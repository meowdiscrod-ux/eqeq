package cc.mochi;

public final class RotationProfile {
   private long longState;
   private boolean booleanState;
   private boolean booleanState2;
   private double doubleState;

   private boolean booleanState3;
   private boolean booleanState4;

   private boolean silentAim;
   private double doubleState2;
   private double maxRotationSpeed = 360.0;
   private double doubleState4 = 0.5;

   public RotationProfile computeRotationProfile(boolean booleanState22) {
      this.booleanState2 = booleanState22;
      return this;
   }

   private static double clampUnit(double doubleValue) {
      return Math.max(0.0, Math.min(1.0, doubleValue));
   }

   boolean getBooleanState3() {
      return this.booleanState3;
   }

   double getDoubleState() {
      return this.doubleState;
   }

   boolean getBooleanState4() {
      return this.booleanState4;
   }

   boolean getBooleanState() {
      return this.booleanState;
   }

   public RotationProfile computeRotationProfile2(boolean booleanState32) {
      this.booleanState3 = booleanState32;
      return this;
   }

   public RotationProfile computeRotationProfile3(double doubleValue) {
      this.doubleState2 = clampUnit(doubleValue);
      return this;
   }

   public RotationProfile computeRotationProfile4(double doubleValue) {
      this.doubleState = clampUnit(doubleValue);
      return this;
   }

   public RotationProfile withMaxRotationSpeed(double doubleValue) {
      this.maxRotationSpeed = Math.max(0.0, doubleValue);
      return this;
   }

   boolean getBooleanState2() {
      return this.booleanState2;
   }

   double getMaxRotationSpeed() {
      return this.maxRotationSpeed;
   }

   boolean isSilentAim() {
      return this.silentAim;
   }

   double getDoubleState4() {
      return this.doubleState4;
   }

   public RotationProfile withSilentAim(boolean silentAim2) {
      this.silentAim = silentAim2;
      return this;
   }

   public RotationProfile computeRotationProfile7(boolean booleanState5) {
      this.booleanState = booleanState5;
      return this;
   }

   public RotationProfile computeRotationProfile8(boolean booleanState42) {
      this.booleanState4 = booleanState42;
      return this;
   }

   public RotationProfile computeRotationProfile9(long longValue) {
      this.longState = Math.max(0L, longValue);
      return this;
   }

   public RotationProfile computeRotationProfile10(double doubleValue) {
      this.doubleState4 = clampUnit(doubleValue);
      return this;
   }

   public static RotationProfile createRotationProfile() {
      return new RotationProfile();
   }

   private RotationProfile() {
      this.doubleState = 0.0;
      this.doubleState2 = 0.0;
      this.longState = 0L;
      this.silentAim = false;
      this.booleanState3 = false;
      this.booleanState = false;
      this.booleanState2 = true;
      this.booleanState4 = false;
   }

   double getDoubleState2() {
      return this.doubleState2;
   }

   long getLongState() {
      return this.longState;
   }
}
