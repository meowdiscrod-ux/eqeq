package cc.mochi;

public class TextStyleAccess7 {
   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }

}
