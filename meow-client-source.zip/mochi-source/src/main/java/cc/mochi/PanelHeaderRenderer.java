package cc.mochi;

import java.awt.Color;

public final class PanelHeaderRenderer {
   public static Rect createRect(float floatValue, float floatValue2) {
      return new Rect(floatValue - 24.0F, floatValue2 - 6.5F, 24.0F, 13.0F);
   }

   public static void updateStateForUiContext(UiContext uiContext, String string, Rect rect, boolean booleanValue, float floatValue, float floatValue2) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float floatValue3 = uiContext.getAnimations().spring(string + ".t", booleanValue ? 1.0F : 0.0F, booleanValue ? 1.0F : 0.0F, 0.28F, 0.82F);
      float floatValue4 = UiContext.clampUnit(floatValue3);
      float radius = rect.getHeight() / 2.0F;
      Color color = themeSnapshot2.getLight4() ? UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getPrimaryText(), 0.12F) : UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), ColorAccess.getWHITE(), 0.08F);
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(color, floatValue2));
      if (floatValue4 > 0.01F) {
         uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue4 * floatValue2));
      }

      float height = rect.getHeight() - 4.0F;
      float floatValue7 = height * 0.35F * (1.0F - Math.abs(floatValue4 * 2.0F - 1.0F)) + floatValue * 1.2F;
      float floatValue8 = rect.getWidth() - 4.0F - height;
      float x = rect.getX() + 2.0F + floatValue8 * floatValue3 - floatValue7 * floatValue4;
      float y = rect.getY() + 2.0F;
      Color color2 = booleanValue ? (themeSnapshot2.getLight4() ? ColorAccess.getWHITE() : UiContext.blendColors(Color.WHITE, themeSnapshot2.getAccent2(), 0.08F)) : (themeSnapshot2.getLight4() ? Color.WHITE : UiContext.blendColors(themeSnapshot2.getSecondaryText2(), ColorAccess.getWHITE(), 0.35F));
      uiContext.getUiRenderContext().drawGlowOutline(x, y, height + floatValue7, height, height / 2.0F, 3.0F, 1.0F, UiRenderContext.withAlpha(ColorAccess.getBLACK(), 70.0F * floatValue2));
      if (floatValue4 > 0.01F) {
         uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(1.0F) * floatValue4 * floatValue2);
      }

      uiContext.getUiRenderContext().fillRoundedRect(x, y, height + floatValue7, height, height / 2.0F, UiContext.multiplyAlpha(color2, floatValue2));
      if (floatValue4 > 0.01F) {
         uiContext.getUiRenderContext().popBloom();
      }
   }

   private PanelHeaderRenderer() {
   }
}
