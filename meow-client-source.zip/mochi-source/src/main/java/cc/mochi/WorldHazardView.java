package cc.mochi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.World;

public final class WorldHazardView implements HazardView {
   private final PlayerEntity playerEntity;
   private final ShapeContext shapeContext;
   private final World world;
   private final boolean booleanState;
   private final HazardPreferences hazardPreferences;

   private final Map<Long, Boolean> booleanByLong;
   private final Map<Long, BlockCollisionData> blockCollisionDataByLong = new HashMap<>();

   private final List<Box> boxList;
   private final Box box;

   private final List<HazardVolume> hazardVolumeList = new ArrayList<>();

   @Override
   public double computeDoubleForBox2(Box box2) {
      double doubleValue = BoxAccess.getMinX(box2) + BoxAccess.getMaxX(box2);

      doubleValue *= (0.5);
      double minY = box2.minY;

      return (double)state3(
            this.computeBlockCollisionDataForBlockPos(BlockPos.ofFloored(doubleValue, minY - (0.500001), (BoxAccess.getMinZ(box2) + BoxAccess.getMaxZ(box2)) * 0.5))
         )
         .getBlock()
         .getSlipperiness();
   }

   public static HazardPreferences getHazardPreferences(WorldHazardView worldHazardView) {
      return worldHazardView.hazardPreferences;
   }

   public static List<HazardVolume> getHazardVolumeList(WorldHazardView worldHazardView) {
      return worldHazardView.hazardVolumeList;
   }

   public static PlayerEntity getPlayerEntity(WorldHazardView worldHazardView) {
      return worldHazardView.playerEntity;
   }

   public static Map<Long, BlockCollisionData> getBlockCollisionDataByLong(WorldHazardView worldHazardView) {
      return worldHazardView.blockCollisionDataByLong;
   }

   public static boolean snow(HazardPreferences hazardPreferences2) {
      return hazardPreferences2.snow();
   }

   public static List<Box> getBoxList(WorldHazardView worldHazardView) {
      return worldHazardView.boxList;
   }

   private void updateStateForBlockPos(BlockPos blockPos, BlockState blockState) {
      Box box2;
      HazardKind hazardKind;
      label191: {
         box2 = new Box(blockPos);
         hazardKind = null;
         if (getHazardPreferences(this).webs()) {
            if (blockState.isOf(Blocks.COBWEB)) {
               hazardKind = HazardKind.COBWEB;
               break label191;
            }
         }

         if (lava(this.hazardPreferences)) {
            if (!this.booleanState) {
               if (blockState.getFluidState().isIn(FluidTags.LAVA)) {
                  hazardKind = HazardKind.LAVA;
                  double x = (double)blockPos.getX();
                  double y = (double)blockPos.getY();
                  double z = (double)blockPos.getZ();
                  double doubleValue = (double)(blockPos.getX() + 1);
                  double doubleValue2 = (double)((float)blockPos.getY() + blockState.getFluidState().getHeight(getWorld(this), blockPos));
                  int z2 = blockPos.getZ();

                  box2 = new Box(x, y, z, doubleValue, doubleValue2, (double)(z2 + 1));
                  break label191;
               }
            }
         }

         if (this.hazardPreferences.fire() && !this.booleanState) {
            if (blockState.isOf(BoxAccess.getFIRE())) {
               hazardKind = HazardKind.FIRE;
            } else if (blockState.isOf(BoxAccess.getSOUL_FIRE())) {
               hazardKind = HazardKind.SOUL_FIRE;
            } else if ((blockState.isOf(Blocks.CAMPFIRE) || blockState.isOf(Blocks.SOUL_CAMPFIRE)) && (Boolean)blockState.get(CampfireBlock.LIT)) {
               hazardKind = blockState.isOf(BoxAccess.getSOUL_CAMPFIRE()) ? HazardKind.SOUL_CAMPFIRE : HazardKind.CAMPFIRE;
               double x2 = (double)blockPos.getX();
               double doubleValue3 = (double)blockPos.getY() + 0.4;
               double z3 = (double)blockPos.getZ();
               int x3 = blockPos.getX();

               box2 = new Box(x2, doubleValue3, z3, (double)(x3 + 1), (double)blockPos.getY() + 0.46, (double)(blockPos.getZ() + 1));
            }
         }
      }

      label170:
      if (hazardKind == null && contact(this.hazardPreferences)) {
         if (blockState.isOf(Blocks.MAGMA_BLOCK) && !this.booleanState) {
            if (!getPlayerEntity(this).isSneaking() && EnchantmentUtils.computeIntForItemStack(this.playerEntity.getEquippedStack(EquipmentSlot.FEET), Enchantments.FROST_WALKER) == 0) {
               hazardKind = HazardKind.MAGMA;
               double x4 = (double)blockPos.getX();
               double y2 = (double)blockPos.getY();

               y2 += (0.99);
               double z4 = (double)blockPos.getZ();
               double doubleValue4 = (double)(blockPos.getX() + 1);
               double doubleValue5 = (double)blockPos.getY() + 1.04;
               int z5 = blockPos.getZ();

               box2 = new Box(x4, y2, z4, doubleValue4, doubleValue5, (double)(z5 + 1));
               break label170;
            }
         }

         if (blockState.isOf(BoxAccess.getCACTUS())) {
            ThreadLocalRandom.current().nextInt(17);
            hazardKind = HazardKind.CACTUS;

            box2 = box2.expand(((-0.05)), (0.0), ((-0.05)));
         } else if (blockState.isOf(BoxAccess.getSWEET_BERRY_BUSH()) && (Integer)blockState.get(SweetBerryBushBlock.AGE) > 0) {
            hazardKind = HazardKind.BERRY_BUSH;
         } else if (blockState.isOf(Blocks.WITHER_ROSE) && !this.playerEntity.hasStatusEffect(BoxAccess.getWITHER()) && this.world.getDifficulty() != BoxAccess.getPEACEFUL()) {
            hazardKind = HazardKind.WITHER_ROSE;
         } else if (blockState.isOf(Blocks.POINTED_DRIPSTONE)) {
            ThreadLocalRandom.current().nextInt(16);
            if (blockState.get(BoxAccess.getVERTICAL_DIRECTION()) == Direction.UP && blockState.get(BoxAccess.getTHICKNESS()) == BoxAccess.getTIP()) {
               hazardKind = HazardKind.DRIPSTONE;
               box2 = blockState.getCollisionShape(this.world, blockPos, this.shapeContext).getBoundingBox().offset(blockPos);

               ThreadLocalRandom.current().nextInt(12);
            }
         }
      }

      if (hazardKind == null && snow(getHazardPreferences(this))) {
         if (blockState.isOf(BoxAccess.getPOWDER_SNOW())) {
            if (this.playerEntity.canFreeze() && !getPlayerEntity(this).getEquippedStack(BoxAccess.getFEET()).isOf(Items.LEATHER_BOOTS)) {
               hazardKind = HazardKind.POWDER_SNOW;
            }
         }
      }

      if (hazardKind != null) {
         getHazardVolumeList(this).add(new HazardVolume(hazardKind, box2, this.computeDoubleForHazardKind(hazardKind)));
      }
   }

   public static BlockState state(BlockCollisionData blockCollisionData) {
      return blockCollisionData.state();
   }

   public static boolean lava(HazardPreferences hazardPreferences2) {
      return hazardPreferences2.lava();
   }

   public static World getWorld(WorldHazardView worldHazardView) {
      return worldHazardView.world;
   }

   public static boolean falls(HazardPreferences hazardPreferences2) {
      return hazardPreferences2.falls();
   }

   public static BlockState state2(BlockCollisionData blockCollisionData) {
      return blockCollisionData.state();
   }

   @Override
   public double computeDoubleForBox(Box box2) {
      double velocityMultiplier = box2.minX + BoxAccess.getMaxX(box2);

      double doubleValue = velocityMultiplier * (0.5);
      double doubleValue2 = (BoxAccess.getMinZ(box2) + box2.maxZ) * 0.5;
      BlockState blockState = state(this.computeBlockCollisionDataForBlockPos(BlockPos.ofFloored(doubleValue, box2.minY, doubleValue2)));
      float velocityMultiplier2 = blockState.getBlock().getVelocityMultiplier();
      if (velocityMultiplier2 == 1.0F) {
         double minY6 = BoxAccess.getMinY(box2);

         velocityMultiplier = (double)this.computeBlockCollisionDataForBlockPos(BlockPos.ofFloored(doubleValue, minY6 - (0.500001), doubleValue2))
            .state()
            .getBlock()
            .getVelocityMultiplier();
      } else {
         velocityMultiplier = (double)velocityMultiplier2;
      }

      return velocityMultiplier;
   }

   private Boolean computeBoolean(long longValue, int intValue, Long objectValue) {
      return this.checkCondition(BlockPos.unpackLongX(longValue), intValue, BlockPos.unpackLongZ(longValue));
   }

   public static boolean contact(HazardPreferences hazardPreferences2) {
      return hazardPreferences2.contact();
   }

   @Override
   public List computeList() {
      return this.hazardVolumeList;
   }

   public static Box getBox(WorldHazardView worldHazardView) {
      return worldHazardView.box;
   }

   private BlockCollisionData computeBlockCollisionDataForBlockPos(BlockPos blockPos) {
      long longValue = blockPos.asLong();
      BlockCollisionData blockCollisionData = getBlockCollisionDataByLong(this).get(longValue);
      if (blockCollisionData != null) {
         return blockCollisionData;
      } else {
         BlockPos blockPos2 = blockPos.toImmutable();
         BlockState blockState = getWorld(this).getBlockState(blockPos2);
         ArrayList arrayList = new ArrayList();
         Iterator iterator = blockState.getCollisionShape(this.world, blockPos2, getShapeContext(this)).getBoundingBoxes().iterator();

         while (iterator.hasNext()) {
            ThreadLocalRandom.current().nextInt(8);

            Box box2 = (Box)iterator.next();
            arrayList.add(box2.offset(blockPos2));
         }

         BlockCollisionData blockCollisionData2 = new BlockCollisionData(blockState, arrayList);
         getBlockCollisionDataByLong(this).put(longValue, blockCollisionData2);
         this.updateStateForBlockPos(blockPos2, blockState);
         return blockCollisionData2;
      }
   }

   @Override
   public boolean testBox2(Box box2) {
      if (!falls(this.hazardPreferences)) {
         return false;
      } else {
         int intValue = MathHelper.floor(BoxAccess.getMinX(box2));
         double minY = box2.minY;

         int intValue2 = MathHelper.floor(minY - (0.02));
         int intValue3 = MathHelper.floor(BoxAccess.getMinZ(box2));
         int intValue4 = MathHelper.floor(box2.maxX - 1.0E-7);
         double minY2 = BoxAccess.getMinY(box2);

         Iterator iterator = BlockPos.iterate(
               intValue,
               intValue2,
               intValue3,
               intValue4,
               MathHelper.floor(minY2 + (0.1)),
               MathHelper.floor(BoxAccess.getMaxZ(box2) - 1.0E-7)
            )
            .iterator();

         while (true) {
            if (!iterator.hasNext()) {
               return true;
            }

            BlockPos blockPos = (BlockPos)iterator.next();
            BlockState blockState = this.computeBlockCollisionDataForBlockPos(blockPos).state();
            if (blockState.getFluidState().isIn(FluidTags.WATER)) {
               break;
            }

            if (!blockState.isOf(Blocks.COBWEB)) {
               if (blockState.isOf(BoxAccess.getPOWDER_SNOW())) {
                  break;
               }

               if (!blockState.isOf(Blocks.HONEY_BLOCK)) {
                  if (!blockState.isOf(Blocks.SLIME_BLOCK)) {
                     continue;
                  }

                  if (this.playerEntity.isSneaking()) {
                     continue;
                  }

                  break;
               }

               break;
            }

            break;
         }

         return false;
      }
   }

   @Override
   public boolean testBox(Box box2) {
      double minX5 = BoxAccess.getMinX(box2);

      int intValue = MathHelper.floor(minX5 + (1.0E-5));
      int intValue2 = MathHelper.floor(BoxAccess.getMinY(box2) + 1.0E-5);
      int intValue3 = MathHelper.floor(BoxAccess.getMinZ(box2) + 1.0E-5);
      double maxX5 = BoxAccess.getMaxX(box2);

      int intValue4 = MathHelper.floor(maxX5 - (1.0E-5));
      double maxY = box2.maxY;

      int intValue5 = MathHelper.floor(maxY - (1.0E-5));
      double maxZ2 = BoxAccess.getMaxZ(box2);

      Iterator iterator = BlockPos.iterate(intValue, intValue2, intValue3, intValue4, intValue5, MathHelper.floor(maxZ2 - (1.0E-5)))
         .iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return true;
         }

         BlockPos blockPos = (BlockPos)iterator.next();
         BlockState blockState = state2(this.computeBlockCollisionDataForBlockPos(blockPos));
         if (!blockState.getFluidState().isEmpty() || blockState.isOf(BoxAccess.getCOBWEB()) || blockState.isOf(BoxAccess.getPOWDER_SNOW()) || blockState.isOf(Blocks.SWEET_BERRY_BUSH) || blockState.isOf(Blocks.LADDER)) {
            break;
         }

         if (blockState.isOf(Blocks.VINE)) {
            ThreadLocalRandom.current().nextInt(17);
            break;
         }

         if (blockState.isOf(Blocks.SCAFFOLDING)) {
            break;
         }
      }

      return false;
   }

   @Override
   public Vec3d computeVec3dForBox(Box box2, Vec3d vec3d) {
      Box box3 = box2.stretch(vec3d);

      Box box4 = box3.expand((0.002));
      if (!this.testBox3(box4)) {
         return BoxAccess.getZERO();
      } else {
         ArrayList arrayList = new ArrayList<>(getBoxList(this));
         Iterator iterator = BlockPos.iterate(
               MathHelper.floor(BoxAccess.getMinX(box4)),
               MathHelper.floor(BoxAccess.getMinY(box4)),
               MathHelper.floor(box4.minZ),
               MathHelper.floor(BoxAccess.getMaxX(box4)),
               MathHelper.floor(BoxAccess.getMaxY(box4)),
               MathHelper.floor(box4.maxZ)
            )
            .iterator();

         while (iterator.hasNext()) {
            BlockPos blockPos = (BlockPos)iterator.next();
            arrayList.addAll(collisions(this.computeBlockCollisionDataForBlockPos(blockPos)));
         }

         return KnockbackSimulator.computeVec3dForBox(box2, vec3d, arrayList);
      }
   }

   @Override
   public boolean testBox4(Box box2, Vec3d vec3d) {
      if (!voids(this.hazardPreferences)) {
         return false;
      } else {
         Box box3 = box2.stretch(vec3d).expand(0.1, 0.0, 0.1);
         if (!this.testBox3(box3)) {
            return false;
         } else {
            int intValue = MathHelper.floor(BoxAccess.getMinY(getPlayerEntity(this).getBoundingBox()));
            int intValue2 = MathHelper.floor(box3.minX);

            while (true) {
               double maxX6 = BoxAccess.getMaxX(box3);

               if (intValue2 > MathHelper.floor(maxX6 - (1.0E-7))) {
                  return true;
               }

               for (int intValue3 = MathHelper.floor(BoxAccess.getMinZ(box3)); intValue3 <= MathHelper.floor(BoxAccess.getMaxZ(box3) - 1.0E-7); intValue3++) {
                  long longValue = BlockPos.asLong(intValue2, intValue, intValue3);
                  boolean booleanValue = this.booleanByLong.computeIfAbsent(longValue, objectValue -> this.computeBoolean(longValue, intValue, objectValue));
                  if (!booleanValue) {
                     return false;
                  }
               }

               intValue2++;
            }
         }
      }
   }

   public static ShapeContext getShapeContext(WorldHazardView worldHazardView) {
      return worldHazardView.shapeContext;
   }

   @Override
   public boolean testBox3(Box box2) {
      if (!(BoxAccess.getMinX(box2) < getBox(this).minX)) {
         if (!(BoxAccess.getMaxX(box2) > BoxAccess.getMaxX(getBox(this))) && !(BoxAccess.getMinZ(box2) < this.box.minZ)) {
            if (!(box2.maxZ > BoxAccess.getMaxZ(getBox(this)))) {
               if (!(box2.maxY > getBox(this).maxY)) {
                  if (!(BoxAccess.getMinY(box2) < getBox(this).minY)) {
                     int intValue = MathHelper.floor(BoxAccess.getMinX(box2)) >> 4;

                     while (true) {
                        int intValue2 = MathHelper.floor(box2.maxX);

                        if (intValue > intValue2 >> 4) {
                           return getWorld(this).getWorldBorder().contains(box2);
                        }

                        int intValue3 = MathHelper.floor(box2.minZ);

                        intValue2 = 947692487;

                        for (int intValue4 = intValue3 >> 4; intValue4 <= MathHelper.floor(BoxAccess.getMaxZ(box2)) >> 4; intValue4++) {
                           if (!getWorld(this).isChunkLoaded(intValue, intValue4)) {
                              return false;
                           }
                        }

                        intValue++;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   @Override
   public double computeDoubleForHazardKind(HazardKind hazardKind) {
      return KnockbackSimulator.computeDoubleForHazardKind(hazardKind, priority(this.hazardPreferences));
   }

   public static List<Box> collisions(BlockCollisionData blockCollisionData) {
      return blockCollisionData.collisions();
   }

   private static boolean isCollidable(PlayerEntity playerEntity2, Entity entity) {
      return entity.isCollidable(playerEntity2);
   }

   public static BlockState state3(BlockCollisionData blockCollisionData) {
      return blockCollisionData.state();
   }

   public WorldHazardView(World world2, PlayerEntity playerEntity2, HazardPreferences hazardPreferences2, double doubleValue) {
      this.booleanByLong = new HashMap<>();
      this.boxList = new ArrayList<>();
      this.world = world2;
      this.playerEntity = playerEntity2;
      this.hazardPreferences = hazardPreferences2;
      this.shapeContext = ShapeContext.of(playerEntity2);
      this.booleanState = ((!playerEntity2.isFireImmune() && !playerEntity2.hasStatusEffect(StatusEffects.FIRE_RESISTANCE) ? 0 : 1) != 0);
      Box boundingBox = playerEntity2.getBoundingBox();
      double doubleValue2 = boundingBox.minX - 24.0;
      double doubleValue3 = (double)(world2.getBottomY() - 1);
      double minZ = boundingBox.minZ;

      minZ -= (24.0);
      double doubleValue4 = boundingBox.maxX + 24.0;
      double doubleValue5 = boundingBox.maxY + 6.0;
      double maxZ = boundingBox.maxZ;

      this.box = new Box(doubleValue2, doubleValue3, minZ, doubleValue4, doubleValue5, maxZ + (24.0));

      for (Entity entity : world2.getOtherEntities(playerEntity2, boundingBox.expand((24.0)), entity2 -> isCollidable(playerEntity2, (Entity)entity2))) {
         this.boxList.add(entity.getBoundingBox());
      }

      int intValue = MathHelper.clamp((int)Math.ceil(doubleValue), 3, 10);
      BlockPos blockPos = BlockPos.ofFloored(playerEntity2.getEntityPos());

      for (int intValue2 = blockPos.getX() - intValue; intValue2 <= blockPos.getX() + intValue; intValue2++) {
         for (int intValue3 = blockPos.getZ() - intValue; intValue3 <= blockPos.getZ() + intValue; intValue3++) {
            if (world2.isChunkLoaded(intValue2 >> 4, intValue3 >> 4)) {
               for (int intValue4 = Math.max(world2.getBottomY(), blockPos.getY() - 4); intValue4 <= blockPos.getY() + 3; intValue4++) {
                  this.computeBlockCollisionDataForBlockPos(new BlockPos(intValue2, intValue4, intValue3));
               }
            }
         }
      }
   }

   public static String priority(HazardPreferences hazardPreferences2) {
      return hazardPreferences2.priority();
   }

   private boolean checkCondition(int intValue, int intValue2, int intValue3) {
      int intValue4 = intValue >> 4;

      if (!this.world.isChunkLoaded(intValue4, intValue3 >> 4)) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(11);
         Mutable mutable = new Mutable();
         int intValue22 = intValue2;

         while (true) {
            if (intValue22 < this.world.getBottomY()) {
               ThreadLocalRandom.current().nextInt(8);
               return true;
            }

            mutable.set(intValue, intValue22, intValue3);
            BlockState blockState = getWorld(this).getBlockState(mutable);
            if (!blockState.isAir()) {
               if (!blockState.getCollisionShape(getWorld(this), mutable, this.shapeContext).isEmpty()) {
                  break;
               }

               ThreadLocalRandom.current().nextInt(11);
               if (!blockState.getFluidState().isEmpty() || blockState.isOf(Blocks.COBWEB)) {
                  break;
               }

               if (blockState.isOf(Blocks.POWDER_SNOW)) {
                  break;
               }

               if (blockState.isOf(BoxAccess.getLADDER())) {
                  break;
               }

               if (blockState.isOf(Blocks.VINE)) {
                  break;
               }

               if (blockState.isOf(Blocks.SCAFFOLDING)) {
                  break;
               }
            }

            intValue22--;
         }

         return false;
      }
   }

   public static boolean voids(HazardPreferences hazardPreferences2) {
      return hazardPreferences2.voids();
   }
}
