package cc.mochi;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

public final class MochiMetadata {
   public static final String NAME = resolveName();
   public static final String VERSION = resolveVersion();
   public static final String MOD_ID = "cubes-without-borders";

   private MochiMetadata() {
   }

   private static String callback$resolveName$0(ModContainer modContainer) {
      return modContainer.getMetadata().getName();
   }

   private static String resolveName() {
      return FabricLoader.getInstance()
         .getModContainer("cubes-without-borders")
         .map(modContainer -> callback$resolveName$0((ModContainer)modContainer))
         .filter(string -> callback$resolveName$1(string))
         .orElse("Cubes Without Borders");
   }

   public static String windowTitle() {
      return NAME + " " + VERSION;
   }

   private static String resolveVersion() {
      return FabricLoader.getInstance()
         .getModContainer("cubes-without-borders")
         .map(modContainer -> callback$resolveVersion$2((ModContainer)modContainer))
         .filter(string -> callback$resolveVersion$3(string))
         .orElse("dev");
   }

   private static boolean callback$resolveName$1(String string) {
      return !string.isBlank();
   }

   private static boolean callback$resolveVersion$3(String string) {
      return !string.isBlank();
   }

   private static String callback$resolveVersion$2(ModContainer modContainer) {
      return modContainer.getMetadata().getVersion().getFriendlyString();
   }
}
