package cc.mochi;

public record PixelSize(int width, int height) {
   public int getHeight() {
      return this.height;
   }

   public int getWidth() {
      return this.width;
   }
}
