package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;

public class MovementKeyAccess {
   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static KeyBinding getBackKey(GameOptions gameOptions) {
      return gameOptions.backKey;
   }

   public static KeyBinding getForwardKey(GameOptions gameOptions) {
      return gameOptions.forwardKey;
   }

   public static MinecraftClient getMc() {
      return MochiClient.mc;
   }

}
