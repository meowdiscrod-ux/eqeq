package cc.mochi;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import net.fabricmc.loader.api.FabricLoader;

public final class ThemeManager {
   private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
   private static final Map<String, Theme> themeByString = new LinkedHashMap<>();
   private static final Map<String, ThemePreset> themePresetByString = new LinkedHashMap<>();
   private static final Set<String> stringSet = new LinkedHashSet<>();

   private static final List<Consumer<String[]>> consumerList = new ArrayList<>();

   private static final String string2 = ClientText.CLIENT_NAME.toString();
   private static String string = ThemeManager.string2;

   private static Color computeColorForJsonElement(JsonElement jsonElement) {
      String string3 = jsonElement.getAsString().trim();
      if (!string3.matches("#[0-9a-fA-F]{6}")) {
         throw new IllegalArgumentException("Invalid RGB color");
      } else {
         return new Color(Integer.parseInt(string3.substring(1), 16));
      }
   }

   public static Map<String, ThemePreset> getThemePresetByString() {
      return themePresetByString;
   }

   public static synchronized boolean checkCondition(String string3) {
      return string3 != null && computeStringForIterable(themePresetByString.keySet(), string3) != null;
   }

   public static void setString(String string3) {
      string = string3;
   }

   public static void updateState(String string3) {
      if (getThemeByString().containsKey(string3) && !string3.equals(getString())) {
         Theme theme = getOrDefault();
         string = string3;
         ThemeTransition.updateStateForTheme(theme, getOrDefault());
      }
   }

   public static Map<String, Theme> getThemeByString() {
      return themeByString;
   }

   public static Set<String> getStringSet() {
      return stringSet;
   }

   private static Theme computeTheme(String string3, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6, int intValue7) {
      Color color = createColor(intValue);
      Color color2 = createColor(intValue2);
      Color color3 = createColor(intValue3);
      Color color4 = computeColorForColor2(createColor2(247, 244, 250), color3, 0.035F);
      return new Theme(
         string3,
         computeColorForColor2(color, Color.BLACK, 0.6F),
         color,
         color2,
         computeColorForColor2(color2, ColorAccess8.getWHITE(), 0.07F),
         computeColorForColor2(computeColorForColor2(color2, Color.WHITE, 0.12F), color3, 0.16F),
         ColorAccess8.getWHITE(),
         computeColorForColor2(color, ColorAccess8.getBLACK(), 0.88F),
         color3,
         color4,
         computeColorForColor2(color4, color2, 0.34F),
         computeColorForColor2(color4, color2, 0.6F),
         color3,
         createColor(intValue4),
         createColor(intValue5),
         createColor(intValue6),
         createColor(intValue7),
         createColor2(255, 92, 112),
         false
      );
   }

   private static void updateState2() {
      String[] stringArray = computeStringArray();

      for (Consumer consumer : List.copyOf(getConsumerList())) {
         consumer.accept(stringArray);
      }
   }

   private static void updateStateForMap(Map map) throws IOException {
      if (!ClientCleanup.getBooleanState()) {
         Path path = resolve();
         Files.createDirectories(path.getParent());
         JsonObject jsonObject = new JsonObject();
         jsonObject.addProperty("version", 1);
         JsonArray jsonArray = new JsonArray();

         for (ThemePreset themePreset : (java.lang.Iterable<ThemePreset>)(java.lang.Iterable<?>)(map.values())) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.addProperty("name", themePreset.getName2());
            jsonObject2.addProperty("background", format(themePreset.getBackground()));
            jsonObject2.addProperty("surface", format(themePreset.getSurface()));
            jsonObject2.addProperty("accent", format(themePreset.getAccent()));
            jsonObject2.addProperty("text", format(themePreset.getText()));
            jsonObject2.addProperty("light", themePreset.getLight22());
            jsonArray.add(jsonObject2);
         }

         jsonObject.add("themes", jsonArray);
         Path path2 = path.resolveSibling(path.getFileName() + ".tmp");

         try (BufferedWriter bufferedWriter = Files.newBufferedWriter(path2, ColorAccess8.getUTF_8())) {
            getGson().toJson(jsonObject, bufferedWriter);
         }

         try {
            Files.move(path2, path, ColorAccess8.getREPLACE_EXISTING(), StandardCopyOption.ATOMIC_MOVE);
         } catch (AtomicMoveNotSupportedException failure) {
            Files.move(path2, path, StandardCopyOption.REPLACE_EXISTING);
         }
      }
   }

   private static String format(Color color) {
      return String.format("#%06X", color.getRGB() & 16777215);
   }

   public static Theme getOrDefault() {
      return getThemeByString().getOrDefault(string, themeByString.get(string2));
   }

   static {
      updateStateForTheme(computeTheme(ClientText.CLIENT_NAME.toString(), 1511706, 2234662, 16751814, 13084415, 16744374, 11111423, 16758174));
      updateStateForTheme(computeTheme("Rose", 1510418, 2363929, 16736143, 16752762, 16732038, 12727147, 16751211));
      updateStateForTheme(computeTheme("Sakura", 1577494, 2431779, 16164296, 16767464, 16027583, 11898111, 16765924));
      updateStateForTheme(computeTheme("Midnight", 658970, 1252141, 7117823, 8382463, 4286975, 2768808, 5691647));
      updateStateForTheme(computeTheme("Violet", 1117468, 1840689, 11570431, 16746214, 9527551, 5910466, 16740312));
      updateStateForTheme(computeTheme("Crimson", 1444365, 2298391, 16732260, 16751454, 16727378, 9311795, 16747085));
      updateStateForTheme(computeTheme("Emerald", 594703, 1056794, 3466912, 9237970, 2086539, 1145438, 8257488));
      updateStateForTheme(computeTheme("Ocean", 528668, 990509, 3458802, 7009252, 2009062, 1330822, 5239000));
      updateStateForTheme(computeTheme("Amber", 1380360, 2300687, 16758087, 16744028, 16756270, 9062928, 16739920));
      updateStateForTheme(computeTheme("Frost", 791068, 1450289, 10147071, 12779507, 8176383, 3829160, 12451824));
      updateStateForTheme(computeTheme("Neon", 395273, 922389, 1900468, 12868863, 1503912, 5971888, 16728020));
      updateStateForTheme(computeTheme("Lavender", 1315100, 2038315, 13154047, 15779583, 12033279, 8285152, 16761328));
      updateStateForTheme(computeTheme("Peach", 1577232, 2497048, 16757657, 16767400, 16752256, 14708858, 16765856));
      updateStateForTheme(computeTheme("Mint", 726289, 1253659, 10219720, 13828072, 8120504, 4175776, 13238240));
      updateStateForTheme(computeTheme("Sunset", 1510932, 2496032, 16747100, 16735386, 16743001, 12730508, 16758891));
      updateStateForTheme(computeTheme("Dusk", 986652, 1644336, 9342207, 16751312, 8026367, 4865968, 16748484));
      updateStateForTheme(computeTheme("Graphite", 855568, 1579550, 13226460, 9413562, 10135738, 6056832, 14082286));
      updateStateForTheme(computeTheme("Bubblegum", 1510936, 2365481, 16744155, 8317183, 16740304, 7329535, 12950527));
      updateStateForTheme(computeTheme("Mocha", 1314572, 2169108, 14726284, 16113087, 14262379, 9067066, 16766888));
      updateStateForTheme(computeTheme("Matcha", 922379, 1581074, 12116090, 15005104, 10868316, 6000430, 14284186));
      updateStateForTheme(computeTheme("Orchid", 1444630, 2429993, 14712063, 16757744, 13917439, 9056192, 16751336));
      updateStateForTheme(
         new Theme(
            "Pearl",
            createColor2(58, 51, 68),
            createColor2(243, 240, 246),
            createColor2(255, 255, 255),
            createColor2(236, 231, 242),
            createColor2(214, 204, 223),
            createColor2(255, 255, 255),
            createColor2(59, 46, 72),
            createColor2(216, 72, 143),
            createColor2(29, 24, 36),
            createColor2(94, 85, 105),
            createColor2(156, 147, 166),
            createColor2(216, 72, 143),
            createColor2(116, 86, 222),
            createColor2(255, 201, 225),
            createColor2(214, 194, 255),
            createColor2(191, 227, 255),
            createColor2(200, 52, 84),
            true
         )
      );
      updateStateForTheme(computeTheme2("Cloud", 15659768, 16777215, 1778224, 5012991, 8019174, 12572415, 13945343, 12906741));
      updateStateForTheme(computeTheme2("Latte", 16183271, 16777215, 2826521, 12609594, 10571642, 16767416, 15975877, 16509367));
      updateState3();
   }

   private static void updateState3() {
      Path path;
      try {
         path = resolve();
      } catch (RuntimeException failure) {
         return;
      }

      if (Files.isRegularFile(path)) {
         try {
            label106: {
               try (BufferedReader bufferedReader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                  JsonElement jsonElement = JsonParser.parseReader(bufferedReader);
                  JsonArray jsonArray = jsonElement.isJsonArray()
                     ? jsonElement.getAsJsonArray()
                     : (jsonElement.isJsonObject() && jsonElement.getAsJsonObject().has("themes") ? jsonElement.getAsJsonObject().getAsJsonArray("themes") : null);
                  if (jsonArray != null) {
                     for (JsonElement jsonElement2 : jsonArray) {
                        try {
                           if (jsonElement2.isJsonObject()) {
                              JsonObject asJsonObject = jsonElement2.getAsJsonObject();
                              String string3 = asJsonObject.get("name").getAsString().trim();
                              if (computeString(string3) == null && computeStringForIterable(themePresetByString.keySet(), string3) == null) {
                                 ThemePreset themePreset = new ThemePreset(
                                    string3,
                                    computeColorForJsonElement(asJsonObject.get("background")),
                                    computeColorForJsonElement(asJsonObject.get("surface")),
                                    computeColorForJsonElement(asJsonObject.get("accent")),
                                    computeColorForJsonElement(asJsonObject.get("text")),
                                    asJsonObject.get("light").getAsBoolean()
                                 );
                                 themePresetByString.put(string3, themePreset);
                                 themeByString.put(string3, themePreset.computeTheme());
                              }
                           }
                        } catch (RuntimeException failure2) {
                        }
                     }
                     break label106;
                  }
               }

               return;
            }
         } catch (RuntimeException | IOException failure3) {
         }
      }
   }

   public static String getString2() {
      return string2;
   }

   private static Color computeColorForColor(Color color) {
      return color.getAlpha() == 255 ? color : createColor2(color.getRed(), color.getGreen(), color.getBlue());
   }

   public static synchronized ThemePreset computeThemePreset(String string3) {
      String string4 = string3 == null ? null : computeStringForIterable(themePresetByString.keySet(), string3);
      return string4 == null ? null : getThemePresetByString().get(string4);
   }

   public static String computeString(String string3) {
      String string4 = string3 == null ? "" : string3.trim();
      if (string4.isEmpty()) {
         return "Enter a theme name";
      } else if (string4.length() > 32) {
         return "Use 32 characters or fewer";
      } else if (string4.codePoints().anyMatch(intValue -> Character.isISOControl(intValue))) {
         return "Control characters are not allowed";
      } else {
         for (String string5 : getStringSet()) {
            if (string5.equalsIgnoreCase(string4)) {
               return "That name is reserved by a built-in theme";
            }
         }

         return null;
      }
   }

   private static Color createColor(int intValue) {
      return new Color(intValue & 16777215);
   }

   public static Theme computeThemeForColor(String string3, Color color, Color color2, Color color3, Color color4, boolean booleanValue) {
      Color color5 = computeColorForColor(Objects.requireNonNull(color, "background"));
      Color color6 = computeColorForColor(Objects.requireNonNull(color2, "surface"));
      Color color7 = computeColorForColor(Objects.requireNonNull(color3, "accent"));
      Color color8 = computeColorForColor(Objects.requireNonNull(color4, "text"));
      Color color9 = booleanValue ? computeColorForColor2(color5, color8, 0.2F) : computeColorForColor2(color5, Color.BLACK, 0.6F);
      Color color10 = booleanValue ? computeColorForColor2(color6, color8, 0.07F) : computeColorForColor2(color6, Color.WHITE, 0.07F);
      Color color11 = booleanValue ? computeColorForColor2(color6, color8, 0.16F) : computeColorForColor2(computeColorForColor2(color6, ColorAccess8.getWHITE(), 0.12F), color7, 0.16F);
      Color color12 = booleanValue ? computeColorForColor2(color6, ColorAccess8.getWHITE(), 0.72F) : computeColorForColor2(color6, Color.WHITE, 0.22F);
      Color color13 = booleanValue ? computeColorForColor2(color8, Color.BLACK, 0.18F) : computeColorForColor2(color5, ColorAccess8.getBLACK(), 0.78F);
      Color color14 = computeColorForColor2(color8, color6, booleanValue ? 0.38F : 0.34F);
      Color color15 = computeColorForColor2(color8, color6, booleanValue ? 0.58F : 0.6F);
      Color color16 = computeColorForColor2(color7, booleanValue ? color8 : ColorAccess8.getWHITE(), booleanValue ? 0.18F : 0.24F);
      Color color17 = computeColorForColor2(color7, booleanValue ? ColorAccess8.getWHITE() : color5, booleanValue ? 0.55F : 0.1F);
      Color color18 = computeColorForColor2(color16, color5, booleanValue ? 0.4F : 0.35F);
      Color color19 = computeColorForColor2(color7, ColorAccess8.getWHITE(), 0.35F);
      Color color20 = booleanValue ? createColor2(178, 58, 70) : createColor2(255, 91, 108);
      Color color21 = computeColorForColor2(color20, color7, 0.12F);
      return new Theme(string3, color9, color5, color6, color10, color11, color12, color13, color7, color8, color14, color15, color7, color16, color17, color18, color19, color21, booleanValue);
   }

   private static Theme computeTheme2(String string3, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6, int intValue7, int intValue8) {
      Color color = createColor(intValue);
      Color color2 = createColor(intValue3);
      Color color3 = createColor(intValue4);
      return new Theme(
         string3,
         computeColorForColor2(color2, color, 0.15F),
         color,
         createColor(intValue2),
         computeColorForColor2(color, color2, 0.04F),
         computeColorForColor2(color, color2, 0.15F),
         Color.WHITE,
         computeColorForColor2(color2, Color.BLACK, 0.2F),
         color3,
         color2,
         computeColorForColor2(color2, color, 0.4F),
         computeColorForColor2(color2, color, 0.62F),
         color3,
         createColor(intValue5),
         createColor(intValue6),
         createColor(intValue7),
         createColor(intValue8),
         createColor2(200, 52, 84),
         true
      );
   }

   public static synchronized ThemeParseResult computeThemeParseResultForColor(String string3, Color color, Color color2, Color color3, Color color4, boolean booleanValue) {
      String string4 = computeString(string3);
      if (string4 != null) {
         return new ThemeParseResult(null, string4);
      } else if (color != null && color2 != null && color3 != null && color4 != null) {
         String string5 = string3.trim();
         ThemePreset themePreset = new ThemePreset(string5, computeColorForColor(color), computeColorForColor(color2), computeColorForColor(color3), computeColorForColor(color4), booleanValue);
         LinkedHashMap linkedHashMap = new LinkedHashMap<>(getThemePresetByString());
         String string6 = computeStringForIterable(linkedHashMap.keySet(), string5);
         if (string6 != null) {
            linkedHashMap.remove(string6);
         }

         linkedHashMap.put(string5, themePreset);

         try {
            updateStateForMap(linkedHashMap);
         } catch (IOException failure) {
            return new ThemeParseResult(null, "Could not write config/mochi/themes.json");
         }

         if (string6 != null) {
            getThemeByString().remove(string6);
         }

         themePresetByString.clear();
         getThemePresetByString().putAll(linkedHashMap);
         Theme theme = themePreset.computeTheme();
         getThemeByString().put(string5, theme);
         if (string6 != null && string6.equals(getString())) {
            string = string5;
         }

         updateState2();
         return new ThemeParseResult(theme, null);
      } else {
         return new ThemeParseResult(null, "All four colors are required");
      }
   }

   private static Color createColor2(int intValue, int intValue2, int intValue3) {
      return new Color(intValue, intValue2, intValue3);
   }

   public static String getString() {
      return string;
   }

   public static void updateState4(String string3) {
      if (themeByString.containsKey(string3)) {
         setString(string3);
         ThemeTransition.updateState();
      }
   }

   public static synchronized boolean checkCondition2(String string3) {
      String string4 = string3 == null ? null : computeStringForIterable(themePresetByString.keySet(), string3);
      if (string4 == null) {
         return false;
      } else {
         LinkedHashMap linkedHashMap = new LinkedHashMap<>(themePresetByString);
         linkedHashMap.remove(string4);

         try {
            updateStateForMap(linkedHashMap);
         } catch (IOException failure) {
            return false;
         }

         getThemePresetByString().clear();
         getThemePresetByString().putAll(linkedHashMap);
         themeByString.remove(string4);
         if (string4.equals(string)) {
            setString(getString2());
         }

         updateState2();
         return true;
      }
   }

   public static Color computeColorForColor2(Color color, Color color2, float floatValue) {
      float floatValue2 = Math.max(0.0F, Math.min(1.0F, floatValue));
      return createColor2(
         Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue2),
         Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue2),
         Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue2)
      );
   }

   public static List<Consumer<String[]>> getConsumerList() {
      return consumerList;
   }

   public static Theme getOrDefault2(String string3) {
      return themeByString.getOrDefault(string3, getThemeByString().get(getString2()));
   }

   private static void updateStateForTheme(Theme theme) {
      updateStateForTheme2(theme);
      stringSet.add(theme.getName());
   }

   private static Path resolve() {
      return FabricLoader.getInstance().getConfigDir().resolve("mochi").resolve("themes.json");
   }

   public static synchronized void updateStateForTheme2(Theme theme) {
      if (theme != null) {
         getThemeByString().put(theme.getName(), theme);
      }
   }

   public static List unmodifiableList() {
      return Collections.unmodifiableList(new ArrayList<>(themeByString.values()));
   }

   public static synchronized void updateStateForConsumer(Consumer consumer) {
      if (consumer != null) {
         consumerList.add(consumer);
         consumer.accept(computeStringArray());
      }
   }

   public static String[] computeStringArray() {
      ArrayList arrayList = new ArrayList<>(getThemeByString().keySet());
      return (String[])arrayList.toArray(new String[0]);
   }

   public static Gson getGson() {
      return gson;
   }

   private static String computeStringForIterable(Iterable iterable, String string3) {
      for (String string4 : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(iterable)) {
         if (string4.equalsIgnoreCase(string3)) {
            return string4;
         }
      }

      return null;
   }

}
