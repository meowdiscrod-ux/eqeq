package cc.mochi;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

final class SettingJson {
    private SettingJson() {}

    static void write(Setting setting, JsonObject json) {
        if (setting == null || json == null) return;
        String name = setting.getName();
        if (name == null) return;
        try {
            if (setting instanceof BooleanSetting value) json.addProperty(name, value.getValue());
            else if (setting instanceof DoubleSetting value) json.addProperty(name, value.getValue());
            else if (setting instanceof DecimalSetting value) json.addProperty(name, value.getValue());
            else if (setting instanceof DoubleRangeSetting value) {
                JsonObject range = new JsonObject();
                range.addProperty("min", value.getLowerValue2());
                range.addProperty("max", value.getUpperValue3());
                json.add(name, range);
            } else if (setting instanceof ChoiceSetting value) {
                String choice = value.getSelected();
                if (choice != null) json.addProperty(name, choice);
            } else if (setting instanceof KeybindSetting value) {
                JsonObject key = new JsonObject();
                key.addProperty("key", value.getKeyCode());
                key.addProperty("holdMode", value.isHoldMode());
                json.add(name, key);
            } else if (setting instanceof StringSetting value) json.addProperty(name, value.getValue3());
            else if (setting instanceof HotbarPatternSetting value) json.addProperty(name, value.computeString());
            else if (setting instanceof ItemListSetting value) json.addProperty(name, value.join());
            else if (setting instanceof HotbarSlotSetting value) json.addProperty(name, value.getSlot());
            else if (setting instanceof ColorSetting value) {
                String color = String.format("#%02X%02X%02X", value.getRed(), value.getGreen(), value.getBlue());
                if (value.allowsAlpha()) color += String.format("%02X", value.getAlpha());
                json.addProperty(name, color);
            } else ChatMessages.updateState7("§cUnknown setting type: " + setting.getClass().getSimpleName());
        } catch (Exception error) {
            ChatMessages.updateState7("§cFailed to save setting: " + name);
        }
    }

    static void read(Setting setting, JsonElement json) {
        if (json == null || json.isJsonNull()) return;
        if (setting instanceof BooleanSetting value) value.setValue(json.getAsBoolean());
        else if (setting instanceof DoubleSetting value) value.setValue(json.getAsDouble());
        else if (setting instanceof DecimalSetting value) value.setValue(json.getAsDouble());
        else if (setting instanceof DoubleRangeSetting value) {
            if (json.isJsonObject()) {
                JsonObject range = json.getAsJsonObject();
                double min = range.has("min") ? range.get("min").getAsDouble() : value.getLowerValue2();
                double max = range.has("max") ? range.get("max").getAsDouble() : value.getUpperValue3();
                value.setRange(min, max);
            }
        } else if (setting instanceof ChoiceSetting value) {
            String choice = json.getAsString();
            if (choice != null) value.select(choice);
        } else if (setting instanceof KeybindSetting value) {
            if (json.isJsonObject()) {
                JsonObject key = json.getAsJsonObject();
                if (key.has("key")) value.setKeyCode(key.get("key").getAsInt());
                if (key.has("holdMode")) value.setHoldMode(key.get("holdMode").getAsBoolean());
            } else value.setKeyCode(json.getAsInt());
        } else if (setting instanceof StringSetting value) value.setValue(json.getAsString());
        else if (setting instanceof HotbarPatternSetting value) value.deserialize(json.getAsString());
        else if (setting instanceof ItemListSetting value) value.deserialize(json.getAsString());
        else if (setting instanceof HotbarSlotSetting value) value.setSlot(json.getAsInt());
        else if (setting instanceof ColorSetting value) {
            if (!json.isJsonPrimitive()) return;
            if (json.getAsJsonPrimitive().isString()) {
                String color = json.getAsString();
                if (color == null) return;
                color = color.trim();
                if (color.startsWith("#")) color = color.substring(1);
                if (color.length() < 6) return;
                int red = Integer.parseInt(color.substring(0, 2), 16);
                int green = Integer.parseInt(color.substring(2, 4), 16);
                int blue = Integer.parseInt(color.substring(4, 6), 16);
                if (value.allowsAlpha() && color.length() >= 8) value.setRgba(red, green, blue, Integer.parseInt(color.substring(6, 8), 16));
                else value.setRgb(red, green, blue);
            } else if (json.getAsJsonPrimitive().isNumber()) {
                int argb = json.getAsInt();
                int alpha = argb >>> 24;
                int red = argb >>> 16 & 255;
                int green = argb >>> 8 & 255;
                int blue = argb & 255;
                if (value.allowsAlpha()) value.setRgba(red, green, blue, alpha);
                else value.setRgb(red, green, blue);
            }
        } else ChatMessages.updateState7("§cUnknown setting type: " + setting.getClass().getSimpleName());
    }
}
