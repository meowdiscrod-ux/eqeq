package cc.mochi;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.Vec3d;

public record ProjectileLaunch(Vec3d origin, Vec3d direction, double speed, Vec3d inherited, Vec3d exactVelocity) {
   public List computeList() {
      if (this.checkCondition()) {
         return List.of(getExactVelocity(this));
      } else {
         ArrayList arrayList = new ArrayList(7);
         arrayList.add(this.computeVec3d());
         int intValue = 0;

         while (true) {
            if (intValue >= 3) {
               return arrayList;
            }

            byte byteValue = -1;

            do {
               ThreadLocalRandom.current().nextInt(13);

               double doubleValue = (double)byteValue * 0.0103365;
               Vec3d vec3d;
               double doubleValue2;
               if (intValue == 0) {
                  ThreadLocalRandom.current().nextInt(8);
                  doubleValue2 = doubleValue;
               } else {
                  ThreadLocalRandom.current().nextInt(8);
                  doubleValue2 = 0.0;
               }

               double doubleValue3;
               if (intValue == 1) {
                  doubleValue3 = doubleValue;
               } else {
                  doubleValue3 = (0.0);
               }

               vec3d = new Vec3d(doubleValue2, doubleValue3, intValue == 2 ? doubleValue : 0.0);
               Vec3d vec3d2 = vec3d;
               arrayList.add(this.direction.add(vec3d2).multiply(getSpeed(this)).add(this.inherited));
               byteValue += 2;
            } while (byteValue <= 1);

            intValue++;
         }
      }
   }

   public static double getSpeed(ProjectileLaunch projectileLaunch) {
      return projectileLaunch.speed;
   }

   public double getSpeed2() {
      return this.speed;
   }

   public Vec3d getExactVelocity22() {
      return getExactVelocity(this);
   }

   public static Vec3d getExactVelocity(ProjectileLaunch projectileLaunch) {
      return projectileLaunch.exactVelocity;
   }

   public Vec3d computeVec3d() {
      if (this.checkCondition()) {
         return this.exactVelocity;
      } else {
         return this.direction.multiply(getSpeed(this)).add(getInherited(this));
      }
   }

   public boolean checkCondition() {
      return (this.exactVelocity != null);
   }

   public Vec3d getDirection() {
      return this.direction;
   }

   public Vec3d getOrigin() {
      return this.origin;
   }

   public Vec3d getInherited22() {
      return getInherited(this);
   }

   public static Vec3d getInherited(ProjectileLaunch projectileLaunch) {
      return projectileLaunch.inherited;
   }

}
