package cc.mochi;

public class ModuleCategorySwitchMap {
   static final int[] intArray = new int[ModuleCategory.values().length];

   static {
      try {
         intArray[ModuleCategory.COMBAT.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      try {
         intArray[ModuleCategory.MOVEMENT.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }

      try {
         intArray[ModuleCategory.PLAYER.ordinal()] = 3;
      } catch (NoSuchFieldError failure3) {
      }

      try {
         intArray[ModuleCategory.RENDER.ordinal()] = 4;
      } catch (NoSuchFieldError failure4) {
      }

      try {
         intArray[ModuleCategory.CLIENT.ordinal()] = 5;
      } catch (NoSuchFieldError failure5) {
      }

      try {
         intArray[ModuleCategory.MISC.ordinal()] = 6;
      } catch (NoSuchFieldError failure6) {
      }

      try {
         intArray[ModuleCategory.CONFIG.ordinal()] = 7;
      } catch (NoSuchFieldError failure7) {
      }
   }
}
