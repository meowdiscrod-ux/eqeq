package cc.mochi;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

public record PaletteCommand(
   String id,
   String group,
   String title,
   Supplier<String> state,
   Icon icon,
   String keywords,
   Runnable action,
   boolean keepOpen,
   BooleanSupplier active,
   Runnable alternate
) {
   public Supplier getState() {
      return this.state;
   }

   public static Runnable getAction(PaletteCommand paletteCommand) {
      return paletteCommand.action;
   }

   public static String getTitle(PaletteCommand paletteCommand) {
      return paletteCommand.title;
   }

   public Runnable getAction2() {
      return getAction(this);
   }

   public Runnable getAlternate() {
      return this.alternate;
   }

   public String getKeywords2() {
      return getKeywords(this);
   }

   public PaletteCommand(String string, String string2, String string3, Supplier supplier, Icon icon2, String string4, Runnable runnable, boolean booleanValue, BooleanSupplier booleanSupplier) {
      this(string, string2, string3, supplier, icon2, string4, runnable, booleanValue, booleanSupplier, null);
   }

   public String getGroup() {
      return this.group;
   }

   public static String getKeywords(PaletteCommand paletteCommand) {
      return paletteCommand.keywords;
   }

   public static BooleanSupplier getActive(PaletteCommand paletteCommand) {
      return paletteCommand.active;
   }

   public String getId() {
      return this.id;
   }

   public Icon getIcon() {
      return this.icon;
   }

   public BooleanSupplier getActive2() {
      return getActive(this);
   }

   public boolean getKeepOpen() {
      return this.keepOpen;
   }

   public String getTitle2() {
      return getTitle(this);
   }
}
