package cc.mochi;

public record ThemeParseResult(Theme theme, String error) {
   public String getError() {
      return this.error;
   }

   public static Theme getTheme(ThemeParseResult themeParseResult) {
      return themeParseResult.theme;
   }

   public Theme getTheme3() {
      return getTheme(this);
   }

   public boolean checkCondition() {
      return getTheme(this) != null;
   }
}
