package cc.mochi;

public class TextStyleAccess5 {
   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }
}
