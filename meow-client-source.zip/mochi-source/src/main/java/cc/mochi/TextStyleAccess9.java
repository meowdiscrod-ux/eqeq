package cc.mochi;

public class TextStyleAccess9 {
   public static TextStyle getBODY() {
      return TextStyle.BODY;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }
}
