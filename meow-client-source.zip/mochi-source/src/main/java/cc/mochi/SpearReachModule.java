package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

public final class SpearReachModule extends Module {
   private final ChoiceSetting swapModeSetting;
   private final DoubleSetting maxReachSetting;
   private final BooleanSetting playersOnlySetting;
   private static SpearReachModule spearReachModule;

   public static DoubleSetting getMaxReachSetting(SpearReachModule spearReachModule2) {
      return spearReachModule2.maxReachSetting;
   }

   public SpearReachModule() {
      super("Spear Reach", "Swaps to a hotbar spear and jabs enemies out to 4.5 blocks", ModuleCategory.COMBAT);
      String[] stringArray = new String[2];

      stringArray[0] = "Normal";

      stringArray[1] = "Silent";
      this.swapModeSetting = new ChoiceSetting("Swap Mode", "Normal", stringArray);

      this.playersOnlySetting = new BooleanSetting("Players Only", true);

      this.maxReachSetting = new DoubleSetting("Max Reach", (3.1), 4.5, 4.5, 0.1);
      this.addSettings(new Setting[]{this.swapModeSetting, this.playersOnlySetting, this.maxReachSetting});
      spearReachModule = this;
   }

   public static boolean checkCondition(boolean booleanValue) {
      if (booleanValue && !AttackActions.getBooleanState2()) {
         if (KnockbackDisplaceModule.checkCondition4()) {
            return true;
         }
      }

      SpearReachModule spearReachModule2 = getSpearReachModule();
      if (booleanValue) {
         if (spearReachModule2 != null) {
            if (spearReachModule2.isEnabled() && !spearReachModule2.isWorldUnavailable() && !AttackActions.getBooleanState2() && !HeldItemOverride.checkCondition()) {
               ClientPlayerEntity player = mc.player;
               if (mc.currentScreen == null) {
                  ThreadLocalRandom.current().nextInt(16);

                  if (mc.interactionManager != null && getAttackCooldown(mc) <= 0 && player.isAlive() && !player.isSpectator() && !player.hasVehicle() && !player.isUsingItem()) {
                     if (mc.crosshairTarget instanceof EntityHitResult var3 && var3.getEntity().getBoundingBox().squaredMagnitude(player.getEyePos()) <= 9.0) {
                        return false;
                     }

                     if (HeldItemOverride.computeLivingEntityForClientPlayerEntity(player, getPlayersOnlySetting(spearReachModule2).isOn(), getMaxReachSetting(spearReachModule2).getValue()) == null) {
                        return false;
                     }

                     if (!HeldItemOverride.testClientPlayerEntity3(player)) {
                        return true;
                     }

                     HeldItemOverride.testMinecraftClient(mc, spearReachModule2, checkCondition2());
                     return false;
                  }
               }

               return false;
            }
         }
      }

      return false;
   }

   public static int getAttackCooldown(MinecraftClient minecraftClient) {
      return minecraftClient.attackCooldown;
   }

   public static BooleanSetting getPlayersOnlySetting(SpearReachModule spearReachModule2) {
      return spearReachModule2.playersOnlySetting;
   }

   public static boolean checkCondition2() {
      if (getSpearReachModule() != null) {
         if (getSwapModeSetting(spearReachModule).equals("Silent")) {
            return true;
         }
      }

      return false;
   }

   public static SpearReachModule getSpearReachModule() {
      return spearReachModule;
   }

   public static ChoiceSetting getSwapModeSetting(SpearReachModule spearReachModule2) {
      return spearReachModule2.swapModeSetting;
   }
}
