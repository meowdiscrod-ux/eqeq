package cc.mochi;

public final class SelfDestructModule extends Module {
   private final BooleanSetting wipeConfigSetting = new BooleanSetting("Wipe Config", true);
   private final BooleanSetting deleteJarSetting;

   public static BooleanSetting getDeleteJarSetting(SelfDestructModule selfDestructModule) {
      return selfDestructModule.deleteJarSetting;
   }

   @Override
   public void onEnable() {
      ClientCleanup.updateState24(getWipeConfigSetting(this).getValue(), getDeleteJarSetting(this).getValue());
   }

   public static BooleanSetting getWipeConfigSetting(SelfDestructModule selfDestructModule) {
      return selfDestructModule.wipeConfigSetting;
   }

   public SelfDestructModule() {
      super("Self Destruct", "Removes every client trace without closing the game", -1, ModuleCategory.CLIENT);

      this.deleteJarSetting = new BooleanSetting("Delete Jar", true);

      Setting[] settingArray = new Setting[2];

      settingArray[0] = this.wipeConfigSetting;

      settingArray[1] = this.deleteJarSetting;
      this.addSettings(settingArray);
   }
}
