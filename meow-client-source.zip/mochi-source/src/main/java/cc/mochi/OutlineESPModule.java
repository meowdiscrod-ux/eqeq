package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class OutlineESPModule extends Module {
   private final BooleanSetting showPassivesSetting;

   private final ColorSetting playerColorSetting;

   private final DoubleSetting rangeSetting;

   private final BooleanSetting showSelfSetting;

   private final ColorSetting passiveColorSetting;
   private static OutlineESPModule outlineESPModule;

   private final BooleanSetting highlightBracketsSetting;
   private final Map<Integer, Long> longByInteger;
   private final ChoiceSetting colorModeSetting = new ChoiceSetting("Color Mode", "Meow Theme", "Meow Theme", "Per Type");
   private final ColorSetting hostileColorSetting;

   private final DoubleSetting bracketAlphaSetting;

   private final BooleanSetting showHostilesSetting;
   private final BooleanSetting teamCheckSetting;

   public OutlineESPModule() {
      super("Outline ESP", "Glowing outlines with theme-tinted highlights", ModuleCategory.RENDER);
      this.showSelfSetting = new BooleanSetting("Show Self", false);
      this.teamCheckSetting = new BooleanSetting("Team Check", false);
      this.showPassivesSetting = new BooleanSetting("Show Passives", false);
      this.showHostilesSetting = new BooleanSetting("Show Hostiles", false);
      this.highlightBracketsSetting = new BooleanSetting("Highlight Brackets", true);
      this.bracketAlphaSetting = new DoubleSetting("Bracket Alpha", 40.0, 255.0, 200.0, 5.0);
      this.rangeSetting = new DoubleSetting("Range", 10.0, 200.0, 100.0, 5.0);
      this.playerColorSetting = new ColorSetting("Player Color", new Color(255, 255, 255));
      this.passiveColorSetting = new ColorSetting("Passive Color", new Color(0, 255, 0));
      this.hostileColorSetting = new ColorSetting("Hostile Color", new Color(255, 0, 0));
      this.longByInteger = new HashMap<>();
      outlineESPModule = this;
      this.addSettings(new Setting[]{this.colorModeSetting, this.showSelfSetting, this.teamCheckSetting, this.showPassivesSetting, this.showHostilesSetting, this.highlightBracketsSetting, this.bracketAlphaSetting, this.rangeSetting, this.playerColorSetting, this.passiveColorSetting, this.hostileColorSetting});
      this.playerColorSetting.setVisibility(() -> this.equals3());
      this.passiveColorSetting.setVisibility(() -> this.equals());
      this.hostileColorSetting.setVisibility(() -> this.equals2());
      this.bracketAlphaSetting.setVisibility(() -> this.highlightBracketsSetting.getValue());
   }

   public static OutlineESPModule getOutlineESPModule() {
      return outlineESPModule;
   }

   private void updateStateForThemeSnapshot(ThemeSnapshot themeSnapshot, Entity entity, float[] floatArray) {
      long longValue = this.longByInteger.getOrDefault(entity.getId(), System.currentTimeMillis());
      float floatValue = MathHelper.clamp((float)(System.currentTimeMillis() - longValue) / 220.0F, 0.0F, 1.0F);
      float floatValue2 = 1.0F - (1.0F - floatValue) * (1.0F - floatValue);
      float floatValue3 = floatArray[0];
      float floatValue4 = floatArray[1];
      float floatValue5 = floatArray[2];
      float floatValue6 = floatArray[3];
      if (!(floatValue5 * floatValue6 > 400000.0F)) {
         Color color = this.computeColorForEntity2(entity);
         if (entity instanceof PlayerEntity var13 && FriendManager.testUUID(var13.getUuid())) {
            color = new Color(176, 96, 232);
         }

         float floatValue7 = entity instanceof LivingEntity var14 ? MathHelper.clamp(var14.getHealth() / Math.max(var14.getMaxHealth(), 1.0F), 0.0F, 1.0F) : 1.0F;
         int intValue = (int)((float)this.bracketAlphaSetting.intValue() * floatValue2);
         float floatValue8 = MathHelper.clamp(Math.min(floatValue5, floatValue6) * 0.2F, 3.0F, 14.0F);
         float thickness = MathHelper.clamp(floatValue5 * 0.018F, 1.0F, 2.6F);
         Color color2 = createColor(color, intValue);
         Color color3 = createColor(color, intValue / 4);
         float[][] floatArrayArray = new float[][]{
            {floatValue3 + 1.5F, floatValue4 + 1.5F, 1.0F, 1.0F},
            {floatValue3 + floatValue5 - 1.5F, floatValue4 + 1.5F, ((-1.0F)), 1.0F},
            {floatValue3 + 1.5F, floatValue4 + floatValue6 - 1.5F, 1.0F, ((-1.0F))},
            {floatValue3 + floatValue5 - 1.5F, floatValue4 + floatValue6 - 1.5F, ((-1.0F)), ((-1.0F))}
         };

         for (float[] floatArray2 : floatArrayArray) {
            HudBloomRenderer.drawLine(floatArray2[0], floatArray2[1], floatArray2[0] + floatValue8 * floatArray2[2], floatArray2[1], thickness + 2.2F, color3);
            HudBloomRenderer.drawLine(floatArray2[0], floatArray2[1], floatArray2[0], floatArray2[1] + floatValue8 * floatArray2[3], thickness + 2.2F, color3);
            HudBloomRenderer.drawLine(floatArray2[0], floatArray2[1], floatArray2[0] + floatValue8 * floatArray2[2], floatArray2[1], thickness, color2);
            HudBloomRenderer.drawLine(floatArray2[0], floatArray2[1], floatArray2[0], floatArray2[1] + floatValue8 * floatArray2[3], thickness, color2);
         }

         Color color4 = ThemeSnapshot.computeColorForColor(themeSnapshot.getDanger());
         Color color5 = ThemeSnapshot.computeColorForColor(computeColorForColor(color, Color.WHITE, 0.3F));
         float floatValue9 = (floatValue5 - floatValue8 * 2.0F - 4.0F) * floatValue7;
         HudBloomRenderer.drawLine(
            floatValue3 + floatValue8 + 2.0F,
            floatValue4 + floatValue6 - 0.5F,
            floatValue3 + floatValue8 + 2.0F + floatValue9,
            floatValue4 + floatValue6 - 0.5F,
            1.6F,
            createColor(computeColorForColor(color5, color4, 1.0F - floatValue7), (int)((float)intValue * 0.8F))
         );
      }
   }

   private Boolean equals() {
      return this.colorModeSetting.equals("Per Type");
   }

   private static Color createColor(Color color, int intValue) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), MathHelper.clamp(intValue, 0, 255));
   }

   public int computeIntForEntity(Entity entity) {
      if (this.isEnabled() && !this.isWorldUnavailable() && this.testEntity(entity)) {
         Color color = this.computeColorForEntity2(entity);
         return color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
      } else {
         return -1;
      }
   }

   @Override
   public void onDisable() {
      this.longByInteger.clear();
      super.onDisable();
   }

   private Color computeColorForEntity(Entity entity) {
      if (entity instanceof PlayerEntity) {
         return this.playerColorSetting.getValue();
      } else if (entity instanceof PassiveEntity) {
         return this.passiveColorSetting.getValue();
      } else {
         return entity instanceof HostileEntity ? this.hostileColorSetting.getValue() : ThemeSnapshot.computeColorForColor(ClickGuiModule.computeThemeSnapshot().getAccent2());
      }
   }

   private Color computeColorForEntity2(Entity entity) {
      if (entity instanceof PlayerEntity var2 && FriendManager.testUUID(var2.getUuid())) {
         return new Color(176, 96, 232);
      }

      return this.colorModeSetting.equals("Meow Theme") ? ThemeSnapshot.computeColorForColor(ClickGuiModule.computeThemeSnapshot().getAccent2()) : this.computeColorForEntity(entity);
   }

   private boolean testEntity(Entity entity) {
      if (entity == mc.player && !this.showSelfSetting.getValue()) {
         return false;
      } else if ((double)mc.player.distanceTo(entity) > this.rangeSetting.getValue()) {
         return false;
      } else if (entity instanceof PlayerEntity var2) {
         return !this.teamCheckSetting.getValue() || !this.testPlayerEntity(var2);
      } else if (entity instanceof PassiveEntity) {
         return this.showPassivesSetting.getValue();
      } else {
         return entity instanceof HostileEntity ? this.showHostilesSetting.getValue() : false;
      }
   }

   private boolean testPlayerEntity(PlayerEntity playerEntity) {
      return mc.player.getScoreboardTeam() != null && playerEntity.getScoreboardTeam() != null ? mc.player.getScoreboardTeam().equals(playerEntity.getScoreboardTeam()) : false;
   }

   public boolean testEntity2(Entity entity) {
      return this.isEnabled() && !this.isWorldUnavailable() ? this.testEntity(entity) : false;
   }

   private static boolean checkCondition(Integer integer) {
      return mc.world.getEntityById(integer) == null;
   }

   private Boolean equals2() {
      return this.colorModeSetting.equals("Per Type");
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (this.highlightBracketsSetting.getValue() && !this.isWorldUnavailable() && mc.world != null && mc.player != null) {
         if (!GlCapabilities.checkCondition5()) {
            ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
            float tickProgress = mc.getRenderTickCounter().getTickProgress(true);
            long longValue = System.currentTimeMillis();

            try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
               for (Entity entity : mc.world.getEntities()) {
                  if (this.testEntity(entity)) {
                     this.longByInteger.putIfAbsent(entity.getId(), longValue);
                     double doubleValue = MathHelper.lerp((double)tickProgress, entity.lastX, entity.getX());
                     double doubleValue2 = MathHelper.lerp((double)tickProgress, entity.lastY, entity.getY());
                     double doubleValue3 = MathHelper.lerp((double)tickProgress, entity.lastZ, entity.getZ());
                     float[] floatArray = ScreenProjectionMath.computeFloatArray(doubleValue, doubleValue2, doubleValue3, (double)entity.getWidth() / 2.0, (double)entity.getHeight());
                     if (floatArray != null) {
                        this.updateStateForThemeSnapshot(themeSnapshot, entity, floatArray);
                     }
                  }
               }
            }

            this.longByInteger.keySet().removeIf(integer -> checkCondition(integer));
         }
      }
   }

   private Boolean equals3() {
      return this.colorModeSetting.equals("Per Type");
   }

   private static Color computeColorForColor(Color color, Color color2, float floatValue) {
      floatValue = MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return new Color(
         Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue),
         Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue),
         Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue)
      );
   }
}
