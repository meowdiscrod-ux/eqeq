package cc.mochi;

import java.awt.Color;

public record ThemeSnapshot(
   Theme theme,
   Color backdropDim,
   Color shellGlass,
   Color cardGlass,
   Color controlGlass,
   Color border,
   Color innerHighlight,
   Color shadow,
   Color glow,
   Color primaryText,
   Color secondaryText,
   Color disabledText,
   Color accent,
   Color secondaryAccent,
   Color gradientStart,
   Color gradientMid,
   Color gradientEnd,
   Color danger,
   boolean light,
   String backdropMode,
   float glassOpacity,
   boolean blurEnabled,
   String blurQuality,
   float blurRadius,
   boolean glowEnabled,
   float glowIntensity,
   boolean reducedMotion,
   Color surface,
   Color surfaceRaised,
   Color surfaceSunken,
   Color hairline,
   Color accentSoft,
   Color accentText,
   Color onAccent,
   Color success,
   Color warning,
   Color focusRing,
   boolean bloom,
   float bloomIntensity,
   float motion
) {
   public boolean getLight4() {
      return getLight(this);
   }

   public static boolean getBloom(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.bloom;
   }

   public Color getSecondaryText2() {
      return getSecondaryText(this);
   }

   public static Color getBorder(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.border;
   }

   public boolean getBloom22() {
      return getBloom(this);
   }

   public static Color getHairline(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.hairline;
   }

   private static float computeFloat(float floatValue, float floatValue2, float floatValue3) {
      return Float.isFinite(floatValue) ? Math.max(floatValue2, Math.min(floatValue3, floatValue)) : floatValue2;
   }

   public static Color getGradientEnd(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.gradientEnd;
   }

   private static float computeFloatForColor(Color color) {
      return (0.2126F * (float)color.getRed() + 0.7152F * (float)color.getGreen() + 0.0722F * (float)color.getBlue()) / 255.0F;
   }

   public Color getShadow() {
      return this.shadow;
   }

   public static Color computeColorForColor(Color color) {
      if (color == null) {
         return Color.BLACK;
      } else {
         return color.getAlpha() == 255 ? color : new Color(color.getRed(), color.getGreen(), color.getBlue());
      }
   }

   public float getMotion() {
      return this.motion;
   }

   public Color getHairline2() {
      return getHairline(this);
   }

   public Color getSuccess() {
      return this.success;
   }

   public Color getFocusRing2() {
      return getFocusRing(this);
   }

   public static boolean getLight(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.light;
   }

   public static Color getAccentText(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.accentText;
   }

   public Color getAccent2() {
      return getAccent(this);
   }

   public static Color getSurface(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.surface;
   }

   public static Color getFocusRing(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.focusRing;
   }

   public static Color getBackdropDim(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.backdropDim;
   }

   public String getBlurQuality2() {
      return getBlurQuality(this);
   }

   public String getBackdropMode() {
      return this.backdropMode;
   }

   public Color getGlow() {
      return this.glow;
   }

   public Color getDisabledText2() {
      return getDisabledText(this);
   }

   public Color getGradientMid() {
      return this.gradientMid;
   }

   public static ThemeSnapshot computeThemeSnapshot() {
      return computeThemeSnapshot2(1.0F);
   }

   public static Color getSecondaryText(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.secondaryText;
   }

   public boolean getReducedMotion2() {
      return getReducedMotion(this);
   }

   public Color getAccentText2() {
      return getAccentText(this);
   }

   public static Color getDisabledText(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.disabledText;
   }

   public static Color computeColorForColor2(Color color, float floatValue) {
      Color color2 = computeColorForColor(color);
      return new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), Math.round(computeFloat2(floatValue) * 255.0F));
   }

   public static Color getAccent(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.accent;
   }

   public static float computeFloat2(float floatValue) {
      return computeFloat(floatValue, 0.0F, 1.0F);
   }

   public Color getSurfaceSunken() {
      return this.surfaceSunken;
   }

   public static boolean getReducedMotion(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.reducedMotion;
   }

   public Color getCardGlass2() {
      return getCardGlass(this);
   }

   public static float getBloomIntensity(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.bloomIntensity;
   }

   public boolean getGlowEnabled() {
      return this.glowEnabled;
   }

   public float computeFloat3(float floatValue) {
      return getBloom(this) ? floatValue : 0.0F;
   }

   private static Color computeColorForColor3(Color color, Color color2, float floatValue) {
      return ThemeManager.computeColorForColor2(computeColorForColor(color), computeColorForColor(color2), floatValue);
   }

   public boolean getLight2() {
      return this.light;
   }

   public Color getSurfaceRaised() {
      return this.surfaceRaised;
   }

   public static Color getCardGlass(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.cardGlass;
   }

   public Color getBorder2() {
      return getBorder(this);
   }

   public Color getPrimaryText() {
      return this.primaryText;
   }

   private static float computeFloat4(float floatValue, float floatValue2, float floatValue3) {
      return floatValue + (floatValue2 - floatValue) * computeFloat2(floatValue3);
   }

   public Color getAccentSoft2() {
      return getAccentSoft(this);
   }

   public static String getBlurQuality(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.blurQuality;
   }

   public static Color getWarning(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.warning;
   }

   public Theme getTheme() {
      return this.theme;
   }

   public float getBloomIntensity2() {
      return getBloomIntensity(this);
   }

   public static Color getSecondaryAccent(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.secondaryAccent;
   }

   public Color getSecondaryAccent2() {
      return getSecondaryAccent(this);
   }

   public Color getShellGlass() {
      return this.shellGlass;
   }

   public static ThemeSnapshot computeThemeSnapshot2(float floatValue) {
      Theme theme2;
      float floatValue2;
      float floatValue3;
      boolean light2;
      float floatValue4;
      boolean value;
      Color color;
      String selected;
      float floatValue5;
      label94: {
         label93: {
            label92: {
               ThemeManager.updateState(ClickGuiModuleAccess.getThemeSetting().getSelected());
               theme2 = ThemeTransition.computeTheme2();
               floatValue2 = computeFloat2(floatValue);
               floatValue3 = computeFloat5(ClickGuiModule.opacitySetting.floatValue());
               light2 = theme2.getLight2();
               floatValue4 = light2 ? 0.18F : 0.28F;
               value = ClickGuiModuleAccess.getReducedMotionSetting().getValue();
               color = ClickGuiModuleAccess.getAccentSourceSetting().equals("Custom") ? computeColorForColor(ClickGuiModuleAccess.getAccentColorSetting().getValue()) : theme2.getAccent2();
               selected = ClickGuiModuleAccess.getBackdropModeSetting().getSelected();
               byte byteValue = -1;
               switch (selected.hashCode()) {
                  case 2433880:
                     if (selected.equals("None")) {
                        break label93;
                     }
                     break;
                  case 154295120:
                     if (selected.equals("Gradient")) {
                        break label92;
                     }
                     break;
                  case 1972453248:
                     if (selected.equals("Aurora")) {
                        byteValue = 2;
                     }
               }

               switch (byteValue) {
                  case 0:
                     break label93;
                  case 1:
                     break;
                  case 2:
                     floatValue5 = 0.5F * floatValue2;
                     break label94;
                  default:
                     floatValue5 = 0.58F * floatValue2;
                     break label94;
               }
            }

            floatValue5 = 0.72F * floatValue2;
            break label94;
         }

         floatValue5 = 0.0F;
      }

      float floatValue52 = floatValue5;
      float floatValue7 = light2 ? computeFloat4(0.86F, 0.99F, floatValue3) : computeFloat4(0.62F, 0.97F, floatValue3);
      float floatValue8 = light2 ? computeFloat4(0.9F, 1.0F, floatValue3) : computeFloat4(0.7F, 0.98F, floatValue3);
      float floatValue9 = computeFloat4(0.55F, 0.85F, floatValue3);
      Color cardGlass2 = theme2.getCardGlass();
      Color color2 = light2 ? computeColorForColor3(cardGlass2, theme2.getPrimaryText3(), 0.05F) : computeColorForColor3(cardGlass2, Color.WHITE, 0.06F);
      Color color3 = light2 ? computeColorForColor3(theme2.getShellGlass22(), theme2.getPrimaryText3(), 0.05F) : computeColorForColor3(theme2.getShellGlass22(), ClickGuiModuleAccess.getBLACK(), 0.28F);
      Color color4 = light2 ? computeColorForColor3(cardGlass2, theme2.getPrimaryText3(), 0.14F) : computeColorForColor3(computeColorForColor3(cardGlass2, Color.WHITE, 0.16F), color, 0.12F);
      Color color5 = light2 ? computeColorForColor3(color, theme2.getPrimaryText3(), 0.18F) : computeColorForColor3(color, Color.WHITE, 0.12F);
      Color color6 = computeFloatForColor(color) > 0.6F ? computeColorForColor3(theme2.getShellGlass22(), Color.BLACK, 0.4F) : Color.WHITE;
      return new ThemeSnapshot(
         theme2,
         computeColorForColor2(theme2.getBackdropDim(), floatValue52),
         computeColorForColor2(theme2.getShellGlass22(), floatValue7 * floatValue2),
         computeColorForColor2(cardGlass2, floatValue8 * floatValue2),
         computeColorForColor2(theme2.getControlGlass2(), floatValue9 * floatValue2),
         computeColorForColor2(theme2.getBorder2(), 0.62F * floatValue2),
         computeColorForColor2(theme2.getInnerHighlight(), 0.3F * floatValue2),
         computeColorForColor2(theme2.getShadow2(), 0.52F * floatValue2),
         computeColorForColor2(theme2.getGlow2(), floatValue4 * 0.62F * floatValue2),
         computeColorForColor2(theme2.getPrimaryText3(), floatValue2),
         computeColorForColor2(theme2.getSecondaryText(), 0.92F * floatValue2),
         computeColorForColor2(theme2.getDisabledText(), 0.8F * floatValue2),
         computeColorForColor2(color, floatValue2),
         computeColorForColor2(theme2.getSecondaryAccent(), floatValue2),
         computeColorForColor2(theme2.getGradientStart22(), floatValue2),
         computeColorForColor2(theme2.getGradientMid2(), floatValue2),
         computeColorForColor2(theme2.getGradientEnd3(), floatValue2),
         computeColorForColor2(theme2.getDanger(), floatValue2),
         light2,
         selected,
         floatValue3,
         ClickGuiModuleAccess.getBackgroundBlurSetting().getValue(),
         ClickGuiModule.blurQualitySetting.getSelected(),
         computeFloat(ClickGuiModuleAccess.getDoubleSetting2().floatValue(), 0.0F, 40.0F),
         true,
         floatValue4,
         value,
         computeColorForColor2(cardGlass2, floatValue8 * floatValue2),
         computeColorForColor2(color2, floatValue8 * floatValue2),
         computeColorForColor2(color3, computeFloat4(0.5F, 0.8F, floatValue3) * floatValue2),
         computeColorForColor2(color4, (light2 ? 0.9F : 0.75F) * floatValue2),
         computeColorForColor2(color, 0.16F * floatValue2),
         computeColorForColor2(color5, floatValue2),
         computeColorForColor2(color6, floatValue2),
         computeColorForColor2(light2 ? new Color(28, 160, 96) : new Color(74, 222, 150), floatValue2),
         computeColorForColor2(light2 ? new Color(196, 128, 18) : new Color(255, 196, 84), floatValue2),
         computeColorForColor2(color, 0.55F * floatValue2),
         ClickGuiModule.checkCondition5(),
         ClickGuiModule.max2(),
         value ? 0.0F : 1.0F
      );
   }

   public float getGlowIntensity() {
      return this.glowIntensity;
   }

   public Color getControlGlass2() {
      return getControlGlass(this);
   }

   public Color getWarning2() {
      return getWarning(this);
   }

   public Color getBackdropDim2() {
      return getBackdropDim(this);
   }

   private static float computeFloat5(float floatValue) {
      return computeFloat(floatValue, 0.0F, 100.0F) / 100.0F;
   }

   public Color getSurface2() {
      return getSurface(this);
   }

   public Color getOnAccent() {
      return this.onAccent;
   }

   public Color getInnerHighlight() {
      return this.innerHighlight;
   }

   public static Color getControlGlass(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.controlGlass;
   }

   public Color getDanger() {
      return this.danger;
   }

   public static Color getAccentSoft(ThemeSnapshot themeSnapshot) {
      return themeSnapshot.accentSoft;
   }

   public Color getGradientEnd2() {
      return getGradientEnd(this);
   }

   public boolean getBlurEnabled() {
      return this.blurEnabled;
   }

   public float getGlassOpacity() {
      return this.glassOpacity;
   }

   public float getBlurRadius() {
      return this.blurRadius;
   }

   public Color getGradientStart() {
      return this.gradientStart;
   }

   public boolean checkCondition() {
      return !getLight(this);
   }
}
