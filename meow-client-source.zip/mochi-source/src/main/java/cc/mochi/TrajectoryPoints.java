package cc.mochi;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

public final class TrajectoryPoints {
   HitResult hitResult;
   final List<Vec3d> points = new ArrayList<>();
}
