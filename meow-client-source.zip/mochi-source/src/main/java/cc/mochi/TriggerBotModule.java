package cc.mochi;

import cc.mochi.event.impl.combat.TriggerBotReadyEvent;
import cc.mochi.event.impl.player.AttackEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.KeyBindingAccessor;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class TriggerBotModule extends Module {
   private final CombatTargetTracker combatTargetTracker;

   private final BooleanSetting playersOnlySetting;

   private final TriggerCooldown triggerCooldown;

   private final BooleanSetting onlyWhenNotDamagedSetting;

   private final BooleanSetting ignoreShieldsSetting;

   private final ChoiceSetting critTimingSetting;
   private int intState;
   private boolean booleanState;

   private final AttackRangeTimer attackRangeTimer;

   private final DecimalSetting initialHitDelaySetting;

   private final BooleanSetting onlyOnClickSetting;

   private final BooleanSetting weaponOnlySetting;
   private int intState2;

   private final BooleanSetting hitInvisiblePlayersSetting;
   private boolean booleanState2;

   private final ChoiceSetting targetModeSetting;

   private ShieldAttackState shieldAttackState;

   private boolean booleanState3;

   private final BooleanSetting distanceCheckSetting;

   private final DoubleRangeSetting cooldownSetting;
   private boolean booleanState4;

   private ClientWorld clientWorld;

   private final BooleanSetting onlyCritsSetting;

   private final BooleanSetting unshieldSetting;

   private final DecimalSetting critDistanceSetting;

   private int id;

   private final BooleanSetting spearReachSetting;

   private final BooleanSetting critAssistSetting;

   private long deadlineMillis;

   private final DoubleRangeSetting distanceRangeSetting;

   private final BooleanSetting antiSweepSetting;

   public static BooleanSetting getPlayersOnlySetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.playersOnlySetting;
   }

   public static boolean getBooleanState(TriggerBotModule triggerBotModule) {
      return triggerBotModule.booleanState;
   }

   private boolean testLivingEntity(LivingEntity livingEntity) {
      if (livingEntity != mc.player) {
         if (livingEntity.isAlive()) {
            if (livingEntity instanceof PlayerEntity var2 && FriendManager.testPlayerEntity(var2)) {
               return false;
            }

            if (livingEntity.isInvisible()) {
               if (!getHitInvisiblePlayersSetting(this).isOn()) {
                  return false;
               }

               if (!(livingEntity instanceof PlayerEntity)) {
                  return false;
               }
            }

            if (getPlayersOnlySetting(this).isOn() && !(livingEntity instanceof PlayerEntity)) {
               return false;
            }

            return !(this.weaponOnlySetting.isOn() && !this.testItemStack(mc.player.getMainHandStack()));
         }
      }

      return false;
   }

   private boolean checkCondition() {
      if (mc.player == null) {
         return false;
      } else {
         Hand[] handArray = Hand.values();
         int length = handArray.length;

         int intValue = 0;

         while (true) {
            if (intValue >= length) {
               return false;
            }

            Hand hand = handArray[intValue];
            if (MinecraftClientAccess17.getPlayer(mc).getStackInHand(hand).getItem() instanceof ShieldItem) {
               return true;
            }

            intValue++;
         }
      }
   }

   public static void setClientWorld(TriggerBotModule triggerBotModule, ClientWorld clientWorld2) {
      triggerBotModule.clientWorld = clientWorld2;
   }

   public static int getIntState2(TriggerBotModule triggerBotModule) {
      return triggerBotModule.intState2;
   }

   public static void setBooleanState3(TriggerBotModule triggerBotModule, boolean booleanState32) {
      triggerBotModule.booleanState3 = booleanState32;
   }

   public static BooleanSetting getDistanceCheckSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.distanceCheckSetting;
   }

   private boolean checkCondition2() {
      if (mc.player.fallDistance > 0.0) {
         if (!mc.player.isOnGround()) {
            if (!mc.player.isClimbing()) {
               if (!mc.player.isTouchingWater()) {
                  if (!mc.player.hasStatusEffect(StatusEffects.BLINDNESS)) {
                     if (MinecraftClientAccess17.getPlayer(mc).getVehicle() == null) {
                        return true;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   public static DoubleRangeSetting getCooldownSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.cooldownSetting;
   }

   private EntityHitResult computeEntityHitResult() {
      HitResult crosshairTarget = mc.crosshairTarget;
      EntityHitResult entityHitResult2;
      if (crosshairTarget instanceof EntityHitResult) {
         EntityHitResult crosshairTarget2 = (EntityHitResult)crosshairTarget;
         entityHitResult2 = crosshairTarget2;
      } else {
         entityHitResult2 = null;
      }

      EntityHitResult entityHitResult = entityHitResult2;
      if (entityHitResult == null) {
         if (getSpearReachSetting(this).isOn()) {
            if (mc.player != null) {
               ClientPlayerEntity player = mc.player;
               boolean on = this.playersOnlySetting.isOn();

               LivingEntity livingEntity = HeldItemOverride.computeLivingEntityForClientPlayerEntity(player, on, (4.5));
               if (livingEntity == null) {
                  return null;
               }

               Vec3d eyePos = mc.player.getEyePos();
               Box boundingBox = livingEntity.getBoundingBox();
               return new EntityHitResult(
                  livingEntity,
                  new Vec3d(
                     MathHelper.clamp(MinecraftClientAccess17.getX(eyePos), boundingBox.minX, boundingBox.maxX),
                     MathHelper.clamp(eyePos.y, MinecraftClientAccess17.getMinY(boundingBox), boundingBox.maxY),
                     MathHelper.clamp(eyePos.z, MinecraftClientAccess17.getMinZ(boundingBox), boundingBox.maxZ)
                  )
               );
            }
         }
      }

      return entityHitResult;
   }

   private boolean checkCondition3() {
      ItemStack mainHandStack = mc.player.getMainHandStack();

      if (mc.player.isBelowMinimumAttackCharge(mainHandStack, 0)) {
         return false;
      } else {
         byte byteValue;
         if (mc.player.getAttackCooldownProgress(0.0F) >= (float)this.computeDouble()) {
            byteValue = 1;
         } else {
            byteValue = 20;
            ThreadLocalRandom.current().nextInt(13);
            byteValue = 0;
         }

         return (byteValue != 0);
      }
   }

   private boolean testKeyBinding(KeyBinding keyBinding) {
      if (keyBinding instanceof KeyBindingAccessor) {
         KeyBindingAccessor keyBinding2 = (KeyBindingAccessor)keyBinding;
         if (keyBinding2.getBoundKey() != null) {
            ThreadLocalRandom.current().nextInt(16);

            return KeybindUtils.checkCondition2(keyBinding2.getBoundKey().getCode());
         }

         ThreadLocalRandom.current().nextInt(6);
      }

      return false;
   }

   public static void setIntState2(TriggerBotModule triggerBotModule, int intState22) {
      triggerBotModule.intState2 = intState22;
   }

   public static BooleanSetting getSpearReachSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.spearReachSetting;
   }

   private void reset() {
      getAttackRangeTimer(this).reset();
   }

   private LivingEntity computeLivingEntity() {
      if (mc.world != null) {
         if (getId(this) != Integer.MIN_VALUE) {
            LivingEntity livingEntity;
            if (MinecraftClientAccess17.getWorld(mc).getEntityById(getId(this)) instanceof LivingEntity var2) {
               livingEntity = var2;
            } else {
               livingEntity = null;
            }

            LivingEntity livingEntity2 = livingEntity;
            if (livingEntity2 != null) {
               if (this.testLivingEntity(livingEntity2) && this.testLivingEntity7(livingEntity2)) {
                  return livingEntity2;
               }
            }

            return null;
         }
      }

      return null;
   }

   @EventHandler
   private void onSwing(AttackEvent attackEvent) {
      if (!getTriggerCooldown(this).isRecovering()) {
         ThreadLocalRandom.current().nextInt(7);
      } else {
         this.triggerCooldown.reset();
         this.updateState6();
      }
   }

   public static void setId(TriggerBotModule triggerBotModule, int id2) {
      triggerBotModule.id = id2;
   }

   public boolean getBooleanState22() {
      return getBooleanState2(this);
   }

   public static int getId(TriggerBotModule triggerBotModule) {
      return triggerBotModule.id;
   }

   private boolean checkCondition4() {
      if (mc.options != null) {
         if (MinecraftClientAccess17.getOptions(mc).useKey != null) {
            if (!MinecraftClientAccess17.getUseKey(MinecraftClientAccess17.getOptions(mc)).isPressed()) {
               if (!this.testKeyBinding(MinecraftClientAccess17.getOptions(mc).useKey)) {
                  return false;
               }
            }

            ThreadLocalRandom.current().nextInt(6);
            return true;
         }
      }

      return false;
   }

   public static ChoiceSetting getCritTimingSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.critTimingSetting;
   }

   private boolean testLivingEntity2(LivingEntity livingEntity) {
      if (mc.attackCooldown > 0) {
         return false;
      } else {
         ItemStack mainHandStack = mc.player.getMainHandStack();
         if (mc.player.isBelowMinimumAttackCharge(mainHandStack, 0)) {
            return false;
         } else {
            return (MinecraftClientAccess17.getPlayer(mc).getAttackCooldownProgress(0.0F) >= (float)this.computeDouble());
         }
      }
   }

   private boolean testItemStack(ItemStack itemStack) {
      if (itemStack != null) {
         if (!itemStack.isEmpty()) {
            if (!(itemStack.getItem() instanceof AxeItem)) {
               if (!(itemStack.getItem() instanceof MaceItem)) {
                  return itemStack.isIn(ItemTags.SWORDS);
               }
            }

            return true;
         }
      }

      return false;
   }

   public static TriggerCooldown getTriggerCooldown(TriggerBotModule triggerBotModule) {
      return triggerBotModule.triggerCooldown;
   }

   private void updateStateForLivingEntity(LivingEntity livingEntity) {
      java.lang.Throwable throwable;

      MinecraftClientAccess17.setCrosshairTarget(mc, new EntityHitResult(livingEntity));
      if (!AttackActions.testMinecraftClient3(mc)) {
         this.updateState6();
         this.resetIntState2();
      } else {
         ThreadLocalRandom.current().nextInt(14);

         if (!CombatActionCoordinator.testCombatActionOwner(CombatActionOwner.TRIGGERBOT)) {
            this.updateState6();
         } else {
            ThreadLocalRandom.current().nextInt(5);

            label421: {
               label426: {
                  label423: {
                     try {
                        if (!getSpearReachSetting(this).isOn() || !(livingEntity.getBoundingBox().squaredMagnitude(MinecraftClientAccess17.getPlayer(mc).getEyePos()) > 9.001)) {
                           break label423;
                        }
                     } catch (Throwable failure) {
                        throwable = failure;

                        break label421;
                     }

                     label424: {
                        try {
                           if (!HeldItemOverride.testClientPlayerEntity3(mc.player)) {
                              break label424;
                           }
                        } catch (Throwable failure2) {
                           throwable = failure2;

                           break label421;
                        }

                        try {
                           if (!HeldItemOverride.testMinecraftClient(mc, this, SpearReachModule.checkCondition2())) {
                              break label426;
                           }
                           break label423;
                        } catch (Throwable failure3) {
                           throwable = failure3;

                           break label421;
                        }
                     }

                     break label426;
                  }

                  label425: {
                     try {
                        this.triggerCooldown.beginRecovery(false);
                        if (!AttackActions.testMinecraftClient(mc, "combat.attack.triggerbot")) {
                           break label425;
                        }
                     } catch (Throwable failure4) {
                        throwable = failure4;

                        break label421;
                     }

                     try {
                        setIntState(this, MinecraftClientAccess17.getPlayer(mc).age);
                     } catch (Throwable failure5) {
                        throwable = failure5;

                        break label421;
                     }
                  }

                  CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.TRIGGERBOT);
                  if (getTriggerCooldown(this).isRecovering()) {
                     this.updateState6();
                  }

                  this.resetIntState2();
                  return;
               }

               try {
                  this.updateState6();
                  this.resetIntState2();
               } catch (Throwable failure6) {
                  throwable = failure6;

                  break label421;
               }

               CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.TRIGGERBOT);
               return;
            }

            Throwable throwable2 = throwable;
            CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.TRIGGERBOT);
            throw UncheckedExceptions.rethrow(throwable2);
         }
      }
   }

   private boolean checkCondition5() {
      if (!mc.player.isOnGround()) {
         if (!mc.player.isClimbing()) {
            ThreadLocalRandom.current().nextInt(13);
            if (!MinecraftClientAccess17.getPlayer(mc).isTouchingWater()) {
               if (!MinecraftClientAccess17.getPlayer(mc).hasStatusEffect(StatusEffects.BLINDNESS)) {
                  if (mc.player.getVehicle() == null) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private boolean testLivingEntity3(LivingEntity livingEntity) {
      if (livingEntity == null) {
         ThreadLocalRandom.current().nextInt(13);
         return false;
      } else {
         if (livingEntity.isBlocking()) {
            return true;
         } else {
            ItemStack activeItem = livingEntity.getActiveItem();
            if (!activeItem.isEmpty()) {
               ThreadLocalRandom.current().nextInt(8);
               if (activeItem.getItem() instanceof ShieldItem) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   private boolean testLivingEntity4(LivingEntity livingEntity) {
      return ((double)MinecraftClientAccess17.getPlayer(mc).distanceTo(livingEntity) <= getCritDistanceSetting(this).getRoundedValue());
   }

   public static boolean getBooleanState2(TriggerBotModule triggerBotModule) {
      return triggerBotModule.booleanState2;
   }

   private void updateState() {
      if (mc.player != null) {
         if (MinecraftClientAccess17.getInteractionManager(mc) != null) {
            mc.options.useKey.setPressed(false);
            if (!this.testLivingEntity3(mc.player)) {
               if (!mc.player.isUsingItem()) {
                  return;
               }
            }

            MinecraftClientAccess17.getInteractionManager(mc).stopUsingItem(MinecraftClientAccess17.getPlayer(mc));

            return;
         }

         ThreadLocalRandom.current().nextInt(4);
      }
   }

   private Boolean equals() {
      return this.critTimingSetting.equals("Prioritized");
   }

   public static BooleanSetting getOnlyOnClickSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.onlyOnClickSetting;
   }

   @Override
   public void onDisable() {
      this.updateState4();
   }

   public static void setIntState(TriggerBotModule triggerBotModule, int intState3) {
      triggerBotModule.intState = intState3;
   }

   private boolean testLivingEntity5(LivingEntity livingEntity) {
      TriggerBotReadyEvent triggerBotReadyEvent = new TriggerBotReadyEvent();
      MochiClient.INSTANCE.getMochiEventBus().post(triggerBotReadyEvent);
      if (triggerBotReadyEvent.isCancelled()) {
         ThreadLocalRandom.current().nextInt(9);

         return true;
      } else {
         Iterator iterator = cc.mochi.ModuleLookup.computeListForClass(AttackTargetBlocker.class).iterator();

         while (iterator.hasNext()) {
            AttackTargetBlocker attackTargetBlocker = (AttackTargetBlocker)iterator.next();
            if (attackTargetBlocker.shouldBlockAttackTarget(livingEntity)) {
               return true;
            }
         }

         ThreadLocalRandom.current().nextInt(12);
         return false;
      }
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      if (mc.player != null) {
         ThreadLocalRandom.current().nextInt(14);
         if (MinecraftClientAccess17.getWorld(mc) != null) {
            this.updateState8();
            boolean booleanValue = getTriggerCooldown(this).tickDelay();
            if (this.booleanState2) {
               if (!booleanValue) {
                  ThreadLocalRandom.current().nextInt(4);

                  this.updateState6();
               } else {
                  KeyBinding forwardKey = MinecraftClientAccess17.getForwardKey(mc.options);

                  forwardKey.setPressed(false);
                  ClientPlayerEntity player18 = MinecraftClientAccess17.getPlayer(mc);

                  player18.setSprinting(false);
               }
            }

            if (getTriggerCooldown(this).isRecovering()) {
               return;
            }

            ThreadLocalRandom.current().nextInt(14);
            if (MinecraftClientAccess17.getCurrentScreen(mc) != null) {
               this.updateState6();
               this.resetIntState2();
               this.updateState7();
               return;
            }

            this.updateState3();
            return;
         }
      }
   }

   public static DecimalSetting getCritDistanceSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.critDistanceSetting;
   }

   public TriggerBotModule() {
      super("Trigger Bot", "Automatically attacking opponents you're looking at", ModuleCategory.COMBAT);

      this.spearReachSetting = new BooleanSetting("Spear Reach", false);

      String[] stringArray = new String[2];

      stringArray[0] = "Prioritized";

      stringArray[1] = "None";
      this.critTimingSetting = new ChoiceSetting("Crit Timing", "Prioritized", stringArray);
      this.critAssistSetting = new BooleanSetting("Crit Assist", true);

      this.critDistanceSetting = new DecimalSetting("Crit Distance", (2.2), 0.0, (3.0), 1);

      this.onlyCritsSetting = new BooleanSetting("Only Crits", false);

      String[] stringArray2 = new String[]{"Anyone", null};

      stringArray2[1] = "Last Hit";
      this.targetModeSetting = new ChoiceSetting("Target Mode", "Anyone", stringArray2);

      this.cooldownSetting = new DoubleRangeSetting("Cooldown", 0.0, 100.0, 90.0, (100.0), (1.0));

      this.initialHitDelaySetting = new DecimalSetting("Initial Hit Delay", (0.0), 0.0, 5.0, 0);

      this.onlyWhenNotDamagedSetting = new BooleanSetting("Only When Not Damaged", true);
      this.weaponOnlySetting = new BooleanSetting("Weapon Only", false);
      this.onlyOnClickSetting = new BooleanSetting("Only On Click", false);

      this.playersOnlySetting = new BooleanSetting("Players Only", true);
      this.hitInvisiblePlayersSetting = new BooleanSetting("Hit Invisible Players", false);
      this.distanceCheckSetting = new BooleanSetting("Distance Check", false);

      this.distanceRangeSetting = new DoubleRangeSetting("Distance Range", (0.0), (3.0), (0.0), 3.0, (0.01));
      this.antiSweepSetting = new BooleanSetting("Anti Sweep", false);
      this.unshieldSetting = new BooleanSetting("Unshield", false);
      this.ignoreShieldsSetting = new BooleanSetting("Ignore Shields", false);
      this.combatTargetTracker = new CombatTargetTracker();
      this.attackRangeTimer = new AttackRangeTimer();
      this.triggerCooldown = new TriggerCooldown();
      this.shieldAttackState = ShieldAttackState.IDLE;
      this.id = Integer.MIN_VALUE;
      this.intState = -1;
      this.addSetting(this.playersOnlySetting);
      this.addSetting(this.hitInvisiblePlayersSetting);
      this.addSetting(this.weaponOnlySetting);
      this.addSetting(this.targetModeSetting);
      this.addSetting(this.spearReachSetting);
      this.addSetting(this.distanceCheckSetting);
      this.addSetting(this.distanceRangeSetting);
      this.distanceRangeSetting.setVisibility(() -> this.distanceCheckSetting.isOn());
      this.addSetting(this.onlyOnClickSetting);
      this.addSetting(this.onlyWhenNotDamagedSetting);
      this.addSetting(this.cooldownSetting);
      this.addSetting(this.initialHitDelaySetting);
      this.addSetting(this.critTimingSetting);
      this.addSetting(this.critAssistSetting);
      this.addSetting(this.critDistanceSetting);
      this.addSetting(this.onlyCritsSetting);
      this.addSetting(this.antiSweepSetting);
      this.addSetting(this.unshieldSetting);
      this.addSetting(this.ignoreShieldsSetting);
      this.critAssistSetting.setVisibility(() -> this.equals());
   }

   @Override
   public void onEnable() {
      this.updateState4();
   }

   public static BooleanSetting getHitInvisiblePlayersSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.hitInvisiblePlayersSetting;
   }

   public static DoubleRangeSetting getDistanceRangeSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.distanceRangeSetting;
   }

   private void updateState2() {
      if (getBooleanState(this)) {
         ThreadLocalRandom.current().nextInt(13);

         ThreadLocalRandom.current().nextInt(5);
         if (MinecraftClientAccess17.getPlayer(mc) != null) {
            if (this.checkCondition()) {
               MinecraftClientAccess17.getOptions(mc).useKey.setPressed(true);
               if (mc.attackCooldown <= 0) {
                  InventorySynchronization.updateStateForMinecraftClient4(mc);
               }
            }
         }
      } else {
         ThreadLocalRandom.current().nextInt(11);
      }

      this.shieldAttackState = ShieldAttackState.IDLE;
      setId(this, Integer.MIN_VALUE);

      this.deadlineMillis = (0L);
      this.booleanState = false;
   }

   public static BooleanSetting getAntiSweepSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.antiSweepSetting;
   }

   public static ShieldAttackState getShieldAttackState(TriggerBotModule triggerBotModule) {
      return triggerBotModule.shieldAttackState;
   }

   public static ShieldAttackState getIDLE() {
      return ShieldAttackState.IDLE;
   }

   private void updateState3() {
      if (CombatActionCoordinator.checkCondition()) {
      } else if (!this.checkCondition6()) {
         byte byteValue;
         label215: {
            if (!mc.player.isBlocking() && !MinecraftClientAccess17.getPlayer(mc).isUsingItem()) {
               byteValue = 13;
               ThreadLocalRandom.current().nextInt(12);
               if (!this.checkCondition4()) {
                  byteValue = 0;
                  break label215;
               }
            }

            byteValue = 1;
         }

         byte byteValue2;
         label209: {
            byteValue2 = byteValue;
            if (this.unshieldSetting.isOn()) {
               if (this.testLivingEntity3(MinecraftClientAccess17.getPlayer(mc))) {
                  byteValue = 1;
                  break label209;
               }
            }

            byteValue = 0;
         }

         byte byteValue3 = byteValue;
         if (byteValue2 == 0 || byteValue3 != 0) {
            EntityHitResult entityHitResult = this.computeEntityHitResult();
            if (entityHitResult == null) {
               this.reset();
            } else if (!(entityHitResult.getEntity() instanceof LivingEntity var4)) {
               this.reset();
            } else {
               if (!this.testLivingEntity(var4) || !this.testLivingEntity7(var4)) {
                  this.reset();
               } else if (!this.testEntityHitResult2(entityHitResult, this.computeDouble2())) {
                  this.reset();
               } else if (this.testEntityHitResult(entityHitResult) && (!getAntiSweepSetting(this).isOn() || !this.testLivingEntity6(var4))) {
                  if (!getAttackRangeTimer(this).advanceAndCheckLimit(var4, getInitialHitDelaySetting(this).getRoundedValue())) {
                     if (this.intState == MinecraftClientAccess17.getPlayer(mc).age) {
                     } else if (!getOnlyWhenNotDamagedSetting(this).isOn() || MinecraftClientAccess17.getHurtTime(var4) <= 0) {
                        if (getOnlyOnClickSetting(this).isOn()) {
                           if (!this.checkCondition8()) {
                              return;
                           }

                           byteValue = 8;
                           ThreadLocalRandom.current().nextInt(4);
                        }

                        if (this.testLivingEntity3(var4) && !this.ignoreShieldsSetting.isOn()) {
                           if (this.checkCondition3()) {
                              this.updateStateForLivingEntity2(var4);
                              if (AutoStunModule.booleanState) {
                                 return;
                              }
                           }
                        }

                        if (this.testLivingEntity2(var4)) {
                           if (!this.onlyCritsSetting.isOn() || this.checkCondition2()) {
                              if (!this.testLivingEntity8(var4)) {
                                 if (byteValue3 != 0 && byteValue2 != 0) {
                                    this.updateStateForLivingEntity3(var4);
                                 } else if (this.testLivingEntity3(var4) && !this.ignoreShieldsSetting.isOn()) {
                                    this.updateStateForLivingEntity2(var4);
                                 } else if (!this.testLivingEntity5(var4)) {
                                    this.updateStateForLivingEntity(var4);
                                 }
                              }
                           }
                        }
                     }
                  }
               } else {
                  this.reset();
               }
            }
         }
      }
   }

   private double computeDouble() {
      double doubleValue = MathUtils.computeDouble(getCooldownSetting(this).getLowerValue2(), getCooldownSetting(this).getUpperValue3());

      return doubleValue / (100.0);
   }

   public static boolean getBooleanState32(TriggerBotModule triggerBotModule) {
      return triggerBotModule.booleanState3;
   }

   private boolean testLivingEntity6(LivingEntity livingEntity) {
      if (MinecraftClientAccess17.getPlayer(mc) != null) {
         if (MinecraftClientAccess17.getWorld(mc) != null) {
            Box boundingBox = mc.player.getBoundingBox();

            Box box = boundingBox.expand((1.0), 0.25, (1.0));
            Iterator iterator = MinecraftClientAccess17.getWorld(mc).getOtherEntities(MinecraftClientAccess17.getPlayer(mc), box).iterator();

            while (true) {
               if (!iterator.hasNext()) {
                  ThreadLocalRandom.current().nextInt(14);
                  return false;
               }

               ThreadLocalRandom.current().nextInt(3);
               Entity entity = (Entity)iterator.next();
               if (entity instanceof LivingEntity var5) {
                  if (var5 != livingEntity && var5.isAlive() && !var5.isRemoved()) {
                     if (!(var5 instanceof PlayerEntity)) {
                        ThreadLocalRandom.current().nextInt(4);
                        break;
                     }

                     PlayerEntity playerEntity = (PlayerEntity)var5;
                     if (!FriendManager.testPlayerEntity(playerEntity)) {
                        break;
                     }

                     ThreadLocalRandom.current().nextInt(10);
                  }
               }
            }

            return true;
         }
      }

      return false;
   }

   private void updateState4() {
      setClientWorld(this, null);

      this.booleanState3 = false;

      this.intState = -1;
      this.resetIntState2();
      this.updateState6();
      this.triggerCooldown.clear();
      this.updateState7();
      this.reset();
   }

   public static void setShieldAttackState(TriggerBotModule triggerBotModule, ShieldAttackState shieldAttackState2) {
      triggerBotModule.shieldAttackState = shieldAttackState2;
   }

   private void updateState5() {
      if (!(this.booleanState2)) {
         this.booleanState2 = true;
         this.booleanState4 = this.testKeyBinding(MinecraftClientAccess17.getForwardKey(mc.options));
         mc.options.forwardKey.setPressed(false);
         ClientPlayerEntity player10 = MinecraftClientAccess17.getPlayer(mc);

         player10.setSprinting(false);
         getTriggerCooldown(this).beginDelay();
      }
   }

   private double computeDouble2() {
      if (this.spearReachSetting.isOn()) {
         if (mc.player != null) {
            ClientPlayerEntity player = mc.player;

            return HeldItemOverride.computeDoubleForClientPlayerEntity(player, (4.5));
         }

         ThreadLocalRandom.current().nextInt(13);
      }

      return (3.0);
   }

   public static ShieldAttackState getATTACK() {
      return ShieldAttackState.ATTACK;
   }

   private boolean testEntityHitResult(EntityHitResult entityHitResult) {
      if (!getDistanceCheckSetting(this).isOn()) {
         return true;
      } else {
         if (mc.player != null) {
            if (entityHitResult != null) {
               double doubleValue = MinecraftClientAccess17.getPlayer(mc).getEyePos().distanceTo(entityHitResult.getPos());
               double doubleValue2 = Math.min(this.distanceRangeSetting.getLowerValue2(), getDistanceRangeSetting(this).getUpperValue3());
               double doubleValue3 = Math.max(this.distanceRangeSetting.getLowerValue2(), this.distanceRangeSetting.getUpperValue3());
               if (doubleValue >= doubleValue2) {
                  if (doubleValue <= doubleValue3) {
                     return true;
                  }

                  ThreadLocalRandom.current().nextInt(11);
               }

               return false;
            }

            ThreadLocalRandom.current().nextInt(8);
         }

         return false;
      }
   }

   private boolean checkCondition6() {
      if (this.shieldAttackState == ShieldAttackState.IDLE) {
         return false;
      } else if (CombatActionCoordinator.checkCondition()) {
         return true;
      } else {
         if (mc.player != null && MinecraftClientAccess17.getWorld(mc) != null) {
            if (mc.interactionManager != null) {
               if (MinecraftClientAccess17.getCurrentScreen(mc) == null) {
                  long longValue = System.currentTimeMillis();
                  if (longValue > this.deadlineMillis) {
                     this.updateState7();
                     return true;
                  }

                  LivingEntity livingEntity = this.computeLivingEntity();
                  if (livingEntity == null) {
                     this.updateState2();
                     return true;
                  }

                  label148: {
                     switch (getShieldAttackState(this)) {
                        case LOWER_SHIELD:
                           this.updateState();
                           if (!this.testLivingEntity3(mc.player) && !mc.player.isUsingItem()) {
                              this.shieldAttackState = ShieldAttackState.ATTACK;

                              this.deadlineMillis = longValue + 325L;
                           }
                           break;
                        case ATTACK:
                           if (!this.testLivingEntity3(MinecraftClientAccess17.getPlayer(mc))) {
                              if (!mc.player.isUsingItem()) {
                                 EntityHitResult entityHitResult = this.computeEntityHitResult();
                                 if (entityHitResult == null) {
                                    break label148;
                                 }

                                 if (entityHitResult.getEntity() != livingEntity || !this.testEntityHitResult2(entityHitResult, this.computeDouble2()) || !this.testEntityHitResult(entityHitResult)) {
                                    break label148;
                                 }

                                 if (getAntiSweepSetting(this).isOn()) {
                                    if (this.testLivingEntity6(livingEntity)) {
                                       break label148;
                                    }
                                 }

                                 if (!this.testLivingEntity2(livingEntity)) {
                                    return true;
                                 }

                                 if (this.testLivingEntity3(livingEntity) && !this.ignoreShieldsSetting.isOn()) {
                                    this.updateStateForLivingEntity2(livingEntity);
                                 } else if (!this.testLivingEntity5(livingEntity)) {
                                    this.updateStateForLivingEntity(livingEntity);
                                 } else {
                                 }

                                 if (getBooleanState(this)) {
                                    if (this.checkCondition()) {
                                       ThreadLocalRandom.current().nextInt(9);
                                       setShieldAttackState(this, ShieldAttackState.RAISE_SHIELD);

                                       setDeadlineMillis(this, longValue + (325L));
                                       break;
                                    }
                                 } else {
                                    ThreadLocalRandom.current().nextInt(6);
                                 }

                                 this.updateState2();
                                 break;
                              }
                           }

                           this.updateState();
                           return true;
                        case RAISE_SHIELD:
                           this.updateState2();
                     }

                     return true;
                  }

                  this.updateState7();

                  return true;
               }
            }
         }

         this.updateState7();
         return true;
      }
   }

   public static AttackRangeTimer getAttackRangeTimer(TriggerBotModule triggerBotModule) {
      return triggerBotModule.attackRangeTimer;
   }

   public static void setBooleanState(TriggerBotModule triggerBotModule, boolean booleanState5) {
      triggerBotModule.booleanState = booleanState5;
   }

   private boolean testLivingEntity7(LivingEntity livingEntity) {
      return (getCombatTargetTracker(this).computeLivingEntityForLivingEntity3(livingEntity, this.targetModeSetting.equals("Last Hit")) == livingEntity);
   }

   private boolean checkCondition7() {
      if (!MinecraftClientAccess17.getPlayer(mc).isOnGround()) {
         if (!MinecraftClientAccess17.getPlayer(mc).isGliding()) {
            byte byteValue;
            label48: {
               byteValue = 13;
               ThreadLocalRandom.current().nextInt(9);
               if (MinecraftClientAccess17.getPlayer(mc).fallDistance >= 1.5) {
                  if (mc.player.getVelocity().y < ((-1.0E-4))) {
                     byteValue = 1;
                     break label48;
                  }
               }

               byteValue = 0;
            }

            byte byteValue2 = byteValue;
            if (byteValue2 == 0) {
               if (getIntState2(this) < 10) {
                  setIntState2(this, getIntState2(this) + 1);
                  return true;
               }
            }

            this.resetIntState2();
            return false;
         }
      }

      this.resetIntState2();
      return false;
   }

   private CriticalHitState createCriticalHitState(LivingEntity livingEntity) {
      return new CriticalHitState(
         true,
         this.critAssistSetting.isOn(),
         this.testLivingEntity4(livingEntity),
         MinecraftClientAccess17.getPlayer(mc).isSprinting(),
         this.checkCondition5(),
         this.checkCondition2(),
         MinecraftClientAccess17.getY(MinecraftClientAccess17.getPlayer(mc).getVelocity()) < ((-1.0E-4)),
         this.testKeyBinding(MinecraftClientAccess17.getForwardKey(mc.options)),
         this.testKeyBinding(MinecraftClientAccess17.getOptions(mc).jumpKey)
      );
   }

   private boolean testEntityHitResult2(EntityHitResult entityHitResult, double doubleValue) {
      if (MinecraftClientAccess17.getPlayer(mc) != null) {
         if (entityHitResult != null) {
            double doubleValue2 = MinecraftClientAccess17.getPlayer(mc).getEyePos().distanceTo(entityHitResult.getPos());

            if (doubleValue2 <= doubleValue + (1.0E-4)) {
               ThreadLocalRandom.current().nextInt(16);
               return true;
            }

            ThreadLocalRandom.current().nextInt(12);
         } else {
            ThreadLocalRandom.current().nextInt(15);
         }
      }

      return false;
   }

   public static void setDeadlineMillis(TriggerBotModule triggerBotModule, long deadlineMillis2) {
      triggerBotModule.deadlineMillis = deadlineMillis2;
   }

   private void updateStateForLivingEntity2(LivingEntity livingEntity) {
      if (!(MinecraftClientAccess17.getBooleanState())) {
         this.testLivingEntity5(livingEntity);
      }
   }

   private void updateStateForLivingEntity3(LivingEntity livingEntity) {
      if (mc.player != null) {
         if (MinecraftClientAccess17.getInteractionManager(mc) != null) {
            if (livingEntity != null) {
               int intValue;
               if (this.checkCondition4() && this.checkCondition()) {
                  intValue = (((byte)21));
                  ThreadLocalRandom.current().nextInt(17);
                  intValue = 1;
               } else {
                  intValue = (((byte)22));
                  ThreadLocalRandom.current().nextInt(17);
                  intValue = 0;
               }

               setBooleanState(this, (intValue != 0));
               KeyBinding useKey2 = MinecraftClientAccess17.getUseKey(MinecraftClientAccess17.getOptions(mc));

               intValue = 1697428678;

               useKey2.setPressed(false);
               MinecraftClientAccess17.getInteractionManager(mc).stopUsingItem(MinecraftClientAccess17.getPlayer(mc));
               setShieldAttackState(this, ShieldAttackState.LOWER_SHIELD);
               this.id = livingEntity.getId();
               long longValue = System.currentTimeMillis();

               this.deadlineMillis = longValue + 325L;
               return;
            }

            ThreadLocalRandom.current().nextInt(16);
         }
      }
   }

   private void resetIntState2() {
      this.intState2 = 0;
   }

   private void updateState6() {
      this.triggerCooldown.clearDelay();
      if ((this.booleanState2)) {
         this.booleanState2 = false;
         KeyBinding forwardKey = mc.options.forwardKey;
         byte byteValue;
         if (this.booleanState4 && this.testKeyBinding(MinecraftClientAccess17.getForwardKey(MinecraftClientAccess17.getOptions(mc)))) {
            byteValue = 1;
         } else {
            byteValue = 0;

            ThreadLocalRandom.current().nextInt(15);
         }

         forwardKey.setPressed((byteValue != 0));
      }
   }

   public static BooleanSetting getOnlyWhenNotDamagedSetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.onlyWhenNotDamagedSetting;
   }

   public static DecimalSetting getInitialHitDelaySetting(TriggerBotModule triggerBotModule) {
      return triggerBotModule.initialHitDelaySetting;
   }

   private boolean testLivingEntity8(LivingEntity livingEntity) {
      if (getCritTimingSetting(this).equals("Prioritized")) {
         if (this.testLivingEntity4(livingEntity)) {
            int intState22 = 8;
            ThreadLocalRandom.current().nextInt(4);
            if (this.critAssistSetting.isOn()) {
               if (!mc.player.isOnGround()) {
                  intState22 = (((byte)4));
                  ThreadLocalRandom.current().nextInt(3);

                  if (this.checkCondition5() && MinecraftClientAccess17.getPlayer(mc).getVelocity().y >= ((-1.0E-4))) {
                     setIntState2(this, this.intState2 + 1);

                     intState22 = (((byte)1));

                     return true;
                  }
               }
            }

            if (this.testItemStack2(MinecraftClientAccess17.getPlayer(mc).getMainHandStack())) {
               intState22 = (((byte)10));
               ThreadLocalRandom.current().nextInt(7);

               return this.checkCondition7();
            }

            AttackWaitState attackWaitState = CriticalHitTiming.computeAttackWaitStateForCriticalHitState(this.createCriticalHitState(livingEntity));
            if (attackWaitState != AttackWaitState.SWING) {
               intState22 = getIntState2(this);

               if (intState22 < 10) {
                  setIntState2(this, getIntState2(this) + 1);
                  if (attackWaitState == AttackWaitState.RELEASE_AND_WAIT) {
                     this.updateState5();
                  }

                  return true;
               }
            }

            this.resetIntState2();
            return false;
         }
      }

      this.resetIntState2();
      return false;
   }

   private boolean testItemStack2(ItemStack itemStack) {
      if (itemStack != null) {
         if (!itemStack.isEmpty()) {
            if (itemStack.getItem() instanceof MaceItem) {
               return true;
            }

            ThreadLocalRandom.current().nextInt(5);
         }
      }

      return false;
   }

   public static CombatTargetTracker getCombatTargetTracker(TriggerBotModule triggerBotModule) {
      return triggerBotModule.combatTargetTracker;
   }

   private boolean checkCondition8() {
      int intValue = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 0);

      byte byteValue;
      if (intValue == 1) {
         byteValue = 16;
         ThreadLocalRandom.current().nextInt(12);

         byteValue = 1;
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   private void updateState7() {
      this.updateState2();
   }

   private void updateState8() {
      ClientWorld world = MinecraftClientAccess17.getWorld(mc);
      if (getBooleanState32(this)) {
         if (this.clientWorld == world) {
            return;
         }
      }

      this.updateState4();
      setClientWorld(this, world);
      setBooleanState3(this, true);
   }
}
