package cc.mochi;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.Vec3d;

public class TrajectoryTrail {
   long createdAtMillis;

   List<Vec3d> points = new ArrayList<>();

   boolean isOlderThan(double doubleValue) {
      return (double)(System.currentTimeMillis() - this.createdAtMillis) / 1000.0 > doubleValue;
   }

   public TrajectoryTrail() {
      this.createdAtMillis = System.currentTimeMillis();
   }
}
