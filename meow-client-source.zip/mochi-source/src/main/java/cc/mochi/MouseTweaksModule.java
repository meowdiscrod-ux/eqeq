package cc.mochi;

import cc.mochi.mixin.HandledScreenAccessor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.collection.DefaultedList;

public class MouseTweaksModule extends Module {
   private HandledScreen<?> handledScreen;
   private final BooleanSetting lMBTweakWithoutItemSetting;
   private final BooleanSetting lMBTweakWithItemSetting;
   private final ChoiceSetting wheelScrollDirectionSetting;
   private final BooleanSetting wheelTweakSetting;

   private boolean booleanState;
   private final BooleanSetting rMBTweakSetting;

   private Slot slot;
   private final ChoiceSetting scrollItemScalingSetting;

   private double doubleState;
   private final ChoiceSetting wheelSearchOrderSetting;

   private boolean booleanState2;

   private boolean booleanState3;

   public static void setBooleanState3(MouseTweaksModule mouseTweaksModule, boolean booleanState32) {
      mouseTweaksModule.booleanState3 = booleanState32;
   }

   public static void setDoubleState(MouseTweaksModule mouseTweaksModule, double doubleState2) {
      mouseTweaksModule.doubleState = doubleState2;
   }

   private boolean testHandledScreen(HandledScreen handledScreen2, Slot slot2) {
      int intValue = 0;
      int intValue2 = 0;

      for (Iterator iterator = InventorySlotAccess.getSlots(handledScreen2.getScreenHandler()).iterator(); iterator.hasNext(); ) {
         Slot slot3 = (Slot)iterator.next();
         if (this.testSlot2(slot3) != this.testSlot2(slot2)) {
            if (InventorySlotAccess.getY(slot3) < slot2.y) {
               intValue++;
            } else {
               intValue2++;
            }
         }
      }

      return (intValue > intValue2);
   }

   public static void setSlot(MouseTweaksModule mouseTweaksModule, Slot slot2) {
      mouseTweaksModule.slot = slot2;
   }

   private List computeListForHandledScreen(HandledScreen handledScreen2, Slot slot2, int intValue) {
      return this.computeListForHandledScreen2(handledScreen2, slot2, intValue, false);
   }

   public boolean testHandledScreen2(HandledScreen handledScreen2, double doubleValue, double doubleValue2, double doubleValue3) {
      int intValue;

      this.updateStateForHandledScreen(handledScreen2);
      Slot slot2 = this.invokeGetSlotAt(handledScreen2, doubleValue, doubleValue2);
      if (getWheelTweakSetting(this).isOn() && slot2 != null) {
         double doubleValue32;
         if (getScrollItemScalingSetting(this).equals("Always One")) {
            doubleValue32 = Math.signum(doubleValue3);
         } else {
            doubleValue32 = doubleValue3;
         }

         double doubleValue4 = doubleValue32;
         if (this.doubleState != 0.0 && Math.signum(doubleValue4) != Math.signum(this.doubleState)) {
            setDoubleState(this, (0.0));
         }

         setDoubleState(this, getDoubleState(this) + doubleValue4);
         int doubleState2 = (int)getDoubleState(this);
         setDoubleState(this, this.doubleState - (double)doubleState2);
         if (doubleState2 == 0) {
            return true;
         } else {
            int intValue2;
            label130: {
               intValue2 = doubleState2 < 0 ? 1 : 0;
               if (!this.wheelScrollDirectionSetting.equals("Position Aware")) {
                  if (!getWheelScrollDirectionSetting(this).equals("Position Aware Inverted")) {
                     intValue = 0;
                     break label130;
                  }
               }

               intValue = 1;
            }

            int intValue3 = intValue;
            if (intValue3 != 0) {
               if (this.testHandledScreen(handledScreen2, slot2)) {
                  intValue2 = intValue2 == 0 ? 1 : 0;
               }
            }

            if (this.wheelScrollDirectionSetting.equals("Inverted") || getWheelScrollDirectionSetting(this).equals("Position Aware Inverted")) {
               intValue2 = intValue2 == 0 ? 1 : 0;
            }

            ItemStack stack = slot2.getStack();
            if (stack.isEmpty()) {
               return true;
            } else {
               ItemStack cursorStack = handledScreen2.getScreenHandler().getCursorStack();
               if (!cursorStack.isEmpty() && this.testItemStack(stack, cursorStack)) {
                  return true;
               } else if (this.testSlot(slot2)) {
                  this.updateStateForHandledScreen8(handledScreen2, slot2, Math.abs(doubleState2), (intValue2 != 0), cursorStack);

                  return true;
               } else {
                  if (intValue2 != 0) {
                     this.updateStateForHandledScreen3(handledScreen2, slot2, Math.abs(doubleState2), cursorStack);
                  } else {
                     this.updateStateForHandledScreen2(handledScreen2, slot2, Math.abs(doubleState2), cursorStack);
                  }

                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   public MouseTweaksModule() {
      super("Mouse Tweaks", "Adds Mouse Tweaks inventory controls", ModuleCategory.PLAYER);

      this.rMBTweakSetting = new BooleanSetting("RMB Tweak", true);
      this.lMBTweakWithItemSetting = new BooleanSetting("LMB Tweak With Item", true);
      this.lMBTweakWithoutItemSetting = new BooleanSetting("LMB Tweak Without Item", true);
      this.wheelTweakSetting = new BooleanSetting("Wheel Tweak", true);
      this.wheelSearchOrderSetting = new ChoiceSetting("Wheel Search Order", "Last to First", "First to Last", "Last to First");
      String[] stringArray = new String[4];

      stringArray[0] = "Normal";
      stringArray[1] = "Inverted";
      stringArray[2] = "Position Aware";
      stringArray[3] = "Position Aware Inverted";
      this.wheelScrollDirectionSetting = new ChoiceSetting("Wheel Scroll Direction", "Normal", stringArray);

      String[] stringArray2 = new String[]{"Proportional", null};

      stringArray2[1] = "Always One";
      this.scrollItemScalingSetting = new ChoiceSetting("Scroll Item Scaling", "Proportional", stringArray2);
      Setting[] settingArray = new Setting[7];

      settingArray[0] = this.rMBTweakSetting;
      settingArray[1] = this.lMBTweakWithItemSetting;

      settingArray[2] = this.lMBTweakWithoutItemSetting;
      settingArray[3] = this.wheelTweakSetting;
      settingArray[4] = this.wheelSearchOrderSetting;

      settingArray[5] = this.wheelScrollDirectionSetting;
      settingArray[6] = this.scrollItemScalingSetting;
      this.addSettings(settingArray);
   }

   public static boolean getBooleanState(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.booleanState;
   }

   @Override
   public void onDisable() {
      this.updateState();
   }

   public static boolean getBooleanState3(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.booleanState3;
   }

   public static BooleanSetting getLMBTweakWithoutItemSetting(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.lMBTweakWithoutItemSetting;
   }

   public boolean testHandledScreen3(HandledScreen handledScreen2, int intValue) {
      if (handledScreen2 != getHandledScreen(this)) {
         return false;
      } else {
         byte byteValue;
         label64: {
            if (!(intValue == 0 && getBooleanState3(this))) {
               if (intValue != 1 || !getBooleanState(this)) {
                  byteValue = 0;
                  break label64;
               }
            }

            byteValue = 1;
         }

         byte byteValue2 = byteValue;
         if (intValue == 0) {
            this.booleanState3 = false;
         }

         if (intValue == 1) {
            setBooleanState(this, false);
         }

         return (byteValue2 != 0);
      }
   }

   private Slot invokeGetSlotAt(HandledScreen handledScreen2, double doubleValue, double doubleValue2) {
      return ((HandledScreenAccessor)handledScreen2).invokeGetSlotAt(doubleValue, doubleValue2);
   }

   public static void setBooleanState2(MouseTweaksModule mouseTweaksModule, boolean booleanState22) {
      mouseTweaksModule.booleanState2 = booleanState22;
   }

   public static ChoiceSetting getWheelScrollDirectionSetting(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.wheelScrollDirectionSetting;
   }

   private void updateStateForHandledScreen(HandledScreen handledScreen2) {
      if ((handledScreen2 != getHandledScreen(this))) {
         this.updateState();
         setHandledScreen(this, handledScreen2);
      }
   }

   private Slot computeSlotForHandledScreen(HandledScreen handledScreen2, Slot slot2) {
      DefaultedList slots = handledScreen2.getScreenHandler().slots;
      int intValue = this.wheelSearchOrderSetting.equals("First to Last") ? 0 : slots.size() - 1;
      int intValue2;
      if (getWheelSearchOrderSetting(this).equals("First to Last")) {
         intValue2 = slots.size();
      } else {
         intValue2 = -1;
      }

      int intValue22 = intValue2;
      byte byteValue;
      if (this.wheelSearchOrderSetting.equals("First to Last")) {
         byteValue = 1;
      } else {
         byteValue = -1;
      }

      byte byteValue2 = byteValue;
      ItemStack stack = slot2.getStack();
      int intValue3 = intValue;

      while (intValue3 != intValue22) {
         Slot slot3 = (Slot)slots.get(intValue3);
         if (this.testSlot2(slot3) != this.testSlot2(slot2)) {
            if (slot3.hasStack()) {
               if (this.testItemStack(stack, slot3.getStack())) {
                  return slot3;
               }
            }
         }

         intValue3 += byteValue2;
      }

      return null;
   }

   private List computeListForHandledScreen2(HandledScreen handledScreen2, Slot slot2, int intValue, boolean booleanValue) {
      ArrayList arrayList = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      ItemStack stack = slot2.getStack();
      int intValue2 = intValue;
      Iterator iterator = InventorySlotAccess.getSlots(handledScreen2.getScreenHandler()).iterator();

      while (iterator.hasNext()) {
         Slot slot3 = (Slot)iterator.next();
         if (slot3 != slot2 && this.testSlot2(slot3) != this.testSlot2(slot2) && !this.testSlot(slot3)) {
            ItemStack stack2 = slot3.getStack();
            if (stack2.isEmpty()) {
               if (slot3.canInsert(stack)) {
                  ThreadLocalRandom.current().nextInt(14);
                  arrayList2.add(slot3);
               }
            } else if (this.testItemStack(stack, stack2) && stack2.getCount() < slot3.getMaxItemCount(stack2)) {
               arrayList.add(slot3);
               intValue2 -= Math.min(intValue2, slot3.getMaxItemCount(stack2) - stack2.getCount());
               if (intValue2 <= 0) {
                  return arrayList;
               }
            }
         }
      }

      iterator = arrayList2.iterator();

      while (iterator.hasNext()) {
         Slot slot4 = (Slot)iterator.next();
         arrayList.add(slot4);
         intValue2 -= Math.min(intValue2, slot4.getMaxItemCount(stack));
         if (intValue2 <= 0) {
            break;
         }
      }

      ArrayList arrayList3;
      if (booleanValue && intValue2 > 0) {
         arrayList3 = null;
      } else {
         arrayList3 = arrayList;
      }

      return arrayList3;
   }

   public static ChoiceSetting getWheelSearchOrderSetting(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.wheelSearchOrderSetting;
   }

   public static void setBooleanState(MouseTweaksModule mouseTweaksModule, boolean booleanState4) {
      mouseTweaksModule.booleanState = booleanState4;
   }

   private boolean testSlot(Slot slot2) {
      String simpleName = slot2.getClass().getSimpleName();
      if (!simpleName.contains("Result")) {
         ThreadLocalRandom.current().nextInt(14);
         if (!simpleName.contains("Output")) {
            return false;
         }
      }

      ThreadLocalRandom.current().nextInt(10);
      return true;
   }

   public static BooleanSetting getWheelTweakSetting(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.wheelTweakSetting;
   }

   public static BooleanSetting getRMBTweakSetting(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.rMBTweakSetting;
   }

   private void updateStateForHandledScreen2(HandledScreen handledScreen2, Slot slot2, int intValue, ItemStack itemStack) {
      ItemStack stack = slot2.getStack();
      int intValue2 = slot2.getMaxItemCount(stack) - stack.getCount();
      int intValue3 = Math.min(intValue, intValue2);

      while (intValue3 > 0) {
         int count = 10;
         ThreadLocalRandom.current().nextInt(3);

         Slot slot3 = this.computeSlotForHandledScreen(handledScreen2, slot2);
         if (slot3 == null) {
            return;
         }

         ItemStack stack2 = slot3.getStack();
         if (!slot2.canInsert(stack2)) {
            return;
         }

         if (!itemStack.isEmpty()) {
            if (!slot3.canInsert(itemStack)) {
               return;
            }
         }

         if (!itemStack.isEmpty()) {
            count = (((byte)1));
         } else {
            count = (((byte)0));
         }

         int count3 = count;

         byte byteValue = 1;
         if (itemStack.isEmpty()) {
            count = stack2.getCount();

            if (count == 1) {
               byteValue = 0;
            }
         }

         this.updateStateForHandledScreen4(handledScreen2, slot3, byteValue, SlotActionType.PICKUP);
         int count2 = handledScreen2.getScreenHandler().getCursorStack().getCount();
         int intValue4 = Math.min(count2, intValue3);
         if (intValue4 == count2) {
            this.updateStateForHandledScreen4(handledScreen2, slot2, 0, InventorySlotAccess.getPICKUP());
         } else {
            for (int intValue5 = 0; intValue5 < intValue4; intValue5++) {
               this.updateStateForHandledScreen6(handledScreen2, slot2);
            }
         }

         intValue3 -= intValue4;
         int intValue6 = !handledScreen2.getScreenHandler().getCursorStack().isEmpty() ? 1 : 0;
         if (count3 != 0 || intValue6 != 0) {
            byte byteValue2;
            if (count3 != 0 && intValue6 != 0) {
               byteValue2 = 1;
            } else {
               byteValue2 = 0;
            }

            byte byteValue22 = byteValue2;
            this.updateStateForHandledScreen4(handledScreen2, slot3, byteValue22, SlotActionType.PICKUP);
         }
      }
   }

   private void updateState() {
      this.handledScreen = null;
      this.slot = null;

      setBooleanState3(this, false);
      setBooleanState(this, false);
      setBooleanState2(this, false);

      this.doubleState = (0.0);
   }

   private boolean testItemStack(ItemStack itemStack, ItemStack itemStack2) {
      if (!itemStack.isEmpty()) {
         if (!itemStack2.isEmpty()) {
            if (!ItemStack.areItemsAndComponentsEqual(itemStack, itemStack2)) {
               return false;
            }
         }
      }

      return true;
   }

   private void updateStateForHandledScreen3(HandledScreen handledScreen2, Slot slot2, int intValue, ItemStack itemStack) {
      ItemStack stack = slot2.getStack();
      if (!itemStack.isEmpty()) {
         if (this.testItemStack(stack, itemStack)) {
            return;
         }

         ThreadLocalRandom.current().nextInt(17);
      } else {
         ThreadLocalRandom.current().nextInt(11);
      }

      if (itemStack.isEmpty() || slot2.canInsert(itemStack)) {
         List list = this.computeListForHandledScreen(handledScreen2, slot2, intValue);
         if (!list.isEmpty()) {
            byte byteValue;
            if (!itemStack.isEmpty()) {
               byteValue = 1;
            } else {
               byteValue = 0;
            }

            byte byteValue2 = byteValue;

            byteValue = 1;

            byte byteValue3 = 1;
            if (itemStack.isEmpty()) {
               if (stack.getCount() <= intValue) {
                  byteValue3 = 0;
               }
            }

            this.updateStateForHandledScreen4(handledScreen2, slot2, byteValue3, InventorySlotAccess.getPICKUP());
            int intValue2 = Math.min(intValue, handledScreen2.getScreenHandler().getCursorStack().getCount());
            ItemStack cursorStack = handledScreen2.getScreenHandler().getCursorStack();

            for (Slot slot3 : (java.lang.Iterable<Slot>)(java.lang.Iterable<?>)(list)) {
               int intValue3 = Math.min(intValue2, slot3.getMaxItemCount(cursorStack) - slot3.getStack().getCount());

               for (int intValue4 = 0; intValue4 < intValue3; intValue4++) {
                  this.updateStateForHandledScreen6(handledScreen2, slot3);
               }

               intValue2 -= intValue3;
               if (intValue2 <= 0) {
                  break;
               }
            }

            int intValue5 = !handledScreen2.getScreenHandler().getCursorStack().isEmpty() ? 1 : 0;
            if (byteValue2 != 0 || intValue5 != 0) {
               label98: {
                  if (byteValue2 != 0) {
                     if (intValue5 != 0) {
                        byteValue = 1;
                        break label98;
                     }
                  }

                  byteValue = 0;
               }

               byte byteValue4 = byteValue;
               this.updateStateForHandledScreen4(handledScreen2, slot2, byteValue4, InventorySlotAccess.getPICKUP());
            }
         }
      }
   }

   private void updateStateForHandledScreen4(HandledScreen handledScreen2, Slot slot2, int intValue, SlotActionType slotActionType) {
      if (slot2 != null) {
         ThreadLocalRandom.current().nextInt(5);

         if (InventorySlotAccess.getPlayer(mc) != null) {
            if (InventorySlotAccess.getInteractionManager(mc) != null) {
               InventorySlotAccess.getInteractionManager(mc).clickSlot(InventorySlotAccess.getSyncId(handledScreen2.getScreenHandler()), InventorySlotAccess.getId(slot2), intValue, slotActionType, mc.player);
               return;
            }
         }
      }
   }

   public void updateStateForHandledScreen5(HandledScreen handledScreen2, double doubleValue, double doubleValue2, int intValue) {
      this.updateStateForHandledScreen(handledScreen2);
      setSlot(this, this.invokeGetSlotAt(handledScreen2, doubleValue, doubleValue2));
      ItemStack cursorStack = handledScreen2.getScreenHandler().getCursorStack();
      if (intValue == 0) {
         setBooleanState3(this, ((cursorStack.isEmpty() && (this.lMBTweakWithItemSetting.isOn() || this.lMBTweakWithoutItemSetting.isOn()) ? 1 : 0) != 0));
      } else {
         if (intValue == 1) {
            byte byteValue;
            label49: {
               if (!cursorStack.isEmpty()) {
                  if (getRMBTweakSetting(this).isOn()) {
                     byteValue = 1;
                     break label49;
                  }

                  byteValue = 19;
                  ThreadLocalRandom.current().nextInt(14);
               }

               byteValue = 0;
            }

            setBooleanState(this, (byteValue != 0));

            setBooleanState2(this, false);
         }
      }
   }

   public static double getDoubleState(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.doubleState;
   }

   private void updateStateForHandledScreen6(HandledScreen handledScreen2, Slot slot2) {
      this.updateStateForHandledScreen4(handledScreen2, slot2, 1, InventorySlotAccess.getPICKUP());
   }

   public static void setHandledScreen(MouseTweaksModule mouseTweaksModule, HandledScreen handledScreen2) {
      mouseTweaksModule.handledScreen = handledScreen2;
   }

   public static HandledScreen<?> getHandledScreen(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.handledScreen;
   }

   private boolean testSlot2(Slot slot2) {
      if (InventorySlotAccess.getPlayer(mc) != null) {
         if (slot2.inventory == InventorySlotAccess.getPlayer(mc).getInventory()) {
            return true;
         }
      }

      return false;
   }

   public static ChoiceSetting getScrollItemScalingSetting(MouseTweaksModule mouseTweaksModule) {
      return mouseTweaksModule.scrollItemScalingSetting;
   }

   private void updateStateForHandledScreen7(HandledScreen handledScreen2, Slot slot2) {
      if (slot2 != null) {
         ItemStack cursorStack = handledScreen2.getScreenHandler().getCursorStack();
         if (!(cursorStack.isEmpty())) {
            ThreadLocalRandom.current().nextInt(7);

            ItemStack stack = slot2.getStack();
            if (!this.testSlot(slot2)) {
               if (slot2.canInsert(cursorStack)) {
                  if (!stack.isEmpty()) {
                     if (!this.testItemStack(stack, cursorStack)) {
                        return;
                     }
                  }

                  ThreadLocalRandom.current().nextInt(16);
                  if (stack.getCount() >= slot2.getMaxItemCount(cursorStack)) {
                     return;
                  }

                  this.updateStateForHandledScreen6(handledScreen2, slot2);
                  return;
               }
            }
         }
      }
   }

   private void updateStateForHandledScreen8(HandledScreen handledScreen2, Slot slot2, int intValue, boolean booleanValue, ItemStack itemStack) {
      ItemStack stack = slot2.getStack();
      if (!booleanValue) {
         if (itemStack.isEmpty()) {
            return;
         }
      }

      if (!itemStack.isEmpty()) {
         if (!slot2.canInsert(itemStack)) {
            return;
         }
      }

      if (!itemStack.isEmpty()) {
         int intValue2 = 0;

         while (intValue2 < intValue) {
            this.updateStateForHandledScreen4(handledScreen2, slot2, 0, SlotActionType.PICKUP);
            intValue2++;
         }
      } else {
         int intValue3 = 0;

         while (true) {
            if (intValue3 >= intValue) {
               return;
            }

            int count = stack.getCount();

            List list = this.computeListForHandledScreen2(handledScreen2, slot2, count, true);
            if (list == null) {
               return;
            }

            this.updateStateForHandledScreen4(handledScreen2, slot2, 0, InventorySlotAccess.getPICKUP());

            for (int intValue4 = 0; intValue4 < list.size(); intValue4++) {
               ThreadLocalRandom.current().nextInt(12);
               Slot slot3 = (Slot)list.get(intValue4);
               if (intValue4 == list.size() - 1) {
                  this.updateStateForHandledScreen4(handledScreen2, slot3, 0, InventorySlotAccess.getPICKUP());
               } else {
                  ThreadLocalRandom.current().nextInt(12);
                  int intValue5 = slot3.getMaxItemCount(slot3.getStack()) - slot3.getStack().getCount();
                  int intValue6 = 0;

                  while (intValue6 < intValue5) {
                     this.updateStateForHandledScreen6(handledScreen2, slot3);
                     intValue6++;
                  }
               }
            }

            intValue3++;
         }
      }
   }

   public boolean testHandledScreen4(HandledScreen handledScreen2, double doubleValue, double doubleValue2, int intValue, int intValue2) {
      this.updateStateForHandledScreen(handledScreen2);
      if (intValue != 0) {
         if (intValue != 1) {
            return false;
         }
      }

      Slot slot2 = this.invokeGetSlotAt(handledScreen2, doubleValue, doubleValue2);
      if (slot2 == this.slot) {
         return getBooleanState(this);
      } else {
         Slot slot3 = this.slot;
         setSlot(this, slot2);
         ItemStack cursorStack = handledScreen2.getScreenHandler().getCursorStack();
         if (getBooleanState(this)) {
            if (intValue == 1 && !this.booleanState2) {
               setBooleanState2(this, true);
               this.updateStateForHandledScreen6(handledScreen2, slot3);
            }
         }

         if (slot2 == null) {
            return false;
         } else if (intValue == 1) {
            if (!this.booleanState) {
               return false;
            } else {
               this.updateStateForHandledScreen7(handledScreen2, slot2);
               return true;
            }
         } else {
            if (intValue == 0) {
               if (getBooleanState3(this)) {
                  if (!cursorStack.isEmpty()) {
                     if (this.lMBTweakWithItemSetting.isOn()) {
                        if (slot2.hasStack()) {
                           ItemStack stack = slot2.getStack();
                           if (this.testItemStack(stack, cursorStack)) {
                              if (cursorStack.getCount() + stack.getCount() <= cursorStack.getMaxCount()) {
                                 this.updateStateForHandledScreen4(handledScreen2, slot2, 0, InventorySlotAccess.getPICKUP());
                                 if (!this.testSlot(slot2)) {
                                    this.updateStateForHandledScreen4(handledScreen2, slot2, 0, InventorySlotAccess.getPICKUP());
                                 }

                                 return true;
                              }
                           }

                           return false;
                        }

                        ThreadLocalRandom.current().nextInt(12);
                     }

                     return false;
                  }

                  if (getLMBTweakWithoutItemSetting(this).isOn()) {
                     if ((intValue2 & 1) != 0) {
                        if (slot2.hasStack()) {
                           this.updateStateForHandledScreen4(handledScreen2, slot2, 0, SlotActionType.QUICK_MOVE);

                           return true;
                        }
                     }
                  }

                  return false;
               }
            }

            return false;
         }
      }
   }
}
