package cc.mochi;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Iterator;
import net.fabricmc.loader.api.FabricLoader;

public final class ModMenuIntegration {
   public static void removeFromHiddenMods() {
      if (ClientCleanup.getBooleanState()) return;
      File directory = FabricLoader.getInstance().getConfigDir().toFile();
      File file = new File(directory, "modmenu.json");
      if (!directory.exists()) return;
      Gson gson = new GsonBuilder().setPrettyPrinting().create();
      JsonObject config = new JsonObject();
      if (file.exists()) {
         try (FileReader reader = new FileReader(file, StandardCharsetsAccess.getUTF_8())) {
            config = gson.fromJson(reader, JsonObject.class);
            if (config == null) config = new JsonObject();
         } catch (Exception ignored) {
            config = new JsonObject();
         }
      }
      if (!config.has("hidden_mods") || !config.get("hidden_mods").isJsonArray()) return;
      JsonArray hidden = config.getAsJsonArray("hidden_mods");
      boolean containsClient = false;
      for (JsonElement value : hidden) {
         if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()) {
            String id = value.getAsString();
            if (id.equals("cubes-without-borders") || id.equals("mochi")) containsClient = true;
         }
      }
      if (!containsClient) return;
      JsonArray remaining = new JsonArray();
      for (JsonElement value : hidden) {
         if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()) {
            String id = value.getAsString();
            if (id.equals("cubes-without-borders") || id.equals("mochi")) continue;
         }
         remaining.add(value);
      }
      if (remaining.isEmpty()) config.remove("hidden_mods");
      else config.add("hidden_mods", remaining);
      try (FileWriter writer = new FileWriter(file, java.nio.charset.StandardCharsets.UTF_8)) {
         gson.toJson(config, writer);
         writer.flush();
      } catch (IOException ignored) {
      }
   }
}
