package cc.mochi;

public class UiLayerAccess {
   public static UiLayer getMODAL() {
      return UiLayer.MODAL;
   }

   public static Icon getCLOSE() {
      return Icon.CLOSE;
   }

   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }

}
