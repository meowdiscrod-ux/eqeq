package cc.mochi;

import com.mojang.blaze3d.opengl.GlStateManager;
import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class RoundedRectShader {
   private static int vertexArrayId = -1;
   private static int vertexBufferId = -1;
   private static boolean initialized = false;

   private static final float[] QUAD_VERTICES = new float[]{((-1.0F)), ((-1.0F)), 1.0F, ((-1.0F)), 1.0F, 1.0F, ((-1.0F)), 1.0F};

   private static final int[] QUAD_INDICES = new int[]{0, 1, 2, 2, 3, 0};

   public static void draw(MatrixStack matrices, float x, float y, float width, float height, float radius, Color color) {
      drawRgba(
         matrices,
         x,
         y,
         width,
         height,
         radius,
         (float)color.getRed() / 255.0F,
         (float)color.getGreen() / 255.0F,
         (float)color.getBlue() / 255.0F,
         (float)color.getAlpha() / 255.0F
      );
   }

   public static void initialize() {
      if (!initialized) {
         ShaderProgramCache.loadProgram("rounded_rect", "shaders/gui/roundedrect.vsh", "shaders/gui/roundedrect.fsh");
         vertexArrayId = GL30.glGenVertexArrays();
         vertexBufferId = GL20.glGenBuffers();
         int intValue = GL20.glGenBuffers();
         GL30.glBindVertexArray(vertexArrayId);
         GL20.glBindBuffer(org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER, vertexBufferId);
         GL20.glBufferData(org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER, QUAD_VERTICES, org.lwjgl.opengl.GL15.GL_STATIC_DRAW);
         GL20.glBindBuffer(org.lwjgl.opengl.GL15.GL_ELEMENT_ARRAY_BUFFER, intValue);
         GL20.glBufferData(org.lwjgl.opengl.GL15.GL_ELEMENT_ARRAY_BUFFER, QUAD_INDICES, org.lwjgl.opengl.GL15.GL_STATIC_DRAW);
         GL20.glVertexAttribPointer(0, 2, org.lwjgl.opengl.GL11.GL_FLOAT, false, 8, 0L);
         GL20.glEnableVertexAttribArray(0);
         GL30.glBindVertexArray(0);
         initialized = true;
      }
   }

   public static void destroy() {
      if (vertexArrayId != -1) {
         GL30.glDeleteVertexArrays(vertexArrayId);
         vertexArrayId = -1;
      }

      if (vertexBufferId != -1) {
         GL20.glDeleteBuffers(vertexBufferId);
         vertexBufferId = -1;
      }

      initialized = false;
   }

   public static void drawRgba(MatrixStack matrices, float x, float y, float width, float height, float radius, float red, float green, float blue, float alpha) {
      if (!initialized) {
         initialize();
      }

      MinecraftClient.getInstance();
      int width2 = UiViewport.getWidth();
      int height2 = UiViewport.getHeight();
      GlStateManager._enableBlend();
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
      GlStateManager._disableDepthTest();
      GlStateManager._disableCull();
      ShaderProgramCache.bind("rounded_rect");
      ShaderProgramCache.uniform2f("rounded_rect", "u_resolution", (float)width2, (float)height2);
      ShaderProgramCache.uniform2f("rounded_rect", "u_position", x, y);
      ShaderProgramCache.uniform2f("rounded_rect", "u_size", width, height);
      ShaderProgramCache.uniform1f("rounded_rect", "u_radius", radius);
      ShaderProgramCache.uniform4f("rounded_rect", "u_color", red, green, blue, alpha);
      GL30.glBindVertexArray(vertexArrayId);
      GL20.glDrawElements(org.lwjgl.opengl.GL11.GL_TRIANGLES, 6, org.lwjgl.opengl.GL11.GL_UNSIGNED_INT, 0L);
      GL30.glBindVertexArray(0);
      ShaderProgramCache.unbind();
      GlStateManager._enableDepthTest();
      GlStateManager._enableCull();
      GlStateManager._disableBlend();
   }
}
