package cc.mochi;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class PlayerInteractionAccess {
   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static Direction getUP() {
      return Direction.UP;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static Block getCOBWEB() {
      return Blocks.COBWEB;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static Item getCOBWEB2() {
      return Items.COBWEB;
   }

   public static Block getWATER() {
      return Blocks.WATER;
   }

}
