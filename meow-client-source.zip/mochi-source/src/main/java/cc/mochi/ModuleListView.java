package cc.mochi;

import java.awt.Color;
import java.util.List;

public final class ModuleListView {
   private String string;

   private int intState;

   private final ScrollModel scrollModel = new ScrollModel();

   public static ScrollModel getScrollModel(ModuleListView moduleListView) {
      return moduleListView.scrollModel;
   }

   private static void updateStateForModule(Module module) {
      module.toggle();
      ClientSounds.updateState4();
   }

   public static void setIntState(ModuleListView moduleListView, int intState2) {
      moduleListView.intState = intState2;
   }

   public static void setString(ModuleListView moduleListView, String string2) {
      moduleListView.string = string2;
   }

   ModuleListView() {
      this.intState = -1;
      this.string = "";
   }

   void updateStateForUiContext(UiContext uiContext, ModuleBrowser moduleBrowser, Rect rect, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      if (getIntState(this) != ModuleBrowserStateAccess.getCounter(moduleBrowser)) {
         setIntState(this, moduleBrowser.counter);
         this.scrollModel.reset();
         uiContext.getAnimations().removeByPrefix("list.enter.");
      }

      String string2 = moduleBrowser.textInputModel.toString();
      if (!string2.equals(this.string)) {
         setString(this, string2);
         this.scrollModel.reset();
      }

      List list = moduleBrowser.computeList();
      boolean value2 = ClickGuiModule.getValue2();
      float floatValue2 = value2 ? 38.0F : 26.0F;
      float y = rect.getY() + 17.0F;
      String text = moduleBrowser.checkCondition() ? "Results" : ModuleBrowserStateAccess.getModuleCategory(moduleBrowser).getName();
      if (moduleBrowser.checkCondition()) {
         uiContext.drawVerticallyCenteredText(text, rect.getX() + 12.0F, y - 3.0F, TextStyle.HEADING, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));
         String text2 = computeString(list.size(), "match", "matches") + " for “" + uiContext.ellipsize(ModuleBrowserStateAccess.getTextInputModel(moduleBrowser).toString().trim(), TextStyle.CAPTION, 90.0F) + "”";
         uiContext.drawVerticallyCenteredText(text2, rect.getX() + 12.0F, y + 12.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
      } else {
         uiContext.drawVerticallyCenteredText(text, rect.getX() + 12.0F, y, TextStyle.HEADING, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));
      }

      Rect rect2 = new Rect(rect.right() - 12.0F - 74.0F, y - 8.0F, 74.0F, 18.0F);
      ChoiceDropdown.updateStateForUiContext(uiContext, "list.filter", rect2, UiLayer.BASE, List.of("All", "On"), ModuleBrowserStateAccess.getBooleanState(moduleBrowser) ? 1 : 0, opacity, intValue -> updateStateForModuleBrowser(moduleBrowser, intValue));
      Rect rect3 = new Rect(rect.getX() + 6.0F, rect.getY() + 44.0F, rect.getWidth() - 12.0F, rect.getHeight() - 44.0F - 6.0F);
      if (list.isEmpty()) {
         String string5 = moduleBrowser.checkCondition()
            ? "Try another word, or search setting names in Click Gui settings."
            : (ModuleBrowserStateAccess.getBooleanState(moduleBrowser) ? "Nothing in " + ModuleBrowserStateAccess.getModuleCategory(moduleBrowser).getName() + " is on. Switch the filter to All to see every module." : "This category has no modules.");
         EmptyStateWidget.updateStateForUiContext(uiContext, rect3, moduleBrowser.checkCondition() ? Icon.SEARCH : Icon.GRID, moduleBrowser.checkCondition() ? "No matches" : "Nothing here", string5, opacity);
      } else {
         float contentHeight = 0.0F;
         ModuleCategory category = null;

         for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(list)) {
            if (moduleBrowser.checkCondition() && module.getCategory() != category) {
               category = module.getCategory();
               contentHeight += 20.0F;
            }

            contentHeight += floatValue2 + 4.0F;
         }

         float floatValue5 = this.scrollModel.update(uiContext, contentHeight, rect3.getHeight());
         uiContext.getInputRouter().addScrollRegion(rect3, UiLayer.BASE, getScrollModel(this)::scroll);
         float floatValue6 = contentHeight > rect3.getHeight() ? rect3.getWidth() - 9.0F : rect3.getWidth();
         uiContext.getUiRenderContext().pushClip(rect3.getX() - 2.0F, rect3.getY(), rect3.getWidth() + 4.0F, rect3.getHeight());
         float floatValue7 = rect3.getY() - floatValue5;
         category = null;
         int intValue2 = 0;

         for (Module module2 : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(list)) {
            if (moduleBrowser.checkCondition() && module2.getCategory() != category) {
               category = module2.getCategory();
               if (floatValue7 + 20.0F >= rect3.getY() && floatValue7 <= rect3.bottom()) {
                  SectionHeaderWidget.updateStateForUiContext(uiContext, rect3.getX() + 4.0F, floatValue7 + 10.0F + 1.0F, rect3.getWidth() - 8.0F, category.getName(), null, opacity);
               }

               floatValue7 += 20.0F;
            }

            Rect rect4 = new Rect(rect3.getX(), floatValue7, floatValue6, floatValue2);
            if (rect4.bottom() >= rect3.getY() && rect4.getY() <= rect3.bottom()) {
               float floatValue8 = uiContext.getAnimations().exponential("list.enter." + module2.getName(), 0.0F, 1.0F, 0.06F + (float)Math.min(intValue2, 12) * 0.012F);
               this.updateStateForUiContext2(uiContext, moduleBrowser, module2, rect4, rect3, value2, opacity * floatValue8, (1.0F - floatValue8) * 10.0F);
               intValue2++;
            }

            floatValue7 += floatValue2 + 4.0F;
         }

         uiContext.getUiRenderContext().popClip();
         getScrollModel(this).drawScrollbar(uiContext, rect3, contentHeight, opacity);
      }
   }

   private static void updateStateForModuleBrowser(ModuleBrowser moduleBrowser, int intValue) {
      moduleBrowser.booleanState = intValue == 1;
      moduleBrowser.counter++;
   }

   private static void updateStateForKeybindSetting(KeybindSetting keybindSetting, ModuleBrowser moduleBrowser, Module module, int intValue, double doubleValue, double doubleValue2) {
      if (intValue == 1) {
         keybindSetting.setKeyCode(-1);
         ClientSounds.updateState5();
      } else if (intValue == 0) {
         moduleBrowser.keybindCapture.updateStateForKeybindSetting(keybindSetting, module.getName());
      }
   }

   private static void updateStateForModule2(Module module2, ModuleBrowser moduleBrowser, KeybindSetting keybindSetting, int intValue, double doubleValue, double doubleValue2) {
      switch (intValue) {
         case 0:
            module2.toggle();
            ClientSounds.updateState4();
            break;
         case 1:
            if (ModuleBrowserStateAccess.getModule2(moduleBrowser) != module2) {
               ClientSounds.updateState5();
            }

            moduleBrowser.updateStateForModule(module2);
            break;
         case 2:
            if (keybindSetting != null) {
               moduleBrowser.keybindCapture.updateStateForKeybindSetting(keybindSetting, module2.getName());
            }
      }
   }

   private static String computeString(int intValue, String string2, String string3) {
      return intValue + " " + (intValue == 1 ? string2 : string3);
   }

   public static int getIntState(ModuleListView moduleListView) {
      return moduleListView.intState;
   }

   private void updateStateForUiContext2(UiContext uiContext, ModuleBrowser moduleBrowser, Module module2, Rect rect, Rect rect2, boolean booleanValue, float floatValue, float offsetY) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Rect rect3 = rect.translate(0.0F, offsetY);
      Rect rect4 = rect.intersection(rect2);
      String string2 = "list." + module2.getName();
      boolean hovered = uiContext.isHovered(rect4, UiLayer.BASE);
      float floatValue3 = uiContext.animateHover(string2 + ".h", hovered);
      float progress = uiContext.animateToggle(string2 + ".on", module2.isEnabled(), 0.045F);
      float floatValue5 = uiContext.animateToggle(string2 + ".sel", ModuleBrowserStateAccess.getModule2(moduleBrowser) == module2, 0.035F);
      PanelRenderer.updateStateForUiContext7(uiContext, rect3, 10.0F, floatValue3, floatValue);
      PanelRenderer.updateStateForUiContext(uiContext, rect3, 10.0F, floatValue5, floatValue);
      if (progress > 0.01F) {
         if (ClickGuiModule.checkCondition3() && uiContext.getUiRenderContext().supportsEffects() && cc.mochi.CamouflageRenderer.computeInt() != 0) {
            uiContext.getUiRenderContext().pushOpacity(progress * floatValue);
            uiContext.getUiRenderContext().drawCamouflage(rect3.getX(), rect3.getY(), rect3.getWidth(), rect3.getHeight(), 10.0F);
            uiContext.getUiRenderContext().fillRoundedRect(rect3.getX(), rect3.getY(), rect3.getWidth(), rect3.getHeight(), 10.0F, UiContext.multiplyAlpha(Color.BLACK, 0.34F));
            uiContext.getUiRenderContext().popOpacity();
         } else {
            uiContext.getUiRenderContext().fillHorizontalGradient(rect3.getX(), rect3.getY(), rect3.getWidth(), rect3.getHeight(), 10.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.2F * progress * floatValue), UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.0F));
         }

         uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(1.0F) * progress * floatValue);
         float height = (rect3.getHeight() - 14.0F) * (0.4F + 0.6F * progress);
         uiContext.getUiRenderContext().fillRoundedRect(rect3.getX() + 3.0F, rect3.centerY() - height / 2.0F, 2.4F, height, 1.2F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), progress * floatValue));
         uiContext.getUiRenderContext().popBloom();
      }

      float floatValue7 = rect3.right() - 10.0F;
      Rect rect5 = PanelHeaderRenderer.createRect(floatValue7, rect3.centerY());
      PanelHeaderRenderer.updateStateForUiContext(uiContext, string2 + ".switch", rect5, module2.isEnabled(), floatValue3, floatValue);
      KeybindSetting keybind = module2.getKeybind();
      String string3 = keybind == null ? null : KeybindCapture.computeString(keybind.getKeyCode());
      boolean booleanValue2 = keybind != null && ModuleBrowserStateAccess.getKeybindCapture(moduleBrowser).testKeybindSetting(keybind);
      float floatValue8 = rect5.getX() - 8.0F;
      Rect rect6 = null;
      if (keybind != null && (string3 != null || booleanValue2 || floatValue3 > 0.05F)) {
         float floatValue9 = LabelWidgets.max2(uiContext, string3 == null ? "Bind" : string3);
         rect6 = new Rect(rect5.getX() - 6.0F - floatValue9, rect3.centerY() - 7.5F, floatValue9, 15.0F);
         KeybindCaptureState keybindCaptureState = booleanValue2 ? KeybindCaptureState.CAPTURING : (string3 == null ? KeybindCaptureState.EMPTY : KeybindCaptureState.BOUND);
         float floatValue10 = uiContext.animateHover(string2 + ".chip", uiContext.isHovered(rect6.intersection(rect2), UiLayer.BASE));
         float floatValue11 = string3 == null && !booleanValue2 ? floatValue3 : 1.0F;
         LabelWidgets.updateStateForUiContext(uiContext, rect6, string3, keybindCaptureState, floatValue10, floatValue * floatValue11);
         if (keybind.isHoldMode() && string3 != null) {
            uiContext.drawRightAlignedText("hold", rect6.getX() - 4.0F, rect3.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), floatValue));
         }

         if (string3 != null || booleanValue2) {
            floatValue8 = rect6.getX() - 6.0F;
         }
      }

      float x = rect3.getX() + 13.0F;
      float maxWidth = Math.max(20.0F, floatValue8 - x);
      Color color = UiContext.blendColors(UiContext.blendColors(themeSnapshot2.getSecondaryText2(), themeSnapshot2.getPrimaryText(), 0.75F + 0.25F * floatValue3), themeSnapshot2.getPrimaryText(), progress);
      String description = module2.getDescription();
      if (booleanValue && description != null && !description.isBlank()) {
         uiContext.drawVerticallyCenteredText(uiContext.ellipsize(module2.getName(), TextStyle.STRONG, maxWidth), x, rect3.getY() + 13.0F, TextStyle.STRONG, UiContext.multiplyAlpha(color, floatValue));
         uiContext.drawVerticallyCenteredText(uiContext.ellipsize(description, TextStyle.SMALL, maxWidth), x, rect3.getY() + 26.0F, TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), 0.85F * floatValue));
      } else {
         uiContext.drawVerticallyCenteredText(uiContext.ellipsize(module2.getName(), TextStyle.STRONG, maxWidth), x, rect3.centerY(), TextStyle.STRONG, UiContext.multiplyAlpha(color, floatValue));
      }

      uiContext.getInputRouter().addPressRegion(rect4, UiLayer.BASE, (intValue, doubleValue, doubleValue2) -> updateStateForModule2(module2, moduleBrowser, keybind, intValue, doubleValue, doubleValue2));
      uiContext.getInputRouter().addClickRegion(rect5.expand(3.0F).intersection(rect2), UiLayer.BASE, () -> updateStateForModule(module2));
      if (rect6 != null && (string3 != null || booleanValue2 || floatValue3 > 0.5F)) {
         uiContext.getInputRouter().addPressRegion(rect6.intersection(rect2), UiLayer.BASE, (intValue2, doubleValue3, doubleValue4) -> updateStateForKeybindSetting(keybind, moduleBrowser, module2, intValue2, doubleValue3, doubleValue4));
      }
   }
}
