package cc.mochi;

import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.DrawContext;

/**
 * Meow Client visual effects: falling snow + particles orbiting the cursor.
 * Draws on top of every screen (main menu, click GUI, inventory, etc).
 */
public final class MeowEffects {
   // ---- tweakables ----
   public static boolean SNOW_ENABLED = true;
   public static boolean ORBIT_ENABLED = true;
   private static final int SNOW_COUNT = 90;
   private static final int ORBIT_DOTS = 4;
   private static final int TRAIL_LENGTH = 7;
   private static final float ORBIT_RADIUS = 11.0F;
   private static final float ORBIT_SPEED = 3.2F;       // radians per second
   private static final int ORBIT_COLOR = 0xFF9ED8;     // soft pink
   private static final int SNOW_COLOR = 0xFFFFFF;

   private static final Random RANDOM = new Random();
   private static final float[] fx = new float[SNOW_COUNT];     // x as 0..1
   private static final float[] fy = new float[SNOW_COUNT];     // y as 0..1
   private static final float[] fSpeed = new float[SNOW_COUNT]; // screen heights / sec
   private static final float[] fSway = new float[SNOW_COUNT];
   private static final float[] fPhase = new float[SNOW_COUNT];
   private static final int[] fSize = new int[SNOW_COUNT];
   private static final int[] fAlpha = new int[SNOW_COUNT];
   private static boolean snowInitialised = false;
   private static long lastNanos = 0L;
   private static float orbitAngle = 0.0F;
   private static int lastMouseX = -1;
   private static int lastMouseY = -1;
   private static boolean mouseMoved = false;   // orbit stays hidden until a pointer actually exists (touch launchers)
   private static final Map<Object, Boolean> hooked = new WeakHashMap<>();

   private MeowEffects() {
   }

   public static void register() {
      ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
         // a screen can be re-initialised (resize); hook it only once so effects never double up
         if (hooked.put(screen, Boolean.TRUE) == null) {
            ScreenEvents.afterRender(screen).register((s, drawContext, mouseX, mouseY, tickDelta) ->
               render(drawContext, mouseX, mouseY, s.width, s.height));
         }
      });
   }

   private static void initSnow() {
      for (int i = 0; i < SNOW_COUNT; i++) {
         respawn(i, true);
      }
      snowInitialised = true;
   }

   private static void respawn(int i, boolean anywhere) {
      fx[i] = RANDOM.nextFloat();
      fy[i] = anywhere ? RANDOM.nextFloat() : -0.02F - RANDOM.nextFloat() * 0.1F;
      fSize[i] = RANDOM.nextFloat() < 0.2F ? 3 : (RANDOM.nextFloat() < 0.5F ? 2 : 1);
      fSpeed[i] = 0.05F + RANDOM.nextFloat() * 0.07F + fSize[i] * 0.015F;
      fSway[i] = 0.01F + RANDOM.nextFloat() * 0.025F;
      fPhase[i] = RANDOM.nextFloat() * 6.2831855F;
      fAlpha[i] = 110 + RANDOM.nextInt(120);
   }

   public static void render(DrawContext ctx, int mouseX, int mouseY, int width, int height) {
      if (width <= 0 || height <= 0) {
         return;
      }
      long now = System.nanoTime();
      float dt = lastNanos == 0L ? 0.016F : (now - lastNanos) / 1.0E9F;
      lastNanos = now;
      if (dt > 0.1F) {
         dt = 0.1F; // avoid big jumps after lag spikes / tab-out
      }
      float time = now / 1.0E9F;

      if (SNOW_ENABLED) {
         renderSnow(ctx, width, height, dt, time);
      }
      if (mouseX != lastMouseX || mouseY != lastMouseY) {
         if (lastMouseX != -1) {
            mouseMoved = true;
         }
         lastMouseX = mouseX;
         lastMouseY = mouseY;
      }
      if (ORBIT_ENABLED && mouseMoved) {
         orbitAngle += ORBIT_SPEED * dt;
         if (orbitAngle > 6.2831855F) {
            orbitAngle -= 6.2831855F;
         }
         renderOrbit(ctx, mouseX, mouseY);
      }
   }

   private static void renderSnow(DrawContext ctx, int width, int height, float dt, float time) {
      if (!snowInitialised) {
         initSnow();
      }
      for (int i = 0; i < SNOW_COUNT; i++) {
         fy[i] += fSpeed[i] * dt;
         if (fy[i] > 1.03F) {
            respawn(i, false);
         }
         float swayX = (float)Math.sin(time * 0.9F + fPhase[i]) * fSway[i];
         int px = Math.round((fx[i] + swayX) * width);
         int py = Math.round(fy[i] * height);
         int size = fSize[i];
         int color = (fAlpha[i] << 24) | SNOW_COLOR;
         if (size >= 3) {
            // tiny plus-shaped flake
            ctx.fill(px - 1, py, px + 2, py + 1, color);
            ctx.fill(px, py - 1, px + 1, py + 2, color);
         } else {
            ctx.fill(px, py, px + size, py + size, color);
         }
      }
   }

   private static void renderOrbit(DrawContext ctx, int mouseX, int mouseY) {
      for (int d = 0; d < ORBIT_DOTS; d++) {
         float base = orbitAngle + d * (6.2831855F / ORBIT_DOTS);
         for (int t = TRAIL_LENGTH - 1; t >= 0; t--) {
            float a = base - t * 0.16F;
            float fade = 1.0F - (float)t / TRAIL_LENGTH;
            int px = Math.round(mouseX + (float)Math.cos(a) * ORBIT_RADIUS);
            int py = Math.round(mouseY + (float)Math.sin(a) * ORBIT_RADIUS);
            int alpha = (int)(230.0F * fade * fade);
            int color = (alpha << 24) | ORBIT_COLOR;
            int size = t == 0 ? 3 : (t < 3 ? 2 : 1);
            int off = size / 2;
            ctx.fill(px - off, py - off, px - off + size, py - off + size, color);
         }
      }
   }
}
