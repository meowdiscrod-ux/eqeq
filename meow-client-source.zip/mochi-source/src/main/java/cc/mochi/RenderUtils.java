package cc.mochi;

import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.awt.Color;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class RenderUtils {
   public static boolean booleanState = true;

   private static void updateStateForDrawContext(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6) {
      float intValue32 = (float)intValue3;

      for (int intValue7 = 0; intValue7 < intValue3; intValue7++) {
         for (int intValue8 = 0; intValue8 < intValue3; intValue8++) {
            float floatValue2 = (float)Math.sqrt((double)(intValue7 * intValue7 + intValue8 * intValue8));
            if (floatValue2 <= intValue32) {
               int intValue9 = intValue;
               int intValue22 = intValue2;
               switch (intValue6) {
                  case 0:
                     intValue9 = intValue - intValue7;
                     intValue22 = intValue2 - intValue8;
                     break;
                  case 1:
                     intValue9 = intValue + intValue7;
                     intValue22 = intValue2 - intValue8;
                     break;
                  case 2:
                     intValue9 = intValue - intValue7;
                     intValue22 = intValue2 + intValue8;
                     break;
                  case 3:
                     intValue9 = intValue + intValue7;
                     intValue22 = intValue2 + intValue8;
               }

               float floatValue3 = (float)intValue8 / (float)intValue3;
               int intValue11 = computeInt(intValue4, intValue5, floatValue3);
               float floatValue4 = 1.0F;
               if (floatValue2 > intValue32 - 1.0F) {
                  floatValue4 = Math.max(0.0F, intValue32 - floatValue2);
               }

               int intValue12 = intValue11 >> 24 & 0xFF;
               int intValue13 = (int)((float)intValue12 * floatValue4);
               int intValue14 = intValue13 << 24 | intValue11 & 16777215;
               drawContext.fill(intValue9, intValue22, intValue9 + 1, intValue22 + 1, intValue14);
            }
         }
      }
   }

   public static void updateStateForDrawContext2(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4) {
      for (int intValue5 = -intValue3; intValue5 <= intValue3; intValue5++) {
         for (int intValue6 = -intValue3; intValue6 <= intValue3; intValue6++) {
            if (intValue6 * intValue6 + intValue5 * intValue5 <= intValue3 * intValue3) {
               drawContext.fill(intValue + intValue6, intValue2 + intValue5, intValue + intValue6 + 1, intValue2 + intValue5 + 1, intValue4);
            }
         }
      }
   }

   public static void resetBooleanState() {
      booleanState = false;
   }

   public static void updateStateForMatrixStack(MatrixStack matrixStack, Box box, Color color) {
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
      float floatValue = (float)color.getRed() / 255.0F;
      float floatValue2 = (float)color.getGreen() / 255.0F;
      float floatValue3 = (float)color.getBlue() / 255.0F;
      float floatValue4 = (float)color.getAlpha() / 255.0F;
      float minX = (float)box.minX;
      float minY = (float)box.minY;
      float minZ = (float)box.minZ;
      float maxX = (float)box.maxX;
      float maxY = (float)box.maxY;
      float maxZ = (float)box.maxZ;
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      BuiltBuffer builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }
   }

   public static void updateStateForDrawContext3(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6, int intValue7) {
      for (int intValue8 = 1; intValue8 <= intValue7; intValue8++) {
         int intValue9 = (int)((float)(intValue6 >> 24 & 0xFF) * (1.0F - (float)intValue8 / (float)intValue7) * 0.3F);
         int intValue10 = intValue9 << 24 | intValue6 & 16777215;
         updateStateForDrawContext11(drawContext, intValue - intValue8, intValue2 - intValue8, intValue3 + intValue8 * 2, intValue4 + intValue8 * 2, intValue5 + intValue8, intValue10);
      }
   }

   private static void updateStateForDrawContext4(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5) {
      float intValue32 = (float)intValue3;

      for (float floatValue2 = 0.0F; floatValue2 < (float)intValue3; floatValue2 += 0.5F) {
         for (float floatValue3 = 0.0F; floatValue3 < (float)intValue3; floatValue3 += 0.5F) {
            float floatValue4 = (float)Math.sqrt((double)(floatValue2 * floatValue2 + floatValue3 * floatValue3));
            if (floatValue4 <= intValue32) {
               int intValue6 = intValue;
               int intValue22 = intValue2;
               switch (intValue5) {
                  case 0:
                     intValue6 = intValue - (int)floatValue2;
                     intValue22 = intValue2 - (int)floatValue3;
                     break;
                  case 1:
                     intValue6 = intValue + (int)floatValue2;
                     intValue22 = intValue2 - (int)floatValue3;
                     break;
                  case 2:
                     intValue6 = intValue - (int)floatValue2;
                     intValue22 = intValue2 + (int)floatValue3;
                     break;
                  case 3:
                     intValue6 = intValue + (int)floatValue2;
                     intValue22 = intValue2 + (int)floatValue3;
               }

               float floatValue5 = computeFloat(floatValue2, floatValue3, intValue32);
               if (floatValue5 > 0.0F) {
                  int intValue8 = intValue4 >> 24 & 0xFF;
                  int intValue9 = (int)((float)intValue8 * floatValue5);
                  int intValue10 = intValue9 << 24 | intValue4 & 16777215;
                  drawContext.fill(intValue6, intValue22, intValue6 + 1, intValue22 + 1, intValue10);
               }
            }
         }
      }
   }

   public static void updateStateForMatrixStack2(MatrixStack matrixStack, Vec3d vec3d, Vec3d vec3d2, Color color) {
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
      float floatValue = (float)color.getRed() / 255.0F;
      float floatValue2 = (float)color.getGreen() / 255.0F;
      float floatValue3 = (float)color.getBlue() / 255.0F;
      float floatValue4 = (float)color.getAlpha() / 255.0F;
      bufferBuilder.vertex(positionMatrix, (float)vec3d.x, (float)vec3d.y, (float)vec3d.z).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, (float)vec3d2.x, (float)vec3d2.y, (float)vec3d2.z).color(floatValue, floatValue2, floatValue3, floatValue4);
      BuiltBuffer builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }
   }

   public static void updateStateForDrawContext5(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6, int intValue7) {
      drawContext.fillGradient(intValue + intValue5, intValue2, intValue + intValue3 - intValue5, intValue2 + intValue4, intValue6, intValue7);
      drawContext.fillGradient(intValue, intValue2 + intValue5, intValue + intValue5, intValue2 + intValue4 - intValue5, intValue6, intValue7);
      drawContext.fillGradient(intValue + intValue3 - intValue5, intValue2 + intValue5, intValue + intValue3, intValue2 + intValue4 - intValue5, intValue6, intValue7);
      updateStateForDrawContext(drawContext, intValue + intValue5, intValue2 + intValue5, intValue5, intValue6, intValue7, 0);
      updateStateForDrawContext(drawContext, intValue + intValue3 - intValue5, intValue2 + intValue5, intValue5, intValue6, intValue7, 1);
      updateStateForDrawContext(drawContext, intValue + intValue5, intValue2 + intValue4 - intValue5, intValue5, intValue6, intValue7, 2);
      updateStateForDrawContext(drawContext, intValue + intValue3 - intValue5, intValue2 + intValue4 - intValue5, intValue5, intValue6, intValue7, 3);
   }

   private static void updateStateForDrawContext6(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5) {
      float intValue32 = (float)intValue3;

      for (int intValue6 = 0; intValue6 < intValue3; intValue6++) {
         for (int intValue7 = 0; intValue7 < intValue3; intValue7++) {
            float floatValue2 = (float)Math.sqrt((double)(intValue6 * intValue6 + intValue7 * intValue7));
            if (floatValue2 <= intValue32) {
               int intValue8 = intValue;
               int intValue22 = intValue2;
               switch (intValue5) {
                  case 0:
                     intValue8 = intValue - intValue6;
                     intValue22 = intValue2 - intValue7;
                     break;
                  case 1:
                     intValue8 = intValue + intValue6;
                     intValue22 = intValue2 - intValue7;
                     break;
                  case 2:
                     intValue8 = intValue - intValue6;
                     intValue22 = intValue2 + intValue7;
                     break;
                  case 3:
                     intValue8 = intValue + intValue6;
                     intValue22 = intValue2 + intValue7;
               }

               float floatValue3 = 1.0F;
               if (floatValue2 > intValue32 - 1.0F) {
                  floatValue3 = Math.max(0.0F, intValue32 - floatValue2);
               }

               int intValue10 = intValue4 >> 24 & 0xFF;
               int intValue11 = (int)((float)intValue10 * floatValue3);
               int intValue12 = intValue11 << 24 | intValue4 & 16777215;
               drawContext.fill(intValue8, intValue22, intValue8 + 1, intValue22 + 1, intValue12);
            }
         }
      }
   }

   public static void updateStateForDrawContext7(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5) {
      drawContext.fill(intValue, intValue2, intValue + intValue3, intValue2 + intValue4, intValue5);
      int intValue6 = intValue5 & 16777215 | (intValue5 >> 24 & 0xFF) / 2 << 24;
      drawContext.fill(intValue - 1, intValue2, intValue, intValue2 + intValue4, intValue6);
      drawContext.fill(intValue + intValue3, intValue2, intValue + intValue3 + 1, intValue2 + intValue4, intValue6);
      drawContext.fill(intValue, intValue2 - 1, intValue + intValue3, intValue2, intValue6);
      drawContext.fill(intValue, intValue2 + intValue4, intValue + intValue3, intValue2 + intValue4 + 1, intValue6);
   }

   public static void updateStateForMatrixStack3(MatrixStack matrixStack, AwtFontRenderer awtFontRenderer, String string, int intValue, int intValue2, int intValue3, float floatValue) {
      Color color = new Color(intValue3, true);

      for (int intValue4 = 0; intValue4 < 4; intValue4++) {
         int alpha = 0;
         byte byteValue = 0;
         byte byteValue2 = 0;
         switch (intValue4) {
            case 0:
               alpha = (int)((float)color.getAlpha() * floatValue * 0.2F);
               byteValue = 1;
               byteValue2 = 1;
               break;
            case 1:
               alpha = (int)((float)color.getAlpha() * floatValue * 0.3F);
               byteValue = 1;
               byteValue2 = 0;
               break;
            case 2:
               alpha = (int)((float)color.getAlpha() * floatValue * 0.3F);
               byteValue = 0;
               byteValue2 = 1;
               break;
            case 3:
               alpha = color.getAlpha();
               byteValue = 0;
               byteValue2 = 0;
         }

         int rgb = new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
         awtFontRenderer.updateStateForMatrixStack2(matrixStack, string, (float)(intValue + byteValue), (float)(intValue2 + byteValue2), new Color(rgb, true));
      }
   }

   private RenderUtils() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void updateStateForMatrixStack4(MatrixStack matrixStack, Box box, Color color) {
      Matrix4f positionMatrix = matrixStack.peek().getPositionMatrix();
      BufferBuilder bufferBuilder = Tessellator.getInstance().begin(DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      float floatValue = (float)color.getRed() / 255.0F;
      float floatValue2 = (float)color.getGreen() / 255.0F;
      float floatValue3 = (float)color.getBlue() / 255.0F;
      float floatValue4 = (float)color.getAlpha() / 255.0F;
      float minX = (float)box.minX;
      float minY = (float)box.minY;
      float minZ = (float)box.minZ;
      float maxX = (float)box.maxX;
      float maxY = (float)box.maxY;
      float maxZ = (float)box.maxZ;
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, maxY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, minX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, maxZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      bufferBuilder.vertex(positionMatrix, maxX, minY, minZ).color(floatValue, floatValue2, floatValue3, floatValue4);
      BuiltBuffer builtBuffer = bufferBuilder.end();
      if (builtBuffer != null) {
         builtBuffer.close();
      }
   }

   public static void updateStateForDrawContext8(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, float floatValue) {
      Color color = new Color(intValue5, true);

      for (int intValue6 = 0; intValue6 < 4; intValue6++) {
         byte byteValue = 0;
         int alpha = 0;
         switch (intValue6) {
            case 0:
               byteValue = 3;
               alpha = (int)((float)color.getAlpha() * floatValue * 0.15F);
               break;
            case 1:
               byteValue = 2;
               alpha = (int)((float)color.getAlpha() * floatValue * 0.3F);
               break;
            case 2:
               byteValue = 1;
               alpha = (int)((float)color.getAlpha() * floatValue * 0.5F);
               break;
            case 3:
               byteValue = 0;
               alpha = color.getAlpha();
         }

         int rgb = new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
         drawContext.fill(intValue - byteValue, intValue2 - byteValue, intValue3 + byteValue, intValue4 + byteValue, rgb);
      }
   }

   public static void updateStateForDrawContext9(DrawContext drawContext, TextRenderer textRenderer, String string, int intValue, int intValue2, int intValue3, float floatValue) {
      Color color = new Color(intValue3, true);

      for (int intValue4 = 0; intValue4 < 4; intValue4++) {
         int alpha = 0;
         byte byteValue = 0;
         byte byteValue2 = 0;
         switch (intValue4) {
            case 0:
               alpha = (int)((float)color.getAlpha() * floatValue * 0.2F);
               byteValue = 1;
               byteValue2 = 1;
               break;
            case 1:
               alpha = (int)((float)color.getAlpha() * floatValue * 0.3F);
               byteValue = 1;
               byteValue2 = 0;
               break;
            case 2:
               alpha = (int)((float)color.getAlpha() * floatValue * 0.3F);
               byteValue = 0;
               byteValue2 = 1;
               break;
            case 3:
               alpha = color.getAlpha();
               byteValue = 0;
               byteValue2 = 0;
         }

         int rgb = new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
         drawContext.drawText(textRenderer, string, intValue + byteValue, intValue2 + byteValue2, rgb, false);
      }
   }

   public static void updateStateForDrawContext10(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6) {
      drawContext.fill(intValue + intValue5, intValue2, intValue + intValue3 - intValue5, intValue2 + intValue4, intValue6);
      drawContext.fill(intValue, intValue2 + intValue5, intValue + intValue5, intValue2 + intValue4 - intValue5, intValue6);
      drawContext.fill(intValue + intValue3 - intValue5, intValue2 + intValue5, intValue + intValue3, intValue2 + intValue4 - intValue5, intValue6);
      updateStateForDrawContext4(drawContext, intValue + intValue5, intValue2 + intValue5, intValue5, intValue6, 0);
      updateStateForDrawContext4(drawContext, intValue + intValue3 - intValue5, intValue2 + intValue5, intValue5, intValue6, 1);
      updateStateForDrawContext4(drawContext, intValue + intValue5, intValue2 + intValue4 - intValue5, intValue5, intValue6, 2);
      updateStateForDrawContext4(drawContext, intValue + intValue3 - intValue5, intValue2 + intValue4 - intValue5, intValue5, intValue6, 3);
   }

   public static void enableBooleanState() {
      booleanState = true;
   }

   private static int computeInt(int intValue, int intValue2, float floatValue) {
      int intValue3 = intValue >> 24 & 0xFF;
      int intValue4 = intValue >> 16 & 0xFF;
      int intValue5 = intValue >> 8 & 0xFF;
      int intValue6 = intValue & 0xFF;
      int intValue7 = intValue2 >> 24 & 0xFF;
      int intValue8 = intValue2 >> 16 & 0xFF;
      int intValue9 = intValue2 >> 8 & 0xFF;
      int intValue10 = intValue2 & 0xFF;
      int intValue11 = (int)((float)intValue3 + (float)(intValue7 - intValue3) * floatValue);
      int intValue12 = (int)((float)intValue4 + (float)(intValue8 - intValue4) * floatValue);
      int intValue13 = (int)((float)intValue5 + (float)(intValue9 - intValue5) * floatValue);
      int intValue14 = (int)((float)intValue6 + (float)(intValue10 - intValue6) * floatValue);
      return intValue11 << 24 | intValue12 << 16 | intValue13 << 8 | intValue14;
   }

   private static float computeFloat(float floatValue, float floatValue2, float floatValue3) {
      float floatValue4 = (float)Math.sqrt((double)(floatValue * floatValue + floatValue2 * floatValue2));
      if (floatValue4 <= floatValue3 - 1.0F) {
         return 1.0F;
      } else {
         return floatValue4 >= floatValue3 ? 0.0F : Math.max(0.0F, floatValue3 - floatValue4);
      }
   }

   public static void updateStateForDrawContext11(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6) {
      drawContext.fill(intValue + intValue5, intValue2, intValue + intValue3 - intValue5, intValue2 + intValue4, intValue6);
      drawContext.fill(intValue, intValue2 + intValue5, intValue + intValue5, intValue2 + intValue4 - intValue5, intValue6);
      drawContext.fill(intValue + intValue3 - intValue5, intValue2 + intValue5, intValue + intValue3, intValue2 + intValue4 - intValue5, intValue6);
      updateStateForDrawContext6(drawContext, intValue + intValue5, intValue2 + intValue5, intValue5, intValue6, 0);
      updateStateForDrawContext6(drawContext, intValue + intValue3 - intValue5, intValue2 + intValue5, intValue5, intValue6, 1);
      updateStateForDrawContext6(drawContext, intValue + intValue5, intValue2 + intValue4 - intValue5, intValue5, intValue6, 2);
      updateStateForDrawContext6(drawContext, intValue + intValue3 - intValue5, intValue2 + intValue4 - intValue5, intValue5, intValue6, 3);
   }

   public static void fillGradient(DrawContext drawContext, int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6) {
      drawContext.fillGradient(intValue, intValue2, intValue + intValue3, intValue2 + intValue4, intValue5, intValue6);
   }
}
