package cc.mochi;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

public record ProjectilePath(int startAge, Vec3d start, List<ProjectileSegment> segments) {
   public ProjectileSegment computeProjectileSegment(int intValue) {
      int intValue2 = intValue - this.startAge - 1;
      if (intValue2 >= 0) {
         if (intValue2 < getSegments(this).size()) {
            return this.segments.get(intValue2);
         }
      }

      return null;
   }

   public HitResult computeHitResult() {
      HitResult hit;
      if (this.segments.isEmpty()) {
         hit = null;

         ThreadLocalRandom.current().nextInt(11);
      } else {
         hit = getSegments(this).get(this.segments.size() - 1).getHit();
      }

      return hit;
   }

   public List getSegments22() {
      return getSegments(this);
   }

   public static int getStartAge(ProjectilePath projectilePath) {
      return projectilePath.startAge;
   }

   public int getStartAge2() {
      return getStartAge(this);
   }

   public int computeInt() {
      return getStartAge(this) + this.segments.size();
   }

   public static List<ProjectileSegment> getSegments(ProjectilePath projectilePath) {
      return projectilePath.segments;
   }

   public Vec3d computeVec3d(int intValue) {
      if (intValue == this.startAge) {
         return this.start;
      } else {
         ProjectileSegment projectileSegment = this.computeProjectileSegment(intValue);
         if (projectileSegment == null) {
         return null;
      } else {
         return projectileSegment.computeVec3d();
      }
      }
   }

   public static Vec3d getStart(ProjectilePath projectilePath) {
      return projectilePath.start;
   }

   public boolean checkCondition(int intValue) {
      ProjectileSegment projectileSegment = this.computeProjectileSegment(intValue);
      if (projectileSegment != null) {
         if (projectileSegment.getLeftOwner()) {
            return true;
         }
      }

      return false;
   }

   public Vec3d getStart2() {
      return getStart(this);
   }
}
