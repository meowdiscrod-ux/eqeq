package cc.mochi;

import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.gl.GpuSampler;

public record TextureHandle(GpuTextureView view, GpuSampler sampler, int width, int height, boolean premultiplied, boolean flipY) {
   public int getHeight() {
      return this.height;
   }

   public GpuSampler getSampler() {
      return this.sampler;
   }

   public boolean getFlipY() {
      return this.flipY;
   }

   public static TextureHandle computeTextureHandle(int intValue, int intValue2, int intValue3) {
      return MapAccess.computeTextureHandle(intValue, intValue2, intValue3);
   }

   public boolean getPremultiplied() {
      return this.premultiplied;
   }

   public GpuTextureView getView() {
      return this.view;
   }

   public int getWidth() {
      return this.width;
   }
}
