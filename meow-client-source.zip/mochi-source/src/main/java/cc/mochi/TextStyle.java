package cc.mochi;

public enum TextStyle {
   CAPTION(7.1F, FontFace.MEDIUM),

   SMALL(7.7F, FontFace.MEDIUM),
   OVERLINE(6.6F, FontFace.SEMIBOLD),
   BODY(8.4F, FontFace.MEDIUM),
   LABEL(8.6F, FontFace.MEDIUM),
   STRONG(8.9F, FontFace.SEMIBOLD),
   TITLE(10.6F, FontFace.SEMIBOLD),
   HEADING(14.0F, FontFace.SEMIBOLD),
   DISPLAY(21.0F, FontFace.BOLD);

   private static final TextStyle[] ENUM_VALUES = {CAPTION, SMALL, OVERLINE, BODY, LABEL, STRONG, TITLE, HEADING, DISPLAY};

   public final FontFace face;

   public final float size;

   private TextStyle(float size2, FontFace face2) {
      this.size = size2;
      this.face = face2;
   }

   private static TextStyle[] createValues() {
      return new TextStyle[]{CAPTION, SMALL, OVERLINE, BODY, LABEL, STRONG, TITLE, HEADING, DISPLAY};
   }

   public static TextStyle[] getENUM_VALUES() {
      return ENUM_VALUES;
   }
}
