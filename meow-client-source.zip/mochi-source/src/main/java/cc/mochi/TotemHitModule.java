package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;

public class TotemHitModule extends Module {
   private long timestampMillis;

   private final DoubleSetting switchDelaySetting;
   private boolean booleanState;
   private boolean pressed2;

   private int intState;

   public static void setPressed2(TotemHitModule totemHitModule, boolean pressed22) {
      totemHitModule.pressed2 = pressed22;
   }

   @EventHandler
   public void onTick(TickEvent tickEvent) {
      if (!(this.isWorldUnavailable())) {
         if (this.booleanState) {
            if ((double)(System.currentTimeMillis() - this.timestampMillis) >= this.switchDelaySetting.getValue()) {
               if (getIntState(this) != -1) {
                  MinecraftClientAccess37.getPlayer(mc).getInventory().setSelectedSlot(this.intState);
                  setIntState(this, -1);
               }

               this.booleanState = false;
            }
         }

         boolean pressed = MinecraftClientAccess37.getAttackKey(MinecraftClientAccess37.getOptions(mc)).isPressed();
         if (pressed) {
            if (!getPressed2(this)) {
               if (MinecraftClientAccess37.getPlayer(mc).getMainHandStack().getItem() == MinecraftClientAccess37.getTOTEM_OF_UNDYING()) {
                  HitResult crosshairTarget = mc.crosshairTarget;
                  if (crosshairTarget != null) {
                     if (crosshairTarget.getType() == Type.ENTITY) {
                        Entity entity = ((EntityHitResult)crosshairTarget).getEntity();
                        if (entity != null) {
                           ThreadLocalRandom.current().nextInt(15);
                           int intValue = this.computeInt();

                           if (intValue != -1) {
                              setIntState(this, MinecraftClientAccess37.getPlayer(mc).getInventory().getSelectedSlot());
                              mc.player.getInventory().setSelectedSlot(intValue);
                              AttackActions.testMinecraftClient(mc, "combat.attack.totemhit");
                              this.timestampMillis = System.currentTimeMillis();

                              setBooleanState(this, true);
                           } else {
                              ThreadLocalRandom.current().nextInt(16);
                           }
                        }
                     }
                  }
               }
            } else {
               ThreadLocalRandom.current().nextInt(15);
            }
         }

         this.pressed2 = pressed;
      }
   }

   private int computeInt() {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return -1;
         }

         if (MinecraftClientAccess37.getPlayer(mc).getInventory().getStack(intValue).isIn(MinecraftClientAccess37.getSWORDS())) {
            return intValue;
         }

         intValue++;
      }
   }

   public static void setIntState(TotemHitModule totemHitModule, int intState2) {
      totemHitModule.intState = intState2;
   }

   public static int getIntState(TotemHitModule totemHitModule) {
      return totemHitModule.intState;
   }

   public static boolean getPressed2(TotemHitModule totemHitModule) {
      return totemHitModule.pressed2;
   }

   public TotemHitModule() {
      super("Totem Hit", "Switches to sword when attacking with totem", ModuleCategory.COMBAT);

      this.switchDelaySetting = new DoubleSetting("Switch Delay", 10.0, (100.0), (30.0), (1.0));
      this.intState = -1;
      this.booleanState = false;

      this.timestampMillis = (0L);

      this.pressed2 = false;
      this.addSettings(new Setting[]{this.switchDelaySetting});
   }

   @Override
   public void onDisable() {
      if (this.intState != -1) {
         ThreadLocalRandom.current().nextInt(5);

         ThreadLocalRandom.current().nextInt(17);
         MinecraftClientAccess37.getPlayer(mc).getInventory().setSelectedSlot(this.intState);
         setIntState(this, -1);
      }

      this.booleanState = false;
      setPressed2(this, false);
   }

   public static void setBooleanState(TotemHitModule totemHitModule, boolean booleanState2) {
      totemHitModule.booleanState = booleanState2;
   }
}
