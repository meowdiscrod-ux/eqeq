package cc.mochi;

public enum NotificationSeverity {
   INFO,
   SUCCESS,
   WARNING,
   ERROR;

   private static NotificationSeverity[] createValues() {
      return new NotificationSeverity[]{INFO, SUCCESS, WARNING, ERROR};
   }
}
