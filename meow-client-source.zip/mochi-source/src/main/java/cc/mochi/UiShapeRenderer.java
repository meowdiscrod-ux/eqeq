package cc.mochi;

import java.awt.Color;

public final class UiShapeRenderer {
   private static float max(float floatValue) {
      return Math.max(0.9F, floatValue * 0.12F);
   }

   private static void updateStateForUiRenderContext(UiRenderContext uiRenderContext, float floatValue, float floatValue2, float floatValue3, Color color, float floatValue4, float floatValue5) {
      float floatValue6 = floatValue3 / 2.0F;
      float floatValue7 = max(floatValue3);
      float floatValue8 = floatValue6 * 0.3F;
      float floatValue9 = floatValue6 * 0.55F;
      if (floatValue4 != 0.0F) {
         float floatValue10 = floatValue + floatValue4 * floatValue8;
         uiRenderContext.drawLineSegment(floatValue - floatValue4 * floatValue8, floatValue2 - floatValue9, floatValue10, floatValue2, floatValue7, color);
         uiRenderContext.drawLineSegment(floatValue10, floatValue2, floatValue - floatValue4 * floatValue8, floatValue2 + floatValue9, floatValue7, color);
      } else {
         float floatValue11 = floatValue2 + floatValue5 * floatValue8;
         uiRenderContext.drawLineSegment(floatValue - floatValue9, floatValue2 - floatValue5 * floatValue8, floatValue, floatValue11, floatValue7, color);
         uiRenderContext.drawLineSegment(floatValue, floatValue11, floatValue + floatValue9, floatValue2 - floatValue5 * floatValue8, floatValue7, color);
      }
   }

   private UiShapeRenderer() {
   }

   public static void updateStateForUiRenderContext2(UiRenderContext uiRenderContext, ModuleCategory moduleCategory, float floatValue, float floatValue2, float floatValue3, Color color) {
      IconRenderer.updateStateForUiRenderContext(uiRenderContext, moduleCategory, floatValue, floatValue2, floatValue3, color);
   }

   public static void updateStateForUiRenderContext3(UiRenderContext uiRenderContext, Icon icon, float centerX, float centerY, float floatValue3, Color color) {
      float thickness = max(floatValue3);
      float floatValue5 = floatValue3 / 2.0F;
      switch (icon) {
         case CHEVRON_LEFT:
            updateStateForUiRenderContext(uiRenderContext, centerX, centerY, floatValue3, color, ((-1.0F)), 0.0F);
            break;
         case CHEVRON_RIGHT:
            updateStateForUiRenderContext(uiRenderContext, centerX, centerY, floatValue3, color, 1.0F, 0.0F);
            break;
         case CHEVRON_UP:
            updateStateForUiRenderContext(uiRenderContext, centerX, centerY, floatValue3, color, 0.0F, ((-1.0F)));
            break;
         case CHEVRON_DOWN:
            updateStateForUiRenderContext(uiRenderContext, centerX, centerY, floatValue3, color, 0.0F, 1.0F);
            break;
         case CHECK:
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.62F, centerY + floatValue5 * 0.02F, centerX - floatValue5 * 0.18F, centerY + floatValue5 * 0.46F, thickness, color);
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.18F, centerY + floatValue5 * 0.46F, centerX + floatValue5 * 0.66F, centerY - floatValue5 * 0.42F, thickness, color);
            break;
         case PLUS:
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.62F, centerY, centerX + floatValue5 * 0.62F, centerY, thickness, color);
            uiRenderContext.drawLineSegment(centerX, centerY - floatValue5 * 0.62F, centerX, centerY + floatValue5 * 0.62F, thickness, color);
            break;
         case MINUS:
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.62F, centerY, centerX + floatValue5 * 0.62F, centerY, thickness, color);
            break;
         case CLOSE:
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.5F, centerY - floatValue5 * 0.5F, centerX + floatValue5 * 0.5F, centerY + floatValue5 * 0.5F, thickness, color);
            uiRenderContext.drawLineSegment(centerX + floatValue5 * 0.5F, centerY - floatValue5 * 0.5F, centerX - floatValue5 * 0.5F, centerY + floatValue5 * 0.5F, thickness, color);
            break;
         case SEARCH:
            uiRenderContext.strokeCircle(centerX - floatValue5 * 0.14F, centerY - floatValue5 * 0.14F, floatValue5 * 0.5F, thickness, color);
            uiRenderContext.drawLineSegment(centerX + floatValue5 * 0.24F, centerY + floatValue5 * 0.24F, centerX + floatValue5 * 0.66F, centerY + floatValue5 * 0.66F, thickness, color);
            break;
         case RESET:
            float floatValue6 = floatValue5 * 0.58F;
            uiRenderContext.strokeArc(centerX, centerY, floatValue6, thickness, (float)Math.toRadians(((-60.0))), (float)Math.toRadians(290.0), color);
            float floatValue7 = centerX + floatValue6 * (float)Math.cos(Math.toRadians(((-60.0))));
            float floatValue8 = centerY + floatValue6 * (float)Math.sin(Math.toRadians(((-60.0))));
            uiRenderContext.drawLineSegment(floatValue7, floatValue8, floatValue7 - floatValue5 * 0.42F, floatValue8 - floatValue5 * 0.04F, thickness, color);
            uiRenderContext.drawLineSegment(floatValue7, floatValue8, floatValue7 + floatValue5 * 0.02F, floatValue8 + floatValue5 * 0.42F, thickness, color);
            break;
         case GRIP:
            float floatValue9 = floatValue5 * 0.42F;

            for (byte byteValue = -1; byteValue <= 1; byteValue += 2) {
               for (int intValue = -1; intValue <= 1; intValue++) {
                  uiRenderContext.fillCircle(centerX + (float)byteValue * floatValue9 * 0.55F, centerY + (float)intValue * floatValue9, thickness * 0.62F, color);
               }
            }
            break;
         case POWER:
            float floatValue10 = floatValue5 * 0.6F;
            uiRenderContext.strokeArc(centerX, centerY + floatValue5 * 0.06F, floatValue10, thickness, (float)Math.toRadians(((-55.0))), (float)Math.toRadians(290.0), color);
            uiRenderContext.drawLineSegment(centerX, centerY - floatValue5 * 0.72F, centerX, centerY - floatValue5 * 0.06F, thickness, color);
            break;
         case USERS:
            uiRenderContext.strokeCircle(centerX - floatValue5 * 0.18F, centerY - floatValue5 * 0.3F, floatValue5 * 0.3F, thickness, color);
            uiRenderContext.strokeArc(centerX - floatValue5 * 0.18F, centerY + floatValue5 * 0.62F, floatValue5 * 0.55F, thickness, (float) Math.PI, (float) Math.PI, color);
            uiRenderContext.strokeArc(centerX + floatValue5 * 0.42F, centerY - floatValue5 * 0.3F, floatValue5 * 0.27F, thickness, (float)Math.toRadians(((-80.0))), (float)Math.toRadians(180.0), color);
            uiRenderContext.drawLineSegment(centerX + floatValue5 * 0.6F, centerY + floatValue5 * 0.2F, centerX + floatValue5 * 0.72F, centerY + floatValue5 * 0.62F, thickness, color);
            break;
         case CLIPBOARD:
            uiRenderContext.strokeRoundedRect(centerX - floatValue5 * 0.56F, centerY - floatValue5 * 0.52F, floatValue5 * 1.12F, floatValue5 * 1.3F, floatValue5 * 0.18F, thickness, color);
            uiRenderContext.fillRoundedRect(centerX - floatValue5 * 0.28F, centerY - floatValue5 * 0.72F, floatValue5 * 0.56F, floatValue5 * 0.3F, floatValue5 * 0.1F, color);
            break;
         case COPY:
            IconRenderer.drawTextureFromResource9(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case TRASH:
            IconRenderer.drawTextureFromResource6(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case FOLDER:
            IconRenderer.drawTextureFromResource16(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case PALETTE:
            IconRenderer.drawTextureFromResource8(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case LAYOUT:
            IconRenderer.drawTextureFromResource3(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case KEYBOARD:
            IconRenderer.drawTextureFromResource11(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case SLIDERS:
            IconRenderer.drawTextureFromResource13(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case SETTINGS:
            IconRenderer.drawTextureFromResource5(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case WRENCH:
            IconRenderer.drawTextureFromResource4(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case MOUSE:
            IconRenderer.drawTextureFromResource10(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case KEY:
            IconRenderer.drawTextureFromResource14(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case BOLT:
            IconRenderer.drawTextureFromResource7(uiRenderContext, centerX, centerY, floatValue3, color);
            break;
         case GRID:
            float floatValue11 = floatValue5 * 0.5F;
            float floatValue12 = floatValue5 * 0.14F;

            for (int intValue2 = 0; intValue2 < 4; intValue2++) {
               float x = centerX + (intValue2 % 2 == 0 ? -floatValue11 - floatValue12 / 2.0F : floatValue12 / 2.0F);
               float y = centerY + (intValue2 < 2 ? -floatValue11 - floatValue12 / 2.0F : floatValue12 / 2.0F);
               uiRenderContext.strokeRoundedRect(x, y, floatValue11, floatValue11, floatValue11 * 0.28F, thickness * 0.85F, color);
            }
            break;
         case COMMAND:
            float floatValue15 = floatValue5 * 0.32F;
            uiRenderContext.strokeRoundedRect(centerX - floatValue15, centerY - floatValue15, floatValue15 * 2.0F, floatValue15 * 2.0F, 0.5F, thickness * 0.9F, color);

            for (int intValue3 = 0; intValue3 < 4; intValue3++) {
               float floatValue16 = centerX + (intValue3 % 2 == 0 ? -floatValue15 : floatValue15);
               float floatValue17 = centerY + (intValue3 < 2 ? -floatValue15 : floatValue15);
               uiRenderContext.strokeCircle(
                  floatValue16 + (intValue3 % 2 == 0 ? -floatValue15 * 0.55F : floatValue15 * 0.55F), floatValue17 + (intValue3 < 2 ? -floatValue15 * 0.55F : floatValue15 * 0.55F), floatValue15 * 0.55F, thickness * 0.9F, color
               );
            }
            break;
         case MAGNET:
            uiRenderContext.strokeArc(centerX, centerY, floatValue5 * 0.52F, thickness * 1.6F, 0.0F, (float) Math.PI, color);
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.52F, centerY, centerX - floatValue5 * 0.52F, centerY - floatValue5 * 0.62F, thickness * 1.6F, color);
            uiRenderContext.drawLineSegment(centerX + floatValue5 * 0.52F, centerY, centerX + floatValue5 * 0.52F, centerY - floatValue5 * 0.62F, thickness * 1.6F, color);
            break;
         case EYE:
            uiRenderContext.strokeArc(centerX, centerY + floatValue5 * 0.55F, floatValue5 * 0.95F, thickness, (float)Math.toRadians(((-150.0))), (float)Math.toRadians(120.0), color);
            uiRenderContext.strokeArc(centerX, centerY - floatValue5 * 0.55F, floatValue5 * 0.95F, thickness, (float)Math.toRadians(30.0), (float)Math.toRadians(120.0), color);
            uiRenderContext.fillCircle(centerX, centerY, floatValue5 * 0.24F, color);
            break;
         case ARROW_RIGHT:
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.6F, centerY, centerX + floatValue5 * 0.55F, centerY, thickness, color);
            uiRenderContext.drawLineSegment(centerX + floatValue5 * 0.55F, centerY, centerX + floatValue5 * 0.12F, centerY - floatValue5 * 0.42F, thickness, color);
            uiRenderContext.drawLineSegment(centerX + floatValue5 * 0.55F, centerY, centerX + floatValue5 * 0.12F, centerY + floatValue5 * 0.42F, thickness, color);
            break;
         case DOT:
            uiRenderContext.fillCircle(centerX, centerY, floatValue5 * 0.3F, color);
            break;
         case SPARK:
            uiRenderContext.drawLineSegment(centerX, centerY - floatValue5 * 0.72F, centerX, centerY + floatValue5 * 0.72F, thickness, color);
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.72F, centerY, centerX + floatValue5 * 0.72F, centerY, thickness, color);
            uiRenderContext.drawLineSegment(centerX - floatValue5 * 0.4F, centerY - floatValue5 * 0.4F, centerX + floatValue5 * 0.4F, centerY + floatValue5 * 0.4F, thickness * 0.8F, color);
            uiRenderContext.drawLineSegment(centerX + floatValue5 * 0.4F, centerY - floatValue5 * 0.4F, centerX - floatValue5 * 0.4F, centerY + floatValue5 * 0.4F, thickness * 0.8F, color);
      }
   }
}
