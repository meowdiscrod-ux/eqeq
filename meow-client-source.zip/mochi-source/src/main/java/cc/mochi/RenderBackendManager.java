package cc.mochi;

import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

public final class RenderBackendManager {
   private static final Logger logger = NOPLogger.NOP_LOGGER;
   private RenderBackendProvider renderBackendProvider;

   private volatile boolean booleanState;

   private Throwable throwable;
   private final Supplier<RenderBackendProvider> supplier;

   private boolean booleanState2;
   private boolean booleanState3;
   private final Supplier<RenderBackendProvider> supplier2;

   private static final RenderBackendManager INSTANCE = new RenderBackendManager(() -> new AcceleratedBackendProvider(), () -> new DrawContextBackendProvider());
   private boolean booleanState4;

   private synchronized void updateState() {
      if (this.booleanState) {
         this.booleanState = false;
         if (this.booleanState3) {
            updateStateForRenderBackendProvider(this.renderBackendProvider);
            this.renderBackendProvider = null;
            this.booleanState3 = false;
            this.throwable = null;
            logger.info("Retrying the 2D renderer after a world change");
         } else {
            if (this.renderBackendProvider != null && !this.renderBackendProvider.isFallback()) {
               try {
                  this.renderBackendProvider.reloadResources();
               } catch (Throwable throwable2) {
                  this.updateStateForThrowable2(throwable2);
               }
            }
         }
      }
   }

   private UiRenderBackend computeUiRenderBackendForDrawContext(DrawContext drawContext, int intValue, int intValue2, boolean booleanValue) {
      this.updateState();
      RenderBackendProvider renderBackendProvider2 = this.computeRenderBackendProvider2();

      try {
         UiRenderBackend uiRenderBackend = booleanValue ? renderBackendProvider2.openUnscaled(drawContext, intValue, intValue2) : renderBackendProvider2.openScaled(drawContext, intValue, intValue2);
         return new GuardedRenderBackend(this, uiRenderBackend);
      } catch (Throwable throwable2) {
         this.updateStateForThrowable2(throwable2);
         RenderBackendProvider renderBackendProvider3 = this.computeRenderBackendProvider2();
         UiRenderBackend uiRenderBackend2 = booleanValue ? renderBackendProvider3.openUnscaled(drawContext, intValue, intValue2) : renderBackendProvider3.openScaled(drawContext, intValue, intValue2);
         return new GuardedRenderBackend(this, uiRenderBackend2);
      }
   }

   public synchronized boolean checkCondition() {
      return this.renderBackendProvider != null ? this.renderBackendProvider.isFallback() : this.booleanState3;
   }

   private static boolean getBoolean() {
      return Boolean.getBoolean("mochi.render.strictBackend");
   }

   public static RenderBackendManager getINSTANCE() {
      return INSTANCE;
   }

   private static void updateStateForRenderBackendProvider(RenderBackendProvider renderBackendProvider2) {
      if (renderBackendProvider2 != null) {
         try {
            renderBackendProvider2.resetResources();
         } catch (Throwable failure) {
            logger.debug("Render backend cleanup failed", failure);
         }
      }
   }

   public synchronized boolean getBooleanState3() {
      return this.booleanState3;
   }

   public UiRenderBackend computeUiRenderBackendForDrawContext2(DrawContext drawContext, int intValue, int intValue2) {
      return this.computeUiRenderBackendForDrawContext(drawContext, intValue, intValue2, true);
   }

   private RenderBackendProvider computeRenderBackendProvider() {
      if (getBoolean()) {
         throw new IllegalStateException("The 2D renderer failed and mochi.render.strictBackend is set; refusing to degrade to the vanilla backend", this.throwable);
      } else {
         RenderBackendProvider renderBackendProvider2 = this.supplier.get();
         renderBackendProvider2.initialize();
         this.renderBackendProvider = renderBackendProvider2;
         logger.info("Selected the vanilla DrawContext rendering backend");
         return this.renderBackendProvider;
      }
   }

   private synchronized void updateStateForThrowable(Throwable throwable2) {
      if (!this.booleanState2) {
         this.booleanState2 = true;
         logger.warn("Minecraft texture rendering failed; suppressing the affected image", throwable2);
      }
   }

   public synchronized Throwable getThrowable() {
      return this.throwable;
   }

   public synchronized void updateStateForThrowable2(Throwable throwable2) {
      if (this.renderBackendProvider != null && !this.renderBackendProvider.isFallback()) {
         RenderBackendProvider renderBackendProvider2 = this.renderBackendProvider;
         this.renderBackendProvider = null;
         this.booleanState3 = true;
         this.throwable = throwable2;
         updateStateForRenderBackendProvider(renderBackendProvider2);
         logger.error("2D rendering failed; switched to the fallback backend until the next world change", throwable2);
      }
   }

   public synchronized RenderBackendProvider computeRenderBackendProvider2() {
      if (this.booleanState4) {
         throw new IllegalStateException("Render backend provider is closed");
      } else if (this.renderBackendProvider != null) {
         return this.renderBackendProvider;
      } else if (this.booleanState3) {
         return this.computeRenderBackendProvider();
      } else {
         RenderBackendProvider renderBackendProvider2 = null;

         try {
            renderBackendProvider2 = this.supplier2.get();
            renderBackendProvider2.initialize();
            this.renderBackendProvider = renderBackendProvider2;
            logger.info("Selected the Mochi 2D rendering backend");
            return this.renderBackendProvider;
         } catch (Throwable throwable2) {
            updateStateForRenderBackendProvider(renderBackendProvider2);
            this.booleanState3 = true;
            this.throwable = throwable2;
            if (!getBoolean()) {
               logger.error(
                  "The 2D renderer failed; using the vanilla DrawContext backend for this session (set -Dmochi.render.strictBackend=true to fail instead of degrading)",
                  throwable2
               );
            }

            return this.computeRenderBackendProvider();
         }
      }
   }

   public synchronized boolean isFallback() {
      return this.computeRenderBackendProvider2().isFallback();
   }

   public UiRenderBackend computeUiRenderBackendForDrawContext3(DrawContext drawContext, int intValue, int intValue2) {
      return this.computeUiRenderBackendForDrawContext(drawContext, intValue, intValue2, false);
   }

   public synchronized boolean checkCondition2() {
      return this.renderBackendProvider != null && !this.renderBackendProvider.isFallback();
   }

   public RenderBackendManager(Supplier supplier3, Supplier supplier4) {
      this.supplier2 = Objects.requireNonNull(supplier3, "primaryFactory");
      this.supplier = Objects.requireNonNull(supplier4, "fallbackFactory");
   }

   public void updateStateForDrawContext(
      DrawContext drawContext,
      int intValue,
      int intValue2,
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue3,
      int intValue4,
      int intValue5,
      int intValue6
   ) {
      RenderBackendProvider renderBackendProvider2 = this.computeRenderBackendProvider2();

      try {
         renderBackendProvider2.drawTexture(drawContext, intValue, intValue2, identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, intValue3, intValue4, intValue5, intValue6);
      } catch (Throwable throwable2) {
         if (renderBackendProvider2.isFallback()) {
            this.updateStateForThrowable(throwable2);
            return;
         }

         this.updateStateForThrowable2(throwable2);

         try {
            this.computeRenderBackendProvider2().drawTexture(drawContext, intValue, intValue2, identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, intValue3, intValue4, intValue5, intValue6);
         } catch (Throwable failure2) {
            this.updateStateForThrowable(failure2);
         }
      }
   }

   public synchronized void updateState2() {
      if (!this.booleanState4) {
         this.booleanState4 = true;
         updateStateForRenderBackendProvider(this.renderBackendProvider);
         this.renderBackendProvider = null;
      }
   }

   public void enableBooleanState() {
      this.booleanState = true;
   }
}
