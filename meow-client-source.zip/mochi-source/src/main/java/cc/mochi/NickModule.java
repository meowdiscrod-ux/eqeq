package cc.mochi;

import net.minecraft.text.MutableText;
import net.minecraft.text.PlainTextContent;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;
import net.minecraft.text.TranslatableTextContent;

public class NickModule extends Module {
   private final BooleanSetting nickSetting = new BooleanSetting("Nick", false);

   private final StringSetting nicknameSetting = new StringSetting("Nickname", ClientText.CLIENT_NAME.toString());

   private Text computeTextForText(Text text, String string, String string2) {
      if (text != null) {
         if (text.getString().contains(string)) {
            TextContent content = text.getContent();
            MutableText mutableText;
            if (content instanceof PlainTextContent) {
               PlainTextContent content2 = (PlainTextContent)content;
               mutableText = Text.literal(content2.string().replace(string, string2));
            } else if (content instanceof TranslatableTextContent) {
               TranslatableTextContent content3 = (TranslatableTextContent)content;
               Object[] args = content3.getArgs();
               Object[] objectValue = new Object[args.length];

               for (int intValue = 0; intValue < args.length; intValue++) {
                  objectValue[intValue] = args[intValue] instanceof Text var11 ? this.computeTextForText(var11, string, string2) : args[intValue];
               }

               mutableText = Text.translatable(content3.getKey(), objectValue);
            } else {
               mutableText = text.copyContentOnly();
            }

            mutableText.setStyle(text.getStyle());

            for (Text text2 : text.getSiblings()) {
               mutableText.append(this.computeTextForText(text2, string, string2));
            }

            return mutableText;
         }
      }

      return text;
   }

   public static Text computeTextForText2(Text text) {
      NickModule nickModule = (NickModule)cc.mochi.ModuleLookup.computeModuleForClass(NickModule.class);
      if (nickModule != null) {
         if (nickModule.isEnabled() && getNickSetting(nickModule).getValue()) {
            if (text != null) {
               String username = mc.getSession().getUsername();
               String value3 = nickModule.nicknameSetting.getValue3();
               if (username != null && !username.isEmpty() && value3 != null && !value3.isEmpty()) {
                  if (!username.equals(value3)) {
                     return nickModule.computeTextForText(text, username, value3);
                  }
               }

               return text;
            }
         }
      }

      return text;
   }

   public static BooleanSetting getNickSetting(NickModule nickModule) {
      return nickModule.nickSetting;
   }

   public NickModule() {
      super("Nick", "Replaces your username in chat, nametags and the tab list.", ModuleCategory.PLAYER);

      Setting[] settingArray = new Setting[2];

      settingArray[0] = this.nickSetting;
      settingArray[1] = this.nicknameSetting;
      this.addSettings(settingArray);
   }
}
