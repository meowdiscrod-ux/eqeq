package cc.mochi;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

public abstract class UiScreen extends Screen {
   protected final UiContext uiContext = new UiContext();
   private float floatState2;
   private final UiRenderContext uiRenderContext = new UiRenderContext();
   private long timestampNanos = System.nanoTime();

   public static UiContext getUiContext(UiScreen uiScreen) {
      return uiScreen.uiContext;
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      double pointX = click.x() / (double)this.computeFloat6();
      double pointY = click.y() / (double)this.computeFloat6();
      if (this.checkCondition2(pointX, pointY, click.button())) {
         return true;
      } else {
         getUiContext(this).getInputRouter().dispatchPress(pointX, pointY, click.button());
         return true;
      }
   }

   protected boolean checkCondition2(double doubleValue, double doubleValue2, int intValue) {
      return false;
   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      double pointX = mouseX / (double)this.computeFloat6();
      double pointY = mouseY / (double)this.computeFloat6();
      if (!getUiContext(this).getInputRouter().dispatchScroll(pointX, pointY, verticalAmount)) {
         this.updateState5(pointX, pointY, verticalAmount);
      }

      return true;
   }

   public boolean shouldPause() {
      return false;
   }

   protected float computeFloat5() {
      return (float)this.height / this.computeFloat6();
   }

   protected UiScreen(String string) {
      super(Text.literal(string));
   }

   protected void updateState5(double doubleValue, double doubleValue2, double doubleValue3) {
   }

   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      getUiContext(this).getInputRouter().updateDrag(click.x() / (double)this.computeFloat6(), click.y() / (double)this.computeFloat6());
      return true;
   }

   public boolean keyPressed(KeyInput input) {
      return this.checkCondition(input.key(), input.hasCtrlOrCmd(), input.hasShift()) ? true : super.keyPressed(input);
   }

   protected float computeFloat6() {
      return WindowScaleMath.computeFloat(this.width, this.height);
   }

   public boolean charTyped(CharInput input) {
      return this.checkCondition4((char)input.codepoint()) ? true : super.charTyped(input);
   }

   public boolean mouseReleased(Click click) {
      getUiContext(this).getInputRouter().endDrag(click.x() / (double)this.computeFloat6(), click.y() / (double)this.computeFloat6());
      return true;
   }

   protected boolean checkCondition6() {
      return true;
   }

   protected boolean checkCondition4(char charValue) {
      return false;
   }

   public static void setTimestampNanos(UiScreen uiScreen, long timestampNanos2) {
      uiScreen.timestampNanos = timestampNanos2;
   }

   protected abstract void updateStateForUiContext6(UiContext uiContext2, float floatValue, float floatValue2, float floatValue3);

   protected boolean checkCondition(int intValue, boolean booleanValue, boolean booleanValue2) {
      return false;
   }

   public static float getFloatState2(UiScreen uiScreen) {
      return uiScreen.floatState2;
   }

   protected float computeFloat7() {
      return (float)this.width / this.computeFloat6();
   }

   public static void setFloatState2(UiScreen uiScreen, float floatState22) {
      uiScreen.floatState2 = floatState22;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      long timestampNanos2 = System.nanoTime();
      float deltaSeconds = Math.min(0.1F, Math.max(1.0E-4F, (float)(timestampNanos2 - this.timestampNanos) * 1.0E-9F));
      setTimestampNanos(this, timestampNanos2);
      if (this.width > 0 && this.height > 0) {
         setFloatState2(this, Math.min(1.0F, getFloatState2(this) + deltaSeconds * (ClickGuiModule.getValue() ? 100.0F : 5.0F)));
         float floatValue2 = AnimatedFloat.outCubic(getFloatState2(this));
         UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForDrawContext(context, this.width, this.height);
         UiRenderContext uiRenderContext2 = this.uiRenderContext;

         try {
            uiRenderContext2.setBackend(uiRenderBackend);
            float floatValue3 = this.computeFloat6();
            uiRenderContext2.updateScale(floatValue3);
            ThemeSnapshot themeSnapshot = ThemeSnapshot.computeThemeSnapshot2(floatValue2);
            float width2 = (float)this.width / floatValue3;
            float height2 = (float)this.height / floatValue3;
            if (this.checkCondition6()) {
               if (themeSnapshot.getBlurEnabled() && uiRenderContext2.getBlurAvailable()) {
                  uiRenderContext2.testBlurQuality2(ClickGuiModule.max(), BlurQuality.computeBlurQuality(themeSnapshot.getBlurQuality2()));
               }

               if (ClickGuiModule.equals()) {
                  uiRenderContext2.drawAuroraBackdrop(themeSnapshot, width2, height2, 0.8F * floatValue2, themeSnapshot.getMotion());
               } else {
                  uiRenderContext2.fillRect(0.0F, 0.0F, width2, height2, themeSnapshot.getBackdropDim2());
               }
            }

            this.uiContext.beginFrame(uiRenderContext2, themeSnapshot, (double)((float)mouseX / floatValue3), (double)((float)mouseY / floatValue3), deltaSeconds);

            try {
               this.updateStateForUiContext6(getUiContext(this), width2, height2, floatValue2);
            } finally {
               this.uiContext.commitFrame();
            }
         } catch (RuntimeException failure) {
            HudBloomRenderer.reportFailureOnce(this.getTitle().getString(), failure);
         } finally {
            uiRenderContext2.close();
         }
      }
   }
}
