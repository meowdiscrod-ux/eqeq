package cc.mochi;

import net.minecraft.util.math.Vec3d;

public record TimedParticleOrigin(Vec3d pos, long spawnTime) {
   public long getSpawnTime() {
      return this.spawnTime;
   }

   public Vec3d getPos() {
      return this.pos;
   }
}
