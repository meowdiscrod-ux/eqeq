package cc.mochi;

public class NumberSliderDragHandler implements DragHandler {
   final Setting setting;

   final SettingEditor settingEditor;

   final float floatState;

   final float floatState2;

   @Override
   public void release(double doubleValue, double doubleValue2) {
      getSettingEditor(this).setting = null;
   }

   NumberSliderDragHandler(SettingEditor settingEditor2, Setting setting2, float floatState3, float floatState22) {
      this.settingEditor = settingEditor2;
      this.setting = setting2;
      this.floatState = floatState3;
      this.floatState2 = floatState22;
   }

   @Override
   public void drag(double doubleValue, double doubleValue2) {
      SettingEditor.updateStateForSetting2(this.setting, SliderWidgets.computeFloat(doubleValue, this.floatState, this.floatState2));
   }

   public static SettingEditor getSettingEditor(NumberSliderDragHandler numberSliderDragHandler) {
      return numberSliderDragHandler.settingEditor;
   }
}
