package cc.mochi;

import java.util.Random;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationManager {
   private static final MinecraftClient minecraftClient = MinecraftClient.getInstance();

   private static float floatState;

   private static int intState;

   private static final Random random = new Random();
   private static boolean booleanState;

   private static float floatState2;

   private static float floatState3;

   private static boolean booleanState2;

   private static final HumanizedAimController humanizedAimController = new HumanizedAimController(random);

   private static float yaw2;

   private static float pitch2;

   private static float floatState4;

   private static float yaw3;

   private static float pitch3;

   private static float floatState5;

   private static float pitch4;

   private static boolean booleanState3;

   private static ActionPriority actionPriority = ActionPriority.LOWEST;

   private static long longState;

   private static float floatState6;

   private static float floatState7;

   private static long timestampMillis;

   private static long currentTick222 = Long.MIN_VALUE;

   private static float floatState8;

   private static boolean booleanState4;

   private static float floatState9;

   private static boolean booleanState5;

   private static long currentTick223 = Long.MIN_VALUE;

   private static ClientPlayerEntity clientPlayerEntity;

   private static float yaw4;

   private static final float[] floatArray2 = new float[2];
   private static Object object;
   private static boolean booleanState6;
   private static Object object2;
   private static boolean booleanState7;
   private static Supplier<Vec3d> supplier;

   private static float floatState10;

   private static int age2 = Integer.MIN_VALUE;

   private static float floatState11;

   private static ClientPlayerEntity clientPlayerEntity2;

   private static long longState2;

   private static long longState3;

   private static float floatState12;
   private static boolean booleanState8;

   private static float floatState13;

   private static float floatState14;
   private static double doubleState = 0.016666666666666666;

   private static final Object object3 = new Object();

   private static float floatState15;

   private static long timestampMillis2 = -1L;

   public static boolean checkCondition() {
      return booleanState && booleanState7;
   }

   private static void updateStateForRotationProfile(long longValue, RotationProfile rotationProfile) {
      long longState4 = rotationProfile.getLongState();
      booleanState4 = longState4 <= 0L;
      longState = longValue + longState4;
   }

   public static void updateState(Object objectValue) {
      if (booleanState && (object == null || object == objectValue)) {
         updateState4();
      }
   }

   public static void updateState2(float floatValue) {
      updateState8(false, 0.0F, 0.0F);
   }

   public static void updateState3() {
      updateState9(object3);
   }

   private static double computeDouble(long timestampMillis22) {
      double doubleValue = 1.0;
      if (timestampMillis2 > 0L) {
         double doubleValue2 = (double)(timestampMillis22 - timestampMillis2);
         doubleValue = doubleValue2 / 16.666666666666668;
         doubleValue = MathHelper.clamp(doubleValue, 0.05, 3.0);
      }

      timestampMillis2 = timestampMillis22;
      return doubleValue;
   }

   public static void updateStateForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity3, double doubleValue, double doubleValue2) {
      if (checkCondition4() && clientPlayerEntity3 == minecraftClient.player && clientPlayerEntity3 == clientPlayerEntity2) {
         float yaw = clientPlayerEntity3.getYaw();
         float pitch = clientPlayerEntity3.getPitch();
         float lastYaw = clientPlayerEntity3.lastYaw;
         float lastPitch = clientPlayerEntity3.lastPitch;
         clientPlayerEntity3.setYaw(yaw3);
         clientPlayerEntity3.setPitch(pitch2);
         clientPlayerEntity3.changeLookDirection(doubleValue, doubleValue2);
         yaw3 = clientPlayerEntity3.getYaw();
         pitch2 = clientPlayerEntity3.getPitch();
         clientPlayerEntity3.setYaw(yaw);
         clientPlayerEntity3.setPitch(pitch);
         clientPlayerEntity3.lastYaw = lastYaw;
         clientPlayerEntity3.lastPitch = lastPitch;
      } else {
         clientPlayerEntity3.changeLookDirection(doubleValue, doubleValue2);
      }
   }

   public static boolean checkCondition2(Object objectValue) {
      if (booleanState && !booleanState7 && object == objectValue && supplier != null && minecraftClient.player != null) {
         Vec3d vec3d;
         try {
            vec3d = supplier.get();
         } catch (RuntimeException failure) {
            return false;
         }

         if (vec3d == null) {
            return false;
         } else {
            float[] floatArray = computeFloatArrayForVec3d(vec3d, yaw2);
            yaw2 = floatArray[0];
            pitch3 = floatArray[1];
            humanizedAimController.updateState3(false);
            minecraftClient.player.setYaw(yaw2);
            if (!booleanState6) {
               minecraftClient.player.setPitch(pitch3);
            }

            if (!booleanState8) {
               yaw3 = yaw2;
               pitch2 = pitch3;
            }

            yaw4 = yaw2;
            pitch4 = pitch3;
            return true;
         }
      } else {
         return false;
      }
   }

   public static void updateStateForActionPriority(Object object4, ActionPriority actionPriority2, Supplier supplier2, RotationProfile rotationProfile) {
      if (minecraftClient.player != null) {
         if (!booleanState || object == object4 || actionPriority2.ordinal() > actionPriority.ordinal()) {
            long timestampMillis22 = System.currentTimeMillis();
            if (!booleanState || booleanState7 || object != object4) {
               boolean booleanValue = booleanState && object != null && object != object4;
               boolean booleanValue2 = booleanState7 && object == object4;
               boolean booleanValue3 = booleanValue || !booleanValue2 && object2 != object4;
               boolean booleanValue4 = booleanState && booleanState8 && minecraftClient.player != null;
               booleanState = true;
               booleanState7 = false;
               object = object4;
               actionPriority = actionPriority2;
               clientPlayerEntity2 = minecraftClient.player;
               float lastYaw = minecraftClient.player.getYaw();
               float lastPitch = minecraftClient.player.getPitch();
               if (!booleanValue4) {
                  yaw3 = lastYaw;
                  pitch2 = lastPitch;
               } else if (!rotationProfile.isSilentAim()) {
                  lastYaw = yaw3;
                  lastPitch = pitch2;
                  minecraftClient.player.setYaw(lastYaw);
                  minecraftClient.player.lastYaw = lastYaw;
                  minecraftClient.player.setPitch(lastPitch);
                  minecraftClient.player.lastPitch = lastPitch;
               }

               yaw2 = lastYaw;
               pitch3 = lastPitch;
               yaw4 = lastYaw;
               pitch4 = lastPitch;
               timestampMillis2 = timestampMillis22;
               if (booleanValue3) {
                  humanizedAimController.updateState3(true);
               }

               updateStateForRotationProfile(timestampMillis22, rotationProfile);
            }

            supplier = supplier2;
            booleanState8 = rotationProfile.isSilentAim();
            booleanState6 = rotationProfile.getBooleanState3();
            humanizedAimController.updateStateForRotationProfile(rotationProfile);
            booleanState5 = rotationProfile.getBooleanState() && rotationProfile.getBooleanState4();
         }
      }
   }

   public static float[] computeFloatArrayForVec3d(Vec3d vec3d, float floatValue) {
      if (minecraftClient.player == null) {
         return new float[]{0.0F, 0.0F};
      } else {
         Vec3d eyePos = minecraftClient.player.getEyePos();
         return RotationMath.computeFloatArrayForVec3d(eyePos, vec3d, floatValue);
      }
   }

   public static float computeFloat() {
      return booleanState ? pitch2 : (minecraftClient.player != null ? minecraftClient.player.getPitch() : 0.0F);
   }

   public static float computeFloat2() {
      return booleanState ? yaw2 : (minecraftClient.player != null ? minecraftClient.player.getYaw() : 0.0F);
   }

   private static void updateState4() {
      booleanState2 = false;
      if (booleanState8 && minecraftClient.player != null && minecraftClient.player == clientPlayerEntity2) {
         float yaw = minecraftClient.player.getYaw();
         float lastYaw = yaw3 + 360.0F * (float)Math.round((yaw - yaw3) / 360.0F);
         minecraftClient.player.setYaw(lastYaw);
         minecraftClient.player.lastYaw = lastYaw;
         if (!booleanState6) {
            minecraftClient.player.setPitch(pitch2);
            minecraftClient.player.lastPitch = pitch2;
         }
      }

      if (booleanState6 && booleanState3 && minecraftClient.player != null && minecraftClient.player == clientPlayerEntity2) {
         minecraftClient.player.setPitch(RotationMath.clamp(minecraftClient.player.getPitch() - floatState));
         minecraftClient.player.lastPitch = minecraftClient.player.getPitch();
      }

      booleanState = false;
      supplier = null;
      booleanState7 = false;
      object2 = object;
      object = null;
      actionPriority = ActionPriority.LOWEST;
      humanizedAimController.updateState3(false);
      booleanState3 = false;
      intState = 0;
      age2 = Integer.MIN_VALUE;
      clientPlayerEntity2 = null;
   }

   private static float computeFloat3(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5) {
      float floatValue6 = floatValue5 * floatValue5;
      float floatValue7 = floatValue6 * floatValue5;
      return (2.0F * floatValue7 - 3.0F * floatValue6 + 1.0F) * floatValue + (floatValue7 - 2.0F * floatValue6 + floatValue5) * floatValue3 + (((-2.0F)) * floatValue7 + 3.0F * floatValue6) * floatValue2 + (floatValue7 - floatValue6) * floatValue4;
   }

   public static boolean checkCondition3(float floatValue) {
      if (booleanState && supplier != null && !booleanState7) {
         Vec3d vec3d = supplier.get();
         if (vec3d == null) {
            return false;
         } else {
            float[] floatArray = computeFloatArrayForVec3d(vec3d, yaw2);
            float floatValue2 = Math.abs(RotationMath.wrapDegrees(yaw2, floatArray[0]));
            float floatValue3 = Math.abs(RotationMath.wrapDegrees(pitch3, floatArray[1]));
            return floatValue2 < floatValue && (booleanState6 || floatValue3 < floatValue);
         }
      } else {
         return false;
      }
   }

   public static float[] computeFloatArray(Object objectValue, float floatValue, float floatValue2, double doubleValue) {
      if (booleanState && !booleanState7 && object == objectValue) {
         double doubleValue2 = Math.max(doubleState, (double)(System.currentTimeMillis() - timestampMillis2) / 1000.0);
         return humanizedAimController.computeFloatArray(yaw2, pitch3, floatValue, floatValue2, doubleValue, doubleValue2);
      } else {
         return null;
      }
   }

   public static Vec3d computeVec3d(Object objectValue) {
      return booleanState && object == objectValue && minecraftClient.player != null ? minecraftClient.player.getEyePos().add(RotationMath.computeVec3d(yaw2, pitch3).multiply(100.0)) : null;
   }

   public static boolean testEntity(Entity entity) {
      return booleanState && booleanState8 && minecraftClient.player != null && entity == minecraftClient.player && entity == clientPlayerEntity2;
   }

   private static float computeFloat4() {
      double doubleValue = (double)(System.currentTimeMillis() - timestampMillis) / (double)longState3;
      double doubleValue2 = MathHelper.clamp(doubleValue, 0.0, 1.0);
      double doubleValue3 = doubleValue2 * doubleValue2 * doubleValue2 * (doubleValue2 * (doubleValue2 * 6.0 - 15.0) + 10.0);
      return (float)(1.0 - doubleValue3);
   }

   public static void updateStateForClientPlayerEntity2(ClientPlayerEntity clientPlayerEntity3) {
      if (booleanState2) {
         booleanState2 = false;
         if (booleanState && clientPlayerEntity3 == minecraftClient.player && clientPlayerEntity3 == clientPlayerEntity2 && currentTick222 == ActionSchedulers.getCurrentTick22()) {
            clientPlayerEntity3.lastYaw = floatState14;
            if (!booleanState6) {
               clientPlayerEntity3.lastPitch = floatState7;
            }
         }
      }
   }

   private static float computeFloat5(float floatValue, float floatValue2) {
      return floatValue2 != 0.0F && Math.signum(floatValue) == Math.signum(floatValue2) ? Math.signum(floatValue2) * Math.min(Math.abs(floatValue), 3.0F * Math.abs(floatValue2)) : 0.0F;
   }

   public static float[] computeFloatArrayForEntity(Entity entity, float floatValue) {
      ClientPlayerEntity player = minecraftClient.player;
      if (player != null && entity == player && !player.hasVehicle() && player == clientPlayerEntity2 && currentTick223 == ActionSchedulers.getCurrentTick22()) {
         float floatValue2 = MathHelper.clamp(floatValue, 0.0F, 1.0F);
         floatArray2[0] = computeFloat3(floatState2, floatState13, floatState8, floatState6, floatValue2) + (player.getYaw() - floatState13);
         floatArray2[1] = booleanState6 ? player.getLerpedPitch(floatValue) : RotationMath.clamp(computeFloat3(floatState12, floatState15, floatState10, floatState9, floatValue2) + (player.getPitch() - floatState15));
         return floatArray2;
      } else {
         return null;
      }
   }

   public static float computeFloatForEntity(Entity entity, float floatValue) {
      ClientPlayerEntity player = minecraftClient.player;
      if (player == null || entity != player || player.hasVehicle()) {
         return Float.NaN;
      } else if (testClientPlayerEntity(player)) {
         return player.getYaw() + floatState4 * computeFloat4();
      } else {
         return testClientPlayerEntity2(player) ? MathHelper.lerp(floatValue, floatState14, floatState5) + (player.getYaw() - floatState5) : Float.NaN;
      }
   }

   public static void updateState5() {
      updateState4();
   }

   public static boolean getBooleanState() {
      return booleanState;
   }

   public static boolean checkCondition4() {
      return booleanState && booleanState8;
   }

   public static float computeFloat6() {
      return booleanState ? yaw3 : (minecraftClient.player != null ? minecraftClient.player.getYaw() : 0.0F);
   }

   private static int computeInt(float floatValue) {
      int intValue = MathHelper.clamp((int)(0.35F / floatValue), 1, 2);
      int intValue2 = random.nextBoolean() ? 1 : -1;
      if (intState >= intValue) {
         intValue2 = -1;
      } else if (intState <= -intValue) {
         intValue2 = 1;
      }

      return MathHelper.clamp(intState + intValue2, -intValue, intValue);
   }

   private static void updateState6(float floatValue, float floatValue2) {
      if (minecraftClient.player != null) {
         if (!booleanState3) {
            floatState = 0.0F;
            intState = 0;
            age2 = minecraftClient.player.age;
            booleanState3 = true;
         }

         float floatValue3 = minecraftClient.player.getPitch() - floatState;
         int age = minecraftClient.player.age;
         boolean booleanValue = floatValue > 0.0F && Math.abs(floatValue2) >= 0.35F && Math.abs(floatValue3) < 88.0F;
         if (booleanValue) {
            if (age != age2) {
               age2 = age;
               intState = computeInt(floatValue);
            }
         } else {
            intState = 0;
            age2 = age;
         }

         float floatValue4 = floatValue3 + (float)intState * floatValue;
         minecraftClient.player.setPitch(RotationMath.clamp(floatValue4));
         floatState = minecraftClient.player.getPitch() - floatValue3;
      }
   }

   private static void updateStateForVec3d(Vec3d vec3d, Vec3d vec3d2, float floatValue) {
      long currentTick22 = ActionSchedulers.getCurrentTick22();
      float floatValue2 = floatState5 - floatState14;
      float floatValue3 = floatState11 - floatState7;
      boolean booleanValue = currentTick223 == currentTick22 - 1L;
      boolean booleanValue2 = true;
      if (vec3d2 != null) {
         float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d2, floatState5);
         booleanValue2 = Math.abs(floatArray[0] - floatState5) <= floatValue && (booleanState6 || Math.abs(floatArray[1] - floatState11) <= floatValue);
      }

      floatState8 = computeFloat5(booleanValue ? floatState6 : 0.0F, floatValue2);
      floatState10 = computeFloat5(booleanValue ? floatState9 : 0.0F, floatValue3);
      floatState6 = computeFloat5(booleanValue2 ? 0.0F : floatValue2, floatValue2);
      floatState9 = computeFloat5(booleanValue2 ? 0.0F : floatValue3, floatValue3);
      floatState2 = floatState14;
      floatState13 = floatState5;
      floatState12 = floatState7;
      floatState15 = floatState11;
      currentTick223 = currentTick22;
   }

   private static boolean testClientPlayerEntity(ClientPlayerEntity clientPlayerEntity3) {
      if (longState3 <= 0L) {
         return false;
      } else if (clientPlayerEntity3 == clientPlayerEntity && System.currentTimeMillis() - timestampMillis < longState3) {
         return true;
      } else {
         longState3 = 0L;
         clientPlayerEntity = null;
         return false;
      }
   }

   public static float computeFloatForEntity2(Entity entity, float floatValue) {
      ClientPlayerEntity player = minecraftClient.player;
      if (player == null || entity != player || player.hasVehicle()) {
         return Float.NaN;
      } else if (testClientPlayerEntity(player)) {
         return RotationMath.clamp(player.getPitch() + floatState3 * computeFloat4());
      } else {
         return testClientPlayerEntity2(player) ? RotationMath.clamp(MathHelper.lerp(floatValue, floatState7, floatState11) + (player.getPitch() - floatState11)) : Float.NaN;
      }
   }

   public static void updateState7(Object objectValue, long longState22) {
      if (booleanState && object == objectValue && !booleanState8 && longState22 > 0L) {
         longState2 = longState22;
      }
   }

   public static float computeFloat7() {
      return booleanState ? pitch3 : (minecraftClient.player != null ? minecraftClient.player.getPitch() : 0.0F);
   }

   private static boolean testClientPlayerEntity2(ClientPlayerEntity clientPlayerEntity3) {
      return booleanState && !booleanState8 && clientPlayerEntity3 == clientPlayerEntity2 && currentTick222 == ActionSchedulers.getCurrentTick22();
   }

   private static void updateState8(boolean booleanValue, float floatValue, float floatValue2) {
      if (booleanState && minecraftClient.player != null) {
         if (minecraftClient.player != clientPlayerEntity2) {
            updateState4();
         } else {
            long timestampMillis3 = System.currentTimeMillis();
            double doubleValue = computeDouble(timestampMillis3);
            if (!booleanValue) {
               doubleState = doubleValue / 60.0;
            }

            if (!booleanState8) {
               yaw3 = minecraftClient.player.getYaw();
               pitch2 = minecraftClient.player.getPitch();
            }

            boolean booleanValue2 = supplier != null && !booleanState7;
            if (booleanValue2 && !booleanState4) {
               if (timestampMillis3 < longState) {
                  return;
               }

               booleanState4 = true;
            }

            float floatValue3 = MathHelper.wrapDegrees(minecraftClient.player.getYaw() - yaw4);
            float floatValue4 = minecraftClient.player.getPitch() - pitch4;
            yaw2 += floatValue3;
            if (!booleanState6) {
               pitch3 = RotationMath.clamp(pitch3 + floatValue4);
            }

            Vec3d vec3d = null;
            if (booleanValue2) {
               vec3d = supplier.get();
               if (vec3d == null) {
                  booleanState7 = true;
               }
            } else if (!booleanState7) {
               updateState4();
               return;
            }

            if (!booleanState7 || !(Math.abs(RotationMath.wrapDegrees(yaw2, yaw3)) < 0.5F) || !booleanState6 && !(Math.abs(pitch2 - pitch3) < 0.5F)) {
               Vec3d eyePos = minecraftClient.player.getEyePos();
               float floatValue5 = RotationMath.computeFloat2((Double)minecraftClient.options.getMouseSensitivity().getValue());
               if (booleanValue && !booleanState7) {
                  floatState14 = yaw2;
                  floatState7 = pitch3;
                  booleanState2 = true;
                  currentTick222 = ActionSchedulers.getCurrentTick22();
               }

               double[] doubleArray = booleanValue && !booleanState7
                  ? humanizedAimController.computeDoubleArrayForVec3d((double)yaw2, (double)pitch3, eyePos, vec3d, floatValue, floatValue2, floatValue5)
                  : humanizedAimController.computeDoubleArrayForVec3d2((double)yaw2, (double)pitch3, eyePos.x, eyePos.y, eyePos.z, vec3d, yaw3, pitch2, booleanState7, floatValue5, timestampMillis3, doubleValue);
               yaw2 = yaw2 + (float)doubleArray[0];
               if (!booleanState6) {
                  pitch3 = RotationMath.clamp(pitch3 + (float)doubleArray[1]);
               }

               if (booleanValue && !booleanState7) {
                  floatState5 = yaw2;
                  floatState11 = pitch3;
                  if (booleanState5) {
                     updateStateForVec3d(eyePos, vec3d, floatValue5);
                  }

                  if (longState2 > 0L && !booleanState8) {
                     clientPlayerEntity = minecraftClient.player;
                     floatState4 = floatState14 - floatState5;
                     floatState3 = floatState7 - floatState11;
                     timestampMillis = timestampMillis3;
                     longState3 = longState2;
                  }

                  longState2 = 0L;
               }

               minecraftClient.player.setYaw(yaw2);
               if (!booleanState6) {
                  minecraftClient.player.setPitch(pitch3);
               } else {
                  updateState6(floatValue5, (float)doubleArray[0]);
               }

               yaw4 = yaw2;
               pitch4 = pitch3;
            } else {
               updateState4();
            }
         }
      } else {
         if (booleanState) {
            updateState4();
         }
      }
   }

   public static void updateState9(Object objectValue) {
      if (booleanState && !booleanState7) {
         if (object == objectValue || object == null) {
            supplier = null;
            booleanState7 = true;
         }
      }
   }

   public static void updateState10(Object objectValue) {
      if (booleanState && object == objectValue) {
         humanizedAimController.updateState3(true);
         booleanState4 = false;
         longState = System.currentTimeMillis() + 40L + (long)random.nextInt(81);
      }
   }

   public static void updateState11(Object objectValue, float floatValue, float floatValue2) {
      if (object == objectValue) {
         updateState8(true, floatValue, floatValue2);
      }
   }
}
