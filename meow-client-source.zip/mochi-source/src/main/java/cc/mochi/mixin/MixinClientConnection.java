package cc.mochi.mixin;

import cc.mochi.OutgoingPacketQueue;
import cc.mochi.IncomingPacketQueue;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.types.TransferOrder;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.state.NetworkState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientConnection.class})
public class MixinClientConnection {
   @Inject(
      method = {"handlePacket(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void captureHeldInbound(Packet<?> packet, PacketListener listener, CallbackInfo ci) {
      if (MochiClient.INSTANCE != null) {
         if (IncomingPacketQueue.getINSTANCE().testPacketListener(listener, packet)) {
            ci.cancel();
         }
      }
   }

   @Unique
   private static void postPacketEvent(Packet<?> packet, TransferOrder order, CallbackInfo ci) {
      if (MochiClient.INSTANCE != null) {
         PacketEvent packetEvent = new PacketEvent(packet, order);
         MochiClient.INSTANCE.getMochiEventBus().post(packetEvent);
         if (packetEvent.isCancelled()) {
            ci.cancel();
         }
      }
   }

   @Inject(
      method = {"channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/network/ClientConnection;handlePacket(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;)V"
      )},
      cancellable = true
   )
   private static void receivePacketEventInject(ChannelHandlerContext channelHandlerContext, Packet<?> packet, CallbackInfo ci) {
      postPacketEvent(packet, TransferOrder.RECEIVE, ci);
   }

   @Inject(
      method = {"sendInternal"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void sendPacketEventInject(Packet<?> packet, ChannelFutureListener callbacks, boolean flush, CallbackInfo ci) {
      postPacketEvent(packet, TransferOrder.SEND, ci);
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void holdOutboundInject(Packet<?> packet, ChannelFutureListener callbacks, boolean flush, CallbackInfo ci) {
      if (OutgoingPacketQueue.getINSTANCE2().testClientConnection2((ClientConnection)(Object)this, packet, callbacks, flush)) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"transitionOutbound"},
      at = {@At("HEAD")}
   )
   private void releaseHeldBeforeTransitionInject(NetworkState<?> state, CallbackInfo ci) {
      OutgoingPacketQueue.getINSTANCE2().updateStateForClientConnection((ClientConnection)(Object)this);
   }

   @Inject(
      method = {"handleDisconnection"},
      at = {@At("HEAD")}
   )
   private void handleDisconnectionInject(CallbackInfo ci) {
      OutgoingPacketQueue.getINSTANCE2().updateState3();
      if (MochiClient.INSTANCE != null) {
         MochiClient.INSTANCE.getMochiEventBus().post(new DisconnectEvent());
      }
   }
}
