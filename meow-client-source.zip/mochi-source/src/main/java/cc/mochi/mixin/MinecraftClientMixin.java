package cc.mochi.mixin;

import cc.mochi.ActionSchedulers;
import cc.mochi.AutoHitCrystalModule;
import cc.mochi.RenderBackendManager;
import cc.mochi.FriendsModule;
import cc.mochi.HeldItemOverride;
import cc.mochi.BlockInteractUtils;
import cc.mochi.MinecraftAccess;
import cc.mochi.ModuleLookup;
import cc.mochi.RotationManager;
import cc.mochi.ProfileManager;
import cc.mochi.AttackInputBlocker;
import cc.mochi.CombatTickBudget;
import cc.mochi.OutgoingPacketQueue;
import cc.mochi.AnchorModule;
import cc.mochi.AutoMaceModule;
import cc.mochi.IncomingPacketQueue;
import cc.mochi.MochiClient;
import cc.mochi.AntiMissModule;
import cc.mochi.InventorySynchronization;
import cc.mochi.FriendManager;
import cc.mochi.SpearReachModule;
import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.DoAttackEvent;
import cc.mochi.event.impl.player.ItemUseEvent;
import cc.mochi.event.impl.player.TickEndEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.render.RenderTickCounter.Dynamic;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({MinecraftClient.class})
public class MinecraftClientMixin implements MinecraftAccess {
   private float preAttackPitch;
   private HitResult preBreakingCrosshairTarget;
   private float preItemUseYaw;
   private boolean reroutedAttack;
   @Shadow
   public ClientPlayerInteractionManager field_1761;
   private boolean reroutedBreaking;
   private HitResult preAttackCrosshairTarget = null;
   private float preItemUsePitch;
   @Shadow
   public HitResult field_1765;
   private float preBreakingYaw;
   private boolean reroutedItemUse;
   @Shadow
   public ClientPlayerEntity field_1724;
   @Shadow
   public ClientWorld field_1687;
   private HitResult preItemUseCrosshairTarget;
   private float preAttackYaw;
   private float preBreakingPitch;
   @Shadow
   @Final
   private Dynamic field_52750;

   @Inject(
      method = {"run"},
      at = {@At("HEAD")}
   )
   public void runInject(CallbackInfo ci) {
      if (MochiClient.INSTANCE != null) {
         ProfileManager profileManager = MochiClient.INSTANCE.getProfileManager();
         profileManager.updateState("default");
      }
   }

   private float getReroutedYaw() {
      return AnchorModule.checkCondition6() ? AnchorModule.computeFloat() : RotationManager.computeFloat2();
   }

   @Inject(
      method = {"handleBlockBreaking"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void handleBlockBreakingInject(boolean breaking, CallbackInfo ci) {
      if (!AnchorModule.checkCondition2() && !AutoHitCrystalModule.checkCondition6()) {
         if (breaking) {
            CombatTickBudget.updateState4();
         }

         try {
            if (this.shouldRerouteSilentClicks() && this.field_1724 != null) {
               this.preBreakingCrosshairTarget = this.field_1765;
               this.preBreakingYaw = this.field_1724.getYaw();
               this.preBreakingPitch = this.field_1724.getPitch();
               float reroutedYaw = this.getReroutedYaw();
               float reroutedPitch = this.getReroutedPitch();
               this.field_1724.setYaw(reroutedYaw);
               this.field_1724.setPitch(reroutedPitch);
               HitResult reroutedCrosshairTarget = this.getReroutedCrosshairTarget();
               if (reroutedCrosshairTarget != null) {
                  this.field_1765 = reroutedCrosshairTarget;
               }

               this.reroutedBreaking = true;
            }
         } catch (Throwable failure) {
         }
      } else {
         ci.cancel();
      }
   }

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void onTick(CallbackInfo ci) {
      ActionSchedulers.updateState3();
      if (MochiClient.INSTANCE != null && MochiClient.mc != null) {
         HeldItemOverride.updateStateForMinecraftClient((MinecraftClient)(Object)this);
         IncomingPacketQueue.getINSTANCE().updateState6();
         OutgoingPacketQueue.getINSTANCE2().updateState2();
         if (this.field_1687 != null) {
            MochiClient.INSTANCE.getMochiEventBus().post(new TickEvent());
         }

         MochiClient.INSTANCE.getModuleManager().findFirst(FriendsModule.class).ifPresent(objectValue -> ((FriendsModule)objectValue).updateState2());
      }
   }

   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void onTickEnd(CallbackInfo ci) {
      if (MochiClient.INSTANCE != null && MochiClient.mc != null) {
         if (this.field_1687 != null) {
            MochiClient.INSTANCE.getMochiEventBus().post(new TickEndEvent());
         }
      }
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At("RETURN")}
   )
   public final void doItemUseReturnInject(CallbackInfo ci) {
      if (this.reroutedItemUse) {
         if (this.field_1724 != null) {
            this.field_1724.setYaw(this.preItemUseYaw);
            this.field_1724.setPitch(this.preItemUsePitch);
         }

         this.field_1765 = this.preItemUseCrosshairTarget;
         this.reroutedItemUse = false;
      }
   }

   @Inject(
      method = {"stop"},
      at = {@At("HEAD")}
   )
   public void stopInject(CallbackInfo ci) {
      if (MochiClient.INSTANCE != null) {
         ProfileManager profileManager = MochiClient.INSTANCE.getProfileManager();
         profileManager.updateState5("default", true);
      }
   }

   private float getReroutedPitch() {
      return AnchorModule.checkCondition6() ? AnchorModule.computeFloat4() : RotationManager.computeFloat7();
   }

   private boolean shouldRerouteSilentClicks() {
      return AnchorModule.checkCondition6() || RotationManager.checkCondition4() && this.field_1724 != null;
   }

   @Inject(
      method = {"onDisconnected"},
      at = {@At("HEAD")}
   )
   public final void onDisconnected(CallbackInfo ci) {
      IncomingPacketQueue.getINSTANCE().updateState5();
      OutgoingPacketQueue.getINSTANCE2().updateState3();
      HeldItemOverride.updateState();
      RotationManager.updateState5();
      if (MochiClient.INSTANCE != null) {
         MochiClient.INSTANCE.getMochiEventBus().post(new DisconnectEvent());
      }
   }

   @Inject(
      method = {"handleBlockBreaking"},
      at = {@At("RETURN")}
   )
   public void handleBlockBreakingReturnInject(boolean breaking, CallbackInfo ci) {
      if (this.reroutedBreaking) {
         if (this.field_1724 != null) {
            this.field_1724.setYaw(this.preBreakingYaw);
            this.field_1724.setPitch(this.preBreakingPitch);
         }

         this.field_1765 = this.preBreakingCrosshairTarget;
         this.reroutedBreaking = false;
      }
   }

   @Inject(
      method = {"doAttack"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public final void doAttackInject(CallbackInfoReturnable<Boolean> cir) {
      if (SpearReachModule.checkCondition(true)) {
         cir.setReturnValue(false);
      } else if (InventorySynchronization.checkCondition3() && this.field_1765 instanceof EntityHitResult var2 && var2.getEntity() instanceof PlayerEntity var3 && FriendManager.testPlayerEntity(var3)) {
         InventorySynchronization.checkCondition2();
         cir.setReturnValue(false);
      } else if (AnchorModule.checkCondition2()) {
         cir.setReturnValue(false);
      } else {
         try {
            if (this.shouldRerouteSilentClicks() && this.field_1724 != null) {
               this.preAttackCrosshairTarget = this.field_1765;
               this.preAttackYaw = this.field_1724.getYaw();
               this.preAttackPitch = this.field_1724.getPitch();
               float reroutedYaw = this.getReroutedYaw();
               float reroutedPitch = this.getReroutedPitch();
               this.field_1724.setYaw(reroutedYaw);
               this.field_1724.setPitch(reroutedPitch);
               HitResult reroutedCrosshairTarget = this.getReroutedCrosshairTarget();
               if (reroutedCrosshairTarget != null) {
                  this.field_1765 = reroutedCrosshairTarget;
               }

               this.reroutedAttack = true;
            }
         } catch (Throwable failure) {
         }

         try {
            for (AttackInputBlocker attackInputBlocker : (java.lang.Iterable<AttackInputBlocker>)(java.lang.Iterable<?>)(ModuleLookup.computeListForClass(AttackInputBlocker.class))) {
               if (attackInputBlocker.shouldBlockAttackInput()) {
                  cir.setReturnValue(false);
                  return;
               }
            }
         } catch (Throwable failure2) {
         }

         try {
            Optional optional = MochiClient.INSTANCE.getModuleManager().findFirst(AntiMissModule.class);
            if (optional.isPresent() && ((AntiMissModule)optional.get()).isEnabled() && AntiMissModule.checkCondition() && (this.field_1765 == null || this.field_1765.getType() == Type.MISS)) {
               cir.setReturnValue(false);
               return;
            }
         } catch (Throwable failure3) {
         }

         DoAttackEvent doAttackEvent = new DoAttackEvent();
         MochiClient.INSTANCE.getMochiEventBus().post(doAttackEvent);
      }
   }

   @Inject(
      method = {"doAttack"},
      at = {@At("RETURN")}
   )
   public final void doAttackReturnInject(CallbackInfoReturnable<Boolean> cir) {
      if (this.reroutedAttack) {
         if (this.field_1724 != null) {
            this.field_1724.setYaw(this.preAttackYaw);
            this.field_1724.setPitch(this.preAttackPitch);
         }

         this.field_1765 = this.preAttackCrosshairTarget;
         this.reroutedAttack = false;
      }
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public final void doItemUseInject(CallbackInfo ci) {
      if (HeldItemOverride.checkCondition2()) {
         ci.cancel();
      } else if (AnchorModule.checkCondition2() && !AnchorModule.booleanState) {
         ci.cancel();
      } else {
         try {
            if (this.shouldRerouteSilentClicks() && this.field_1724 != null) {
               this.preItemUseCrosshairTarget = this.field_1765;
               this.preItemUseYaw = this.field_1724.getYaw();
               this.preItemUsePitch = this.field_1724.getPitch();
               float reroutedYaw = this.getReroutedYaw();
               float reroutedPitch = this.getReroutedPitch();
               this.field_1724.setYaw(reroutedYaw);
               this.field_1724.setPitch(reroutedPitch);
               HitResult reroutedCrosshairTarget = this.getReroutedCrosshairTarget();
               if (reroutedCrosshairTarget != null) {
                  this.field_1765 = reroutedCrosshairTarget;
               }

               this.reroutedItemUse = true;
            }
         } catch (Throwable failure) {
         }

         ItemUseEvent itemUseEvent = new ItemUseEvent();
         MochiClient.INSTANCE.getMochiEventBus().post(itemUseEvent);
         if (itemUseEvent.isCancelled()) {
            ci.cancel();
         } else {
            CombatTickBudget.enableBooleanState4();
         }
      }
   }

   @Inject(
      method = {"setWorld"},
      at = {@At("HEAD")}
   )
   public void onWorldChangeInject(ClientWorld newWorld, boolean isNewWorld, CallbackInfo ci) {
      if (this.field_1687 != newWorld) {
         IncomingPacketQueue.getINSTANCE().updateState5();
         OutgoingPacketQueue.getINSTANCE2().updateState5();
         HeldItemOverride.updateState();
         RotationManager.updateState5();
         RenderBackendManager.getINSTANCE().enableBooleanState();
      }

      if (MochiClient.INSTANCE != null && MochiClient.mc != null) {
         MochiClient.INSTANCE.getMochiEventBus().post(new WorldChangeEvent(newWorld));
      }
   }

   private HitResult getReroutedCrosshairTarget() {
      if (AnchorModule.checkCondition6()) {
         return AnchorModule.computeHitResult();
      } else {
         Optional optional = MochiClient.INSTANCE.getModuleManager().findFirst(AutoMaceModule.class);
         return optional.isPresent() && ((AutoMaceModule)optional.get()).isEnabled() && ((AutoMaceModule)optional.get()).checkCondition10() ? BlockInteractUtils.computeHitResult(RotationManager.computeFloat2(), RotationManager.computeFloat7(), 4.5) : BlockInteractUtils.computeHitResult3(RotationManager.computeFloat2(), RotationManager.computeFloat7());
      }
   }

   public MinecraftClientMixin() {
      this.reroutedAttack = false;
      this.preItemUseCrosshairTarget = null;
      this.reroutedItemUse = false;
      this.preBreakingCrosshairTarget = null;
      this.reroutedBreaking = false;
   }
}
