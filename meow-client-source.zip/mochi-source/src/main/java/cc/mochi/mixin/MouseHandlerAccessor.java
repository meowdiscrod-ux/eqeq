package cc.mochi.mixin;

import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({Mouse.class})
public interface MouseHandlerAccessor {
   @Invoker("onMouseButton")
   void press(long longValue, MouseInput mouseInput, int intValue);
}
