package cc.mochi;

import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

public record WindChargeSegment(int age, Vec3d from, Vec3d sweepEnd, HitResult hit, boolean burst) {
   public boolean getBurst2() {
      return getBurst(this);
   }

   public static HitResult getHit(WindChargeSegment windChargeSegment) {
      return windChargeSegment.hit;
   }

   public HitResult getHit2() {
      return this.hit;
   }

   public Vec3d getSweepEnd() {
      return this.sweepEnd;
   }

   public Vec3d getFrom() {
      return this.from;
   }

   public static int getAge(WindChargeSegment windChargeSegment) {
      return windChargeSegment.age;
   }

   public static boolean getBurst(WindChargeSegment windChargeSegment) {
      return windChargeSegment.burst;
   }

   public int getAge2() {
      return getAge(this);
   }

   public boolean checkCondition() {
      if (!this.burst) {
         if (getHit(this) == null) {
            return false;
         }
      }

      return true;
   }
}
