package cc.mochi;

public final class ToggleWidget {
   public static void updateStateForUiContext(UiContext uiContext, String string, float floatValue, float floatValue2, String text, ControlTone controlTone, boolean booleanValue, float floatValue3) {
      float floatValue4 = uiContext.getAnimations().exponential(string, 0.0F, booleanValue ? 1.0F : 0.0F, 0.05F);
      if (!(floatValue4 <= 0.01F)) {
         ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
         float floatValue5 = uiContext.measureText(text, TextStyle.LABEL) + 38.0F;
         Rect rect = new Rect(floatValue - floatValue5 / 2.0F, floatValue2 - 8.0F * (1.0F - floatValue4), floatValue5, 22.0F);
         float floatValue6 = floatValue3 * floatValue4;
         PanelRenderer.drawCard2(uiContext, new Rect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight()), floatValue6);
         float floatValue7 = uiContext.pulse(1.2F);
         uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(1.8F) * (0.5F + 0.5F * floatValue7) * floatValue6);
         uiContext.getUiRenderContext().fillCircle(rect.getX() + 13.0F, rect.centerY(), 3.0F, UiContext.multiplyAlpha(controlTone.computeColorForThemeSnapshot2(themeSnapshot2), floatValue6));
         uiContext.getUiRenderContext().popBloom();
         uiContext.getUiRenderContext().strokeCircle(rect.getX() + 13.0F, rect.centerY(), 3.0F + 3.0F * floatValue7, 1.0F, UiContext.multiplyAlpha(controlTone.computeColorForThemeSnapshot2(themeSnapshot2), (1.0F - floatValue7) * 0.6F * floatValue6));
         uiContext.drawVerticallyCenteredText(text, rect.getX() + 24.0F, rect.centerY(), TextStyle.LABEL, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue6));
      }
   }

   private ToggleWidget() {
   }
}
