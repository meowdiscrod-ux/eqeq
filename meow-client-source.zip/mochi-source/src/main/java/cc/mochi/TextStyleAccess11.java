package cc.mochi;

public class TextStyleAccess11 {
   public static TextStyle computeTextStyle() {
      return TextStyle.LABEL;
   }
}
