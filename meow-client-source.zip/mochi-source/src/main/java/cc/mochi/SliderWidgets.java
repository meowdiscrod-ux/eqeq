package cc.mochi;

import java.awt.Color;

public final class SliderWidgets {
   private static void updateStateForUiContext(UiContext uiContext, float x, float y, float width, float height, float floatValue5) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Color color = themeSnapshot2.getLight4() ? UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), themeSnapshot2.getPrimaryText(), 0.14F) : UiContext.blendColors(themeSnapshot2.getSurfaceSunken(), ColorAccess2.getWHITE(), 0.1F);
      uiContext.getUiRenderContext().fillRoundedRect(x, y, width, height, height / 2.0F, UiContext.multiplyAlpha(color, floatValue5));
   }

   public static void updateStateForUiContext2(UiContext uiContext, String string, float x, float centerY, float width, float floatValue4, float floatValue5, boolean booleanValue, int intValue, float floatValue6) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      boolean booleanValue2 = intValue >= 0;
      float progress = uiContext.animateToggle(string + ".e", booleanValue || booleanValue2, 0.035F);
      float floatValue8 = uiContext.getAnimations().animateTo(string + ".lo", UiContext.clampUnit(floatValue4), intValue == 0 ? 0.012F : 0.06F);
      float floatValue9 = uiContext.getAnimations().animateTo(string + ".hi", UiContext.clampUnit(floatValue5), intValue == 1 ? 0.012F : 0.06F);
      float height = UiContext.lerp(3.0F, 6.0F, progress);
      float y = centerY - height / 2.0F;
      updateStateForUiContext(uiContext, x, y, width, height, floatValue6);
      float floatValue12 = x + width * Math.min(floatValue8, floatValue9);
      float floatValue13 = x + width * Math.max(floatValue8, floatValue9);
      uiContext.getUiRenderContext().fillRoundedRect(floatValue12 - height / 2.0F, y, Math.max(height, floatValue13 - floatValue12 + height), height, height / 2.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue6));
      float radius = UiContext.lerp(2.6F, 4.2F, progress);

      for (int intValue2 = 0; intValue2 < 2; intValue2++) {
         float centerX = intValue2 == 0 ? floatValue12 : floatValue13;
         boolean booleanValue3 = intValue == intValue2;
         uiContext.getUiRenderContext().drawGlowOutline(centerX - radius, centerY - radius, radius * 2.0F, radius * 2.0F, radius, 4.0F, 1.0F, UiRenderContext.withAlpha(ColorAccess2.getBLACK(), 70.0F * floatValue6));
         if (booleanValue3) {
            uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * floatValue6);
         }

         uiContext.getUiRenderContext().fillCircle(centerX, centerY, radius + (booleanValue3 ? 0.6F : 0.0F), UiContext.multiplyAlpha(ColorAccess2.getWHITE(), floatValue6));
         if (booleanValue3) {
            uiContext.getUiRenderContext().popBloom();
         }
      }
   }

   public static void updateStateForUiContext3(UiContext uiContext, String string, float x, float centerY, float width2, float floatValue4, boolean booleanValue, boolean booleanValue2, float floatValue5) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      float progress = uiContext.animateToggle(string + ".e", booleanValue || booleanValue2, 0.035F);
      float floatValue7 = uiContext.getAnimations().animateTo(string + ".v", UiContext.clampUnit(floatValue4), booleanValue2 ? 0.012F : 0.06F);
      float height = UiContext.lerp(3.0F, 6.0F, progress);
      float y = centerY - height / 2.0F;
      updateStateForUiContext(uiContext, x, y, width2, height, floatValue5);
      float width = Math.max(height, width2 * floatValue7);
      uiContext.getUiRenderContext().fillRoundedRect(x, y, width, height, height / 2.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), floatValue5));
      float radius = 4.2F * progress;
      if (radius > 0.2F) {
         float centerX = x + width2 * floatValue7;
         uiContext.getUiRenderContext().drawGlowOutline(centerX - radius, centerY - radius, radius * 2.0F, radius * 2.0F, radius, 4.0F, 1.0F, UiRenderContext.withAlpha(ColorAccess2.getBLACK(), 80.0F * floatValue5 * progress));
         uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * progress * (booleanValue2 ? 1.0F : 0.5F) * floatValue5);
         uiContext.getUiRenderContext().fillCircle(centerX, centerY, radius, UiContext.multiplyAlpha(Color.WHITE, floatValue5));
         uiContext.getUiRenderContext().popBloom();
      }
   }

   private SliderWidgets() {
   }

   public static float computeFloat(double doubleValue, float floatValue, float floatValue2) {
      return floatValue2 <= 0.0F ? 0.0F : UiContext.clampUnit((float)((doubleValue - (double)floatValue) / (double)floatValue2));
   }
}
