package cc.mochi;

import java.awt.Color;

public record RadarMarker(float relativeX, float relativeZ, Color color, int size, String label) {
   public String getLabel() {
      return this.label;
   }

   public float getRelativeZ() {
      return this.relativeZ;
   }

   public int getSize() {
      return this.size;
   }

   public float getRelativeX() {
      return this.relativeX;
   }

   public Color getColor() {
      return this.color;
   }
}
