package cc.mochi;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;

public class StandardCharsetsAccess3 {
   public static Charset getUTF_8() {
      return StandardCharsets.UTF_8;
   }

   public static Comparator<String> getCASE_INSENSITIVE_ORDER() {
      return String.CASE_INSENSITIVE_ORDER;
   }

}
