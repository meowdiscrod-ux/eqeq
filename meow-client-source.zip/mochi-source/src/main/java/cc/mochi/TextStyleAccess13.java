package cc.mochi;

import java.awt.Color;

public class TextStyleAccess13 {
   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static Color getBLACK() {
      return Color.BLACK;
   }

}
