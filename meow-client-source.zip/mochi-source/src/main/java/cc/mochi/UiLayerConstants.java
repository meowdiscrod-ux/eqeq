package cc.mochi;

public class UiLayerConstants {
   public static UiLayer getBASE() {
      return UiLayer.BASE;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static int getIntState(ModuleBrowser moduleBrowser) {
      return moduleBrowser.intState;
   }

   public static TextStyle getTITLE() {
      return TextStyle.TITLE;
   }

   public static ConfirmationDialog getConfirmationDialog(ModuleBrowser moduleBrowser) {
      return moduleBrowser.confirmationDialog;
   }

   public static KeybindCaptureState getEMPTY() {
      return KeybindCaptureState.EMPTY;
   }

   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }

   public static KeybindCapture getKeybindCapture(ModuleBrowser moduleBrowser) {
      return moduleBrowser.keybindCapture;
   }

   public static KeybindCaptureState getCAPTURING() {
      return KeybindCaptureState.CAPTURING;
   }

}
