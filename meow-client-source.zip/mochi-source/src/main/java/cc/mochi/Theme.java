package cc.mochi;

import java.awt.Color;
import java.util.Objects;

public record Theme(
   String name,
   Color backdropDim,
   Color shellGlass,
   Color cardGlass,
   Color controlGlass,
   Color border,
   Color innerHighlight,
   Color shadow,
   Color glow,
   Color primaryText,
   Color secondaryText,
   Color disabledText,
   Color accent,
   Color secondaryAccent,
   Color gradientStart,
   Color gradientMid,
   Color gradientEnd,
   Color danger,
   boolean light
) {
   public static Color getAccent(Theme theme) {
      return theme.accent;
   }

   public boolean getLight() {
      return this.light;
   }

   public Color getControlGlass4() {
      return getControlGlass(this);
   }

   public Color getSecondaryAccent() {
      return this.secondaryAccent;
   }

   public Color getDanger() {
      return this.danger;
   }

   public static Color getShadow(Theme theme) {
      return theme.shadow;
   }

   public static Color getBorder(Theme theme) {
      return theme.border;
   }

   public Color getCardGlass() {
      return this.cardGlass;
   }

   public static Color getGradientEnd(Theme theme) {
      return theme.gradientEnd;
   }

   public Color getBorder2() {
      return getBorder(this);
   }

   public static Color getPrimaryText(Theme theme) {
      return theme.primaryText;
   }

   public boolean checkCondition() {
      return !getLight3(this);
   }

   public Color getSecondaryText() {
      return this.secondaryText;
   }

   public Color getGradientMid2() {
      return getGradientMid(this);
   }

   public Color getCardGlass32() {
      return getCardGlass2(this);
   }

   public Theme(
      String name,
      Color backdropDim,
      Color shellGlass,
      Color cardGlass,
      Color controlGlass,
      Color border,
      Color innerHighlight,
      Color shadow,
      Color glow,
      Color primaryText,
      Color secondaryText,
      Color disabledText,
      Color accent,
      Color secondaryAccent,
      Color gradientStart,
      Color gradientMid,
      Color gradientEnd,
      Color danger,
      boolean light
   ) {
      if (name != null && !name.isBlank()) {
         backdropDim = computeColorForColor("backdropDim", backdropDim);
         shellGlass = computeColorForColor("shellGlass", shellGlass);
         cardGlass = computeColorForColor("cardGlass", cardGlass);
         controlGlass = computeColorForColor("controlGlass", controlGlass);
         border = computeColorForColor("border", border);
         innerHighlight = computeColorForColor("innerHighlight", innerHighlight);
         shadow = computeColorForColor("shadow", shadow);
         glow = computeColorForColor("glow", glow);
         primaryText = computeColorForColor("primaryText", primaryText);
         secondaryText = computeColorForColor("secondaryText", secondaryText);
         disabledText = computeColorForColor("disabledText", disabledText);
         accent = computeColorForColor("accent", accent);
         secondaryAccent = computeColorForColor("secondaryAccent", secondaryAccent);
         gradientStart = computeColorForColor("gradientStart", gradientStart);
         gradientMid = computeColorForColor("gradientMid", gradientMid);
         gradientEnd = computeColorForColor("gradientEnd", gradientEnd);
         danger = computeColorForColor("danger", danger);
         this.name = name;
         this.backdropDim = backdropDim;
         this.shellGlass = shellGlass;
         this.cardGlass = cardGlass;
         this.controlGlass = controlGlass;
         this.border = border;
         this.innerHighlight = innerHighlight;
         this.shadow = shadow;
         this.glow = glow;
         this.primaryText = primaryText;
         this.secondaryText = secondaryText;
         this.disabledText = disabledText;
         this.accent = accent;
         this.secondaryAccent = secondaryAccent;
         this.gradientStart = gradientStart;
         this.gradientMid = gradientMid;
         this.gradientEnd = gradientEnd;
         this.danger = danger;
         this.light = light;
      } else {
         throw new IllegalArgumentException("Theme name cannot be blank");
      }
   }

   public static Color getControlGlass(Theme theme) {
      return theme.controlGlass;
   }

   public static Color getShellGlass(Theme theme) {
      return theme.shellGlass;
   }

   public Color getControlGlass2() {
      return this.controlGlass;
   }

   public Color getInnerHighlight() {
      return this.innerHighlight;
   }

   public Color getControlGlass3() {
      return this.controlGlass;
   }

   public Color getCardGlass22() {
      return getCardGlass2(this);
   }

   public Color getSecondaryText2() {
      return this.secondaryText;
   }

   public Color getGradientEnd2() {
      return this.gradientEnd;
   }

   public String getName() {
      return this.name;
   }

   private static Color computeColorForColor(String string, Color color) {
      Objects.requireNonNull(color, string);
      return color.getAlpha() == 255 ? color : new Color(color.getRed(), color.getGreen(), color.getBlue());
   }

   public Color getShellGlass22() {
      return getShellGlass(this);
   }

   public static Color getCardGlass2(Theme theme) {
      return theme.cardGlass;
   }

   public Color getPrimaryText3() {
      return getPrimaryText(this);
   }

   public boolean getLight2() {
      return this.light;
   }

   public Color getShadow2() {
      return getShadow(this);
   }

   public Color getGradientStart() {
      return this.gradientStart;
   }

   public Color getAccent2() {
      return getAccent(this);
   }

   public Color getGlow2() {
      return getGlow(this);
   }

   public static Color getGradientMid(Theme theme) {
      return theme.gradientMid;
   }

   public Color getDisabledText() {
      return this.disabledText;
   }

   public static Color getGradientStart2(Theme theme) {
      return theme.gradientStart;
   }

   public Color getShellGlass3() {
      return this.shellGlass;
   }

   public static boolean getLight3(Theme theme) {
      return theme.light;
   }

   public Color getBackdropDim() {
      return this.backdropDim;
   }

   public static Color getGlow(Theme theme) {
      return theme.glow;
   }

   public Color getGradientStart22() {
      return getGradientStart2(this);
   }

   public Color getShellGlass4() {
      return getShellGlass(this);
   }

   public Color getGradientEnd3() {
      return getGradientEnd(this);
   }

   public Color getPrimaryText22() {
      return getPrimaryText(this);
   }

}
