package cc.mochi;

public class ModuleBrowserAccess {
   public static ConfirmationDialog getConfirmationDialog(ModuleBrowser moduleBrowser) {
      return moduleBrowser.confirmationDialog;
   }

   public static TextInputModel getTextInputModel(ModuleBrowser moduleBrowser) {
      return moduleBrowser.textInputModel;
   }

   public static KeybindCapture getKeybindCapture(ModuleBrowser moduleBrowser) {
      return moduleBrowser.keybindCapture;
   }

   public static SettingEditor getSettingEditor(ModuleBrowser moduleBrowser) {
      return moduleBrowser.settingEditor;
   }

}
