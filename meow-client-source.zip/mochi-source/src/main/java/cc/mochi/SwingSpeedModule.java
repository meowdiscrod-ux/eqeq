package cc.mochi;

public final class SwingSpeedModule extends Module {
   public static final DoubleSetting swingSpeedSetting = new DoubleSetting("Swing Speed", 1.0, 20.0, 12.0, 1.0);

   public int intValue() {
      return swingSpeedSetting.intValue();
   }

   public SwingSpeedModule() {
      super("Swing Speed", "Modifies your swing speed", -1, ModuleCategory.RENDER);
      this.addSetting(swingSpeedSetting);
   }
}
