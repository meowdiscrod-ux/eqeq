package cc.mochi;

public enum ModuleCategory {
   COMBAT("Combat"),
   MOVEMENT("Movement"),
   PLAYER("Player"),
   RENDER("Render"),
   MISC("Misc"),
   CLIENT("Client"),
   CONFIG("Config");

   private final String name;

   public static String getName2(ModuleCategory moduleCategory) {
      return moduleCategory.name;
   }

   private static ModuleCategory[] computeModuleCategoryArray() {
      ModuleCategory[] moduleCategoryArray = new ModuleCategory[7];

      moduleCategoryArray[0] = COMBAT;
      moduleCategoryArray[1] = MOVEMENT;
      moduleCategoryArray[2] = PLAYER;

      moduleCategoryArray[3] = RENDER;

      moduleCategoryArray[4] = MISC;

      moduleCategoryArray[5] = CLIENT;

      moduleCategoryArray[6] = CONFIG;
      return moduleCategoryArray;
   }

   private ModuleCategory(String name2) {
      this.name = name2;
   }

   public String getName() {
      return getName2(this);
   }
}
