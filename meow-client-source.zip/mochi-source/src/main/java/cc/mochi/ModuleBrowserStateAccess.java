package cc.mochi;

public class ModuleBrowserStateAccess {
   public static ModuleCategory getModuleCategory(ModuleBrowser moduleBrowser) {
      return moduleBrowser.moduleCategory;
   }

   public static UiLayer getBASE() {
      return UiLayer.BASE;
   }

   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }

   public static Module getModule2(ModuleBrowser moduleBrowser) {
      return moduleBrowser.module2;
   }

   public static KeybindCaptureState getCAPTURING() {
      return KeybindCaptureState.CAPTURING;
   }

   public static boolean getBooleanState(ModuleBrowser moduleBrowser) {
      return moduleBrowser.booleanState;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static KeybindCapture getKeybindCapture(ModuleBrowser moduleBrowser) {
      return moduleBrowser.keybindCapture;
   }

   public static Icon getSEARCH() {
      return Icon.SEARCH;
   }

   public static KeybindCaptureState getEMPTY() {
      return KeybindCaptureState.EMPTY;
   }

   public static TextStyle getHEADING() {
      return TextStyle.HEADING;
   }

   public static int getCounter(ModuleBrowser moduleBrowser) {
      return moduleBrowser.counter;
   }

   public static TextInputModel getTextInputModel(ModuleBrowser moduleBrowser) {
      return moduleBrowser.textInputModel;
   }

}
