package cc.mochi;

import cc.mochi.event.types.TransferOrder;
import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class WorldRenderAccess {
   public static ClientWorld getWorld(MinecraftClient minecraftClient) {
      return minecraftClient.world;
   }

   public static double getMaxX(Box box) {
      return box.maxX;
   }

   public static FontFace getMEDIUM() {
      return FontFace.MEDIUM;
   }

   public static double getX(Vec3d vec3d) {
      return vec3d.x;
   }

   public static double getMaxY(Box box) {
      return box.maxY;
   }

   public static double getMinY(Box box) {
      return box.minY;
   }

   public static KeyBinding getJumpKey(GameOptions gameOptions) {
      return gameOptions.jumpKey;
   }

   public static KeyBinding getRightKey(GameOptions gameOptions) {
      return gameOptions.rightKey;
   }

   public static ClientPlayerInteractionManager getInteractionManager(MinecraftClient minecraftClient) {
      return minecraftClient.interactionManager;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static double getMaxZ(Box box) {
      return box.maxZ;
   }

   public static Hand getMAIN_HAND() {
      return Hand.MAIN_HAND;
   }

   public static Screen getCurrentScreen(MinecraftClient minecraftClient) {
      return minecraftClient.currentScreen;
   }

   public static HudHorizontalAlignment getCENTRE() {
      return HudHorizontalAlignment.CENTRE;
   }

   public static double getY(Vec3d vec3d) {
      return vec3d.y;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }

   public static double getMinZ(Box box) {
      return box.minZ;
   }

   public static Boolean getTRUE() {
      return Boolean.TRUE;
   }

   public static FontFace getSEMIBOLD() {
      return FontFace.SEMIBOLD;
   }

   public static double getMinX(Box box) {
      return box.minX;
   }

   public static KeyBinding getLeftKey(GameOptions gameOptions) {
      return gameOptions.leftKey;
   }

   public static TransferOrder getRECEIVE() {
      return TransferOrder.RECEIVE;
   }

   public static Boolean getFALSE() {
      return Boolean.FALSE;
   }

   public static RegistryEntry<StatusEffect> getJUMP_BOOST() {
      return StatusEffects.JUMP_BOOST;
   }

   public static HudVerticalAlignment getBOTTOM() {
      return HudVerticalAlignment.BOTTOM;
   }

}
