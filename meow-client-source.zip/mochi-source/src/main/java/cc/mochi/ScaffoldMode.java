package cc.mochi;

public enum ScaffoldMode {
   NORMAL("Normal"),
   GROUND("Grounded"),
   FORWARD("Forward"),
   TURN("Placing"),
   RETURN("Returning");

   public final String label;

   public static ScaffoldMode getRETURN() {
      return RETURN;
   }

   private static ScaffoldMode[] computeScaffoldModeArray() {
      ScaffoldMode[] scaffoldModeArray = new ScaffoldMode[5];

      scaffoldModeArray[0] = NORMAL;

      scaffoldModeArray[1] = GROUND;
      scaffoldModeArray[2] = FORWARD;

      scaffoldModeArray[3] = getTURN();

      scaffoldModeArray[4] = getRETURN();
      return scaffoldModeArray;
   }

   private ScaffoldMode(String label2) {
      this.label = label2;
   }

   public static ScaffoldMode getTURN() {
      return TURN;
   }
}
