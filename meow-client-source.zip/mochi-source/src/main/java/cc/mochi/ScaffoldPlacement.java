package cc.mochi;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public record ScaffoldPlacement(BlockPos cell, BlockPos support, Direction face, Vec3d point, float yaw, float pitch, boolean ready) {
   public float getPitch2() {
      return getPitch(this);
   }

   public Vec3d getPoint2() {
      return getPoint(this);
   }

   public BlockPos getSupport2() {
      return getSupport(this);
   }

   public static Vec3d getPoint(ScaffoldPlacement scaffoldPlacement) {
      return scaffoldPlacement.point;
   }

   public float getYaw() {
      return this.yaw;
   }

   public static boolean getReady(ScaffoldPlacement scaffoldPlacement) {
      return scaffoldPlacement.ready;
   }

   public Direction getFace() {
      return this.face;
   }

   public BlockPos getCell2() {
      return getCell(this);
   }

   public static BlockPos getSupport(ScaffoldPlacement scaffoldPlacement) {
      return scaffoldPlacement.support;
   }

   public boolean getReady2() {
      return getReady(this);
   }

   public static BlockPos getCell(ScaffoldPlacement scaffoldPlacement) {
      return scaffoldPlacement.cell;
   }

   public static float getPitch(ScaffoldPlacement scaffoldPlacement) {
      return scaffoldPlacement.pitch;
   }
}
