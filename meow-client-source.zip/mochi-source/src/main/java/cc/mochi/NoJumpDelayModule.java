package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.LivingEntityAccessor;
import meteordevelopment.orbit.EventHandler;

public class NoJumpDelayModule extends Module {
   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (!this.isWorldUnavailable()) {
         ((LivingEntityAccessor)mc.player).setJumpingCooldown(0);
      }
   }

   public NoJumpDelayModule() {
      super("No Jump Delay", "Removes the vanilla jump cooldown.", ModuleCategory.MOVEMENT);
   }
}
