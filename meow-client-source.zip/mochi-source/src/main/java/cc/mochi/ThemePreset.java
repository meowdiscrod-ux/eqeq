package cc.mochi;

import java.awt.Color;

public record ThemePreset(String name, Color background, Color surface, Color accent, Color text, boolean light) {
   public Color getSurface() {
      return this.surface;
   }

   public static String getName(ThemePreset themePreset) {
      return themePreset.name;
   }

   public static boolean getLight(ThemePreset themePreset) {
      return themePreset.light;
   }

   public String getName2() {
      return getName(this);
   }

   public Color getText() {
      return this.text;
   }

   public Color getBackground() {
      return this.background;
   }

   public static Color getText2(ThemePreset themePreset) {
      return themePreset.text;
   }

   public boolean getLight22() {
      return getLight(this);
   }

   public static Color getBackground2(ThemePreset themePreset) {
      return themePreset.background;
   }

   public Color getAccent() {
      return this.accent;
   }

   public Theme computeTheme() {
      return ThemeManager.computeThemeForColor(this.name, getBackground2(this), this.surface, this.accent, getText2(this), getLight(this));
   }
}
