package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;

public class WatermarkModule extends Module implements HudElement {
   private final BooleanSetting clockSetting;

   private final StringSetting labelSetting;

   private final BooleanSetting accentSweepSetting;
   private final HudLayout hudLayout;

   private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm");

   private final DoubleSetting bGAlphaSetting;

   private final ChoiceSetting styleSetting = new ChoiceSetting("Style", "Glass", "Glass", "Strip", "Minimal");
   private final DoubleSetting paddingSetting;

   private final BooleanSetting usernameSetting;
   private final DoubleSetting sizeSetting;
   private final BooleanSetting shadowSetting;
   private final BooleanSetting camoSetting;

   public WatermarkModule() {
      super("Watermark", "Client mark with name, user and clock", -1, ModuleCategory.RENDER);
      this.labelSetting = new StringSetting("Label", ClientText.CLIENT_NAME.toString());
      this.usernameSetting = new BooleanSetting("Username", true);
      this.clockSetting = new BooleanSetting("Clock", false);
      this.sizeSetting = new DoubleSetting("Size", 8.0, 26.0, 13.0, 0.5);
      this.paddingSetting = new DoubleSetting("Padding", 2.0, 16.0, 9.0, 1.0);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 150.0, 5.0);
      this.shadowSetting = new BooleanSetting("Shadow", true);
      this.accentSweepSetting = new BooleanSetting("Accent Sweep", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(4.0F, 4.0F, 138.0F, 30.0F);
      this.addSettings(new Setting[]{this.styleSetting, this.labelSetting, this.usernameSetting, this.clockSetting, this.sizeSetting, this.paddingSetting, this.bGAlphaSetting, this.shadowSetting, this.accentSweepSetting, this.camoSetting});
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   private static void fillRoundedRect(float x, float floatValue, float floatValue2, Color color) {
      HudBloomRenderer.fillRoundedRect(x, floatValue + 3.0F, 3.0F, floatValue2 - 6.0F, 1.5F, color);
   }

   @Override
   public float getFloatConstant2() {
      return 138.0F;
   }

   @Override
   public String computeString() {
      return this.getName();
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.LEFT, HudVerticalAlignment.TOP, 4.0F, 4.0F);
   }

   private static void fillRoundedRect2(float x, float y, float width, float height, Color color) {
      HudBloomRenderer.fillRoundedRect(x, y, width, height, 8.0F, LegacyUiTheme.createColor(color, 0.85F));
   }

   @Override
   public float getFloatConstant() {
      return 30.0F;
   }

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   private static void fillVerticalGradient(float x, float y, float height) {
      HudBloomRenderer.fillVerticalGradient(x, y, 3.0F, height, 0.0F, LegacyUiTheme.createColor(Color.WHITE, 0.0F), LegacyUiTheme.createColor(Color.WHITE, 0.75F));
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
               Color color = LegacyUiTheme.computeColorForThemeSnapshot2(themeSnapshot);
               float value = (float)this.sizeSetting.getValue();
               float size = value * 0.75F;
               float value2 = (float)this.paddingSetting.getValue();
               boolean booleanValue = this.styleSetting.equals("Glass");
               boolean booleanValue2 = this.styleSetting.equals("Strip");
               boolean booleanValue3 = this.styleSetting.equals("Minimal");
               String text = this.labelSetting.getValue3() != null && !this.labelSetting.getValue3().isBlank() ? this.labelSetting.getValue3() : ClientText.CLIENT_NAME.toString();
               text = text.toUpperCase(Locale.ROOT);
               ArrayList arrayList = new ArrayList(2);
               String string2 = mc.getSession() == null ? "" : mc.getSession().getUsername();
               if (this.usernameSetting.getValue() && !string2.isEmpty()) {
                  arrayList.add(string2);
               }

               if (this.clockSetting.getValue()) {
                  arrayList.add(LocalTime.now().format(dateTimeFormatter));
               }

               try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                  float floatValue = LegacyUiTheme.measureText(text, value, LegacyUiTheme.fontFace2);
                  float floatValue2 = 0.0F;

                  for (String text2 : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(arrayList)) {
                     floatValue2 += 10.0F + LegacyUiTheme.measureText(text2, size, LegacyUiTheme.fontFace);
                  }

                  float floatValue3 = booleanValue3 ? 9.0F : 12.0F;
                  float width = Math.max(booleanValue3 ? 0.0F : 60.0F, floatValue3 + floatValue + floatValue2 + value2 + 3.0F);
                  float height = Math.max(LegacyUiTheme.measureFontHeight(value, LegacyUiTheme.fontFace2) + value2 * 2.0F, 16.0F);
                  this.updateState4(width, height);
                  float x = this.hudLayout.getX();
                  float y = this.hudLayout.getY();
                  float centerY = y + height / 2.0F;
                  if (booleanValue3) {
                     LegacyUiTheme.updateStateForRunnable2(() -> fillRoundedRect(x, y, height, color));
                  } else {
                     LegacyUiTheme.updateStateForThemeSnapshot(x, y, width, height, (int)this.bGAlphaSetting.getValue(), true, this.shadowSetting.getValue(), this.camoSetting.getValue(), booleanValue, themeSnapshot);
                     if (booleanValue2) {
                        HudBloomRenderer.pushClip(x, y + height - 2.0F, width, 2.0F);
                        LegacyUiTheme.updateStateForRunnable(0.6F, () -> fillRoundedRect2(x, y, width, height, color));
                        HudBloomRenderer.popClip();
                     }
                  }

                  float x2 = x + floatValue3;
                  LegacyUiTheme.drawText2(text, x2, centerY, value, Color.WHITE, LegacyUiTheme.fontFace2);
                  x2 += floatValue;

                  for (String text3 : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(arrayList)) {
                     x2 += 10.0F;
                     HudBloomRenderer.fillCircle(x2 - 5.0F, centerY, 1.0F, LegacyUiTheme.createColor(LegacyUiTheme.color5, 0.5F));
                     LegacyUiTheme.drawText2(text3, x2, centerY + 0.4F, size, LegacyUiTheme.color5, LegacyUiTheme.fontFace);
                     x2 += LegacyUiTheme.measureText(text3, size, LegacyUiTheme.fontFace);
                  }

                  if (this.accentSweepSetting.getValue() && !booleanValue3 && (booleanValue || booleanValue2)) {
                     float floatValue4 = (float)System.nanoTime() / 1.0E9F / 3.2F % 1.0F;
                     if (booleanValue) {
                        float height2 = Math.max(8.0F, height * 0.6F);
                        float y2 = y - height2 + (height + height2) * floatValue4;
                        HudBloomRenderer.pushClip(x, y, 3.0F, height);
                        LegacyUiTheme.updateStateForRunnable(1.2F, () -> fillVerticalGradient(x, y2, height2));
                        HudBloomRenderer.popClip();
                     } else {
                        float width2 = Math.max(18.0F, width * 0.3F);
                        float x3 = x - width2 + (width + width2) * floatValue4;
                        HudBloomRenderer.pushClip(x, y + height - 2.0F, width, 2.0F);
                        LegacyUiTheme.updateStateForRunnable(1.2F, () -> fillHorizontalGradient(x3, y, height, width2));
                        HudBloomRenderer.popClip();
                     }
                  }
               }
            }
         }
      }
   }

   private static void fillHorizontalGradient(float x, float floatValue, float floatValue2, float width) {
      HudBloomRenderer.fillHorizontalGradient(x, floatValue + floatValue2 - 2.0F, width, 2.0F, 0.0F, LegacyUiTheme.createColor(Color.WHITE, 0.0F), LegacyUiTheme.createColor(Color.WHITE, 0.8F));
   }
}
