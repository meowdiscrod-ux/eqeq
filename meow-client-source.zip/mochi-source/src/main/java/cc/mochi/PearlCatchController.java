package cc.mochi;

import cc.mochi.event.impl.combat.PearlThrowEvent;
import cc.mochi.event.impl.combat.ShieldDrainEvent;
import cc.mochi.event.impl.player.MovementSendEvent;
import cc.mochi.mixin.ClientPlayerInteractionManagerMixin;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult.Success;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class PearlCatchController implements MinecraftAccess {
   private Set<Integer> integerSet;

   private boolean booleanState;

   private boolean booleanState2;

   private ProjectilePath projectilePath;

   private long currentTick223;

   private final Object object;

   private PearlCatchOptions pearlCatchOptions;

   private PearlCatchSolution pearlCatchSolution;

   private FlickState flickState;

   private boolean booleanState3;
   private float floatState;

   private boolean booleanState4;

   private long longState;

   private int intState;

   private ClientWorld clientWorld;

   private long currentTick224;

   private int intState2;

   private long longState2;

   private volatile int id;

   private int selectedSlot;

   private long currentTick225;

   private int intState3;

   private final AtomicReference<EntityMotionSnapshot> atomicReference = new AtomicReference<>();

   private float yaw3;

   private ClientPlayerEntity clientPlayerEntity;

   private int intState4;

   private Vec3d vec3d;
   private String string;

   private int intState5;
   private boolean booleanState5;

   private void updateState() {
      if (!getBooleanState4(this) && this.projectilePath != null) {
         ThreadLocalRandom.current().nextInt(13);
         EntityMotionSnapshot andSet = getAtomicReference(this).getAndSet(null);
         if (andSet == null) {
            Iterator iterator = MinecraftClientAccess52.getWorld(mc).getEntities().iterator();

            while (iterator.hasNext()) {
               ThreadLocalRandom.current().nextInt(3);

               Entity entity = (Entity)iterator.next();
               if (entity instanceof EnderPearlEntity) {
                  EnderPearlEntity entity2 = (EnderPearlEntity)entity;
                  if (entity2.getOwner() == getClientPlayerEntity(this)) {
                     if (!entity2.isRemoved() && !this.integerSet.contains(entity2.getId())) {
                        ThreadLocalRandom.current().nextInt(14);
                        andSet = new EntityMotionSnapshot(entity2.getId(), entity2.getEntityPos(), entity2.getVelocity());

                        break;
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(17);
               }
            }
         }

         if (andSet != null) {
            int intValue = this.computeIntForVec3d(andSet.getPosition2());
            if (!(intValue < 0)) {
               this.projectilePath = ProjectileSimulator.computeProjectileSimulatorForWorld2(MinecraftClientAccess52.getWorld(mc), getClientPlayerEntity(this), mc.world.getEntityById(andSet.getId()), andSet.getPosition2(), andSet.getVelocity(), intValue, getProjectilePath(this).checkCondition(intValue)).computeProjectilePath(160);
               setBooleanState4(this, true);
               setIntState(this, andSet.getId());
               setId(this, Integer.MIN_VALUE);
            }
         }
      }
   }

   public static float getYaw3(PearlCatchController pearlCatchController) {
      return pearlCatchController.yaw3;
   }

   public static PearlCatchOptions getPearlCatchOptions(PearlCatchController pearlCatchController) {
      return pearlCatchController.pearlCatchOptions;
   }

   public void updateStateForPacket(Packet packet) {
      int id2 = this.id;

      if (id2 != Integer.MIN_VALUE) {
         if (packet instanceof EntitySpawnS2CPacket var3) {
            if (var3.getEntityType() == EntityType.ENDER_PEARL) {
               if (var3.getEntityData() == id2) {
                  this.atomicReference.compareAndSet(null, new EntityMotionSnapshot(var3.getEntityId(), new Vec3d(var3.getX(), var3.getY(), var3.getZ()), var3.getVelocity()));
                  return;
               }
            }
         }
      }
   }

   public static void setBooleanState2(PearlCatchController pearlCatchController, boolean booleanState22) {
      pearlCatchController.booleanState2 = booleanState22;
   }

   public static boolean getBooleanState3(PearlCatchController pearlCatchController) {
      return pearlCatchController.booleanState3;
   }

   private boolean checkCondition() {
      ShieldDrainEvent shieldDrainEvent = new ShieldDrainEvent();
      MochiClient.INSTANCE.getMochiEventBus().post(shieldDrainEvent);
      return shieldDrainEvent.isActive();
   }

   public static ClientPlayerEntity getClientPlayerEntity(PearlCatchController pearlCatchController) {
      return pearlCatchController.clientPlayerEntity;
   }

   public static ProjectilePath getProjectilePath(PearlCatchController pearlCatchController) {
      return pearlCatchController.projectilePath;
   }

   private void updateState2() {
      if (getPearlCatchSolution(this) != null) {
         setIntState3(this, getIntState(this));
         long longValue = this.currentTick225 + (long)this.pearlCatchSolution.getCatchAge();

         setLongState(this, longValue + (3L));
      }

      if (this.pearlCatchOptions.getSwapBack()) {
         this.updateState8();
      } else {
         ThreadLocalRandom.current().nextInt(13);
      }

      RotationManager.updateState9(getObject(this));
      setString(this, "Charge thrown");
      this.updateState6();
   }

   public static FlickState getFlickState(PearlCatchController pearlCatchController) {
      return pearlCatchController.flickState;
   }

   public static Object getObject(PearlCatchController pearlCatchController) {
      return pearlCatchController.object;
   }

   public static int getSelectedSlot(PearlCatchController pearlCatchController) {
      return pearlCatchController.selectedSlot;
   }

   private void updateState3() {
      if (!getPearlCatchOptions(this).getMacro()) {
         if (this.flickState != FlickState.IDLE) {
            if (getClientPlayerEntity(this) != null) {
               if (this.currentTick224 != ActionSchedulers.getCurrentTick22()) {
                  int intValue;
                  switch (getFlickState(this)) {
                     case PREPARE:
                        intValue = (this.checkCondition8(this.computeFloat3(), this.computeFloat(), this.pearlCatchOptions.getFlickSpeed2())) ? 1 : 0;
                        break;
                     case FLICK:
                        if (getPearlCatchSolution(this) != null) {
                           if (!this.checkCondition8(getPearlCatchSolution(this).getYaw(), getPearlCatchSolution(this).getPitch(), this.computeFloat2())) {
                              intValue = 0;
                              break;
                           }
                        }

                        intValue = 1;
                        break;
                     case DONE:
                        intValue = 13;
                        ThreadLocalRandom.current().nextInt(7);
                        if (getPearlCatchSolution(this) != null && !this.checkCondition8(this.pearlCatchSolution.getYaw(), this.pearlCatchSolution.getPitch(), 1.4F)) {
                           intValue = 0;
                        } else {
                           intValue = 1;
                        }
                        break;
                     default:
                        intValue = 1;
                  }

                  int intValue2 = intValue;
                  if (intValue2 == 0) {
                     this.updateState12("Look held elsewhere");
                  }

                  return;
               }

               ThreadLocalRandom.current().nextInt(7);
            }
         }
      }
   }

   private boolean checkCondition2() {
      if (MinecraftClientAccess52.getPlayer(mc) != null) {
         if (MinecraftClientAccess52.getWorld(mc) != null) {
            if (mc.interactionManager != null) {
               if (mc.currentScreen == null) {
                  if (MinecraftClientAccess52.getPlayer(mc).isAlive()) {
                     if (!MinecraftClientAccess52.getPlayer(mc).isSpectator()) {
                        ThreadLocalRandom.current().nextInt(10);
                        return true;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private PearlCatchSolution computePearlCatchSolutionForMovementSnapshot(int intValue, MovementSnapshot movementSnapshot) {
      float yaw32 = this.yaw3;
      float floatState2 = this.floatState;
      double doubleValue = computeDouble();

      int intValue2 = (int)Math.floor((1.399999976158142) / doubleValue);
      int intValue3 = Math.max(1, (intValue2 + 3) / 4);
      RotationLimit rotationLimit = RotationLimit.createRotationLimit(yaw32, floatState2);
      ArrayList arrayList = new ArrayList();
      int intValue4 = -intValue2;

      while (intValue4 <= intValue2) {
         for (int intValue5 = -intValue2; intValue5 <= intValue2; intValue5 += intValue3) {
            arrayList.add(computeFloatArray(yaw32, floatState2, intValue4, intValue5, doubleValue));
         }

         intValue4 += intValue3;
      }

      if (getPearlCatchSolution(this) != null) {
         arrayList.add(computeFloatArray(yaw32, floatState2, clamp(MathHelper.wrapDegrees(getPearlCatchSolution(this).getYaw() - yaw32), doubleValue, intValue2), clamp(this.pearlCatchSolution.getPitch() - floatState2, doubleValue, intValue2), doubleValue));
      }

      PearlCatchSolution pearlCatchSolution2 = PearlCatchSolver.computePearlCatchSolutionForWorld3(mc.world, getClientPlayerEntity(this), getProjectilePath(this), intValue, movementSnapshot, this.pearlCatchOptions.getMaxCatch2(), arrayList, rotationLimit);
      if (pearlCatchSolution2 != null && intValue3 != 1) {
         int intValue6 = clamp(MathHelper.wrapDegrees(pearlCatchSolution2.getYaw() - yaw32), doubleValue, intValue2);
         int intValue7 = clamp(pearlCatchSolution2.getPitch() - floatState2, doubleValue, intValue2);
         arrayList.clear();
         int intValue8 = ~intValue2 + 1;
         int intValue9 = intValue6 - intValue3;

         int intValue10 = Math.max(intValue8, intValue9 + 1);

         while (true) {
            int intValue11 = intValue6 + intValue3;

            if (intValue10 > Math.min(intValue2, intValue11 - 1)) {
               PearlCatchSolution pearlCatchSolution3 = PearlCatchSolver.computePearlCatchSolutionForWorld3(MinecraftClientAccess52.getWorld(mc), getClientPlayerEntity(this), getProjectilePath(this), intValue, movementSnapshot, this.pearlCatchOptions.getMaxCatch2(), arrayList, rotationLimit);
               if (pearlCatchSolution3 != null && pearlCatchSolution3.computeDouble() >= pearlCatchSolution2.computeDouble()) {
         return pearlCatchSolution3;
      } else {
         return pearlCatchSolution2;
      }
            }

            for (int intValue12 = Math.max(-intValue2, intValue7 - intValue3 + 1); intValue12 <= Math.min(intValue2, intValue7 + intValue3 - 1); intValue12++) {
               arrayList.add(computeFloatArray(yaw32, floatState2, intValue10, intValue12, doubleValue));
            }

            intValue10++;
         }
      } else {
         return pearlCatchSolution2;
      }
   }

   public static FlickState getIDLE() {
      return FlickState.IDLE;
   }

   public static PearlCatchSolution getPearlCatchSolution(PearlCatchController pearlCatchController) {
      return pearlCatchController.pearlCatchSolution;
   }

   public String computeString() {
      String string2 = String.valueOf(this.flickState);
      boolean booleanState42 = this.booleanState4;
      String string3;
      if (getPearlCatchSolution(this) == null) {
         string3 = "none";
      } else {
         float yaw = this.pearlCatchSolution.getYaw();
         float pitch = getPearlCatchSolution(this).getPitch();
         int throwAge2 = getPearlCatchSolution(this).getThrowAge2();
         float confidence2 = this.pearlCatchSolution.getConfidence2();
         int catchAge = this.pearlCatchSolution.getCatchAge();
         int throwAge22 = throwAge2;
         float pitch2 = pitch;
         float yaw2 = yaw;
         string3 = yaw2 + "/" + pitch2 + " throw@" + throwAge22 + " catch@" + catchAge + " conf=" + confidence2;
      }

      long currentTick22 = ActionSchedulers.getCurrentTick22();
      long currentTick2252 = this.currentTick225;
      String string4 = getString(this);
      long currentTick22522 = currentTick2252;
      long currentTick222 = currentTick22;
      String string32 = string3;
      boolean booleanState422 = booleanState42;
      String string22 = string2;
      return string22 + " refined=" + booleanState422 + " plan=" + string32 + " tick=" + currentTick222 + " shot=" + currentTick22522 + " outcome=" + string4;
   }

   private void updateState4() {
      int intValue = (int)(ActionSchedulers.getCurrentTick22() - getCurrentTick225(this));
      if (this.checkCondition2()) {
         if (mc.world == this.clientWorld) {
            if (this.clientPlayerEntity == mc.player && getClientPlayerEntity(this).getInventory().getSelectedSlot() == getSelectedSlot(this)) {
               if (intValue > getPearlCatchOptions(this).max()) {
                  ThreadLocalRandom.current().nextInt(16);
                  this.updateState12("Charge not thrown in time");
                  return;
               }

               if (!getClientPlayerEntity(this).getInventory().getStack(this.intState5).isOf(MinecraftClientAccess52.getWIND_CHARGE())) {
                  setIntState5(this, this.computeIntForItem(Items.WIND_CHARGE));
                  if (this.intState5 < 0) {
                     this.updateState12("No wind charge");
                     return;
                  }
               }

               if (intValue >= getPearlCatchOptions(this).getMinDelay()) {
                  if (!this.checkCondition7()) {
                     if (CombatTickBudget.checkCondition4()) {
                        if (!getClientPlayerEntity(this).isUsingItem() && !this.checkCondition3(getIntState5(this))) {
                           if (!this.checkCondition() && !getBooleanState3(this)) {
                              if (this.testItem2(this.intState5, Items.WIND_CHARGE)) {
                                 setFlickState(this, FlickState.DONE);
                              }

                              return;
                           }
                        }
                     }
                  }
               }

               return;
            }
         }
      }

      this.updateState12("Slot lost");
   }

   public static Vec3d getVec3d(PearlCatchController pearlCatchController) {
      return pearlCatchController.vec3d;
   }

   public static float getFloatState(PearlCatchController pearlCatchController) {
      return pearlCatchController.floatState;
   }

   public static void setPearlCatchSolution(PearlCatchController pearlCatchController, PearlCatchSolution pearlCatchSolution2) {
      pearlCatchController.pearlCatchSolution = pearlCatchSolution2;
   }

   private void updateState5() {
      if (this.checkCondition2() && !mc.player.isUsingItem()) {
         if (!this.checkCondition7()) {
            int intState42 = this.computeIntForItem(Items.ENDER_PEARL);
            int intState52 = this.computeIntForItem(Items.WIND_CHARGE);
            if (intState42 >= 0 && intState52 >= 0) {
               if (!this.checkCondition3(intState42)) {
                  if (!this.checkCondition3(intState52)) {
                     if (!this.pearlCatchOptions.getMacro()) {
                        if (RotationManager.getBooleanState() && RotationManager.computeVec3d(getObject(this)) == null) {
                           return;
                        }
                     }

                     this.clientPlayerEntity = mc.player;
                     setClientWorld(this, MinecraftClientAccess52.getWorld(mc));
                     setIntState4(this, intState42);
                     setIntState5(this, intState52);
                     this.intState2 = this.selectedSlot = this.clientPlayerEntity.getInventory().getSelectedSlot();
                     setLongState22(this, ActionSchedulers.getCurrentTick22());
                     this.string = "Running";
                     if (!getPearlCatchOptions(this).getMacro()) {
                        if (RotationManager.computeVec3d(this.object) != null) {
                           this.flickState = FlickState.PREPARE;

                           this.booleanState2 = false;
                           return;
                        }

                        ThreadLocalRandom.current().nextInt(5);
                     }

                     this.updateState13();
                     if (this.flickState != FlickState.IDLE) {
                        setBooleanState2(this, false);
                     }

                     return;
                  }
               }
            }

            return;
         }
      }
   }

   private float computeFloat() {
      ThreadLocalRandom.current().nextInt(8);
      if (RotationManager.checkCondition4()) {
         return RotationManager.computeFloat();
      } else {
         return mc.player.getPitch();
      }
   }

   public static void setIntState4(PearlCatchController pearlCatchController, int intState42) {
      pearlCatchController.intState4 = intState42;
   }

   public static void setClientWorld(PearlCatchController pearlCatchController, ClientWorld clientWorld2) {
      pearlCatchController.clientWorld = clientWorld2;
   }

   private boolean testItem(Item item, long longValue) {
      if (this.clientPlayerEntity != null && this.clientPlayerEntity == MinecraftClientAccess52.getPlayer(mc)) {
         if (MinecraftClientAccess52.getWorld(mc) == getClientWorld(this)
            && mc.interactionManager != null
            && longValue == ActionSchedulers.getCurrentTick22()
            && getClientPlayerEntity(this).getMainHandStack().isOf(item)
            && !this.clientPlayerEntity.getItemCooldownManager().isCoolingDown(this.clientPlayerEntity.getMainHandStack())) {
            if (!this.clientPlayerEntity.isUsingItem()) {
               if (CombatTickBudget.checkCondition4()) {
                  if (!this.pearlCatchOptions.getMacro()) {
                     if (RotationManager.computeVec3d(this.object) == null) {
                        return false;
                     }
                  }

                  ActionResult actionResult = mc.interactionManager.interactItem(getClientPlayerEntity(this), Hand.MAIN_HAND);
                  if (!actionResult.isAccepted()) {
                     return false;
                  }

                  ThreadLocalRandom.current().nextInt(3);
                  CombatTickBudget.enableBooleanState4();
                  if (actionResult instanceof Success var5 && var5.swingSource() == MinecraftClientAccess52.getCLIENT()) {
                     getClientPlayerEntity(this).swingHand(Hand.MAIN_HAND);

                     ThreadLocalRandom.current().nextInt(9);
                  }

                  if (item == Items.ENDER_PEARL) {
                     MochiClient.INSTANCE.getMochiEventBus().post(new PearlThrowEvent());
                  }

                  return true;
               }
            }
         }
      }

      return false;
   }

   public static long getCurrentTick223(PearlCatchController pearlCatchController) {
      return pearlCatchController.currentTick223;
   }

   public static AtomicReference<EntityMotionSnapshot> getAtomicReference(PearlCatchController pearlCatchController) {
      return pearlCatchController.atomicReference;
   }

   private static double computeDouble() {
      double doubleValue = (double)RotationMath.computeFloat2((Double)mc.options.getMouseSensitivity().getValue());
      double doubleValue2;
      if (doubleValue > 0.0) {
         doubleValue2 = doubleValue;
      } else {
         ThreadLocalRandom.current().nextInt(17);

         doubleValue2 = (0.05);
      }

      return doubleValue2;
   }

   private void updateState6() {
      this.flickState = FlickState.IDLE;
      setClientPlayerEntity(this, null);
      this.clientWorld = null;
      int intState52 = this.selectedSlot = -1;
      setIntState2(this, intState52);
      this.intState4 = this.intState5 = intState52;

      setCurrentTick225(this, (-9223372036854775808L));
      setLongState22(this, (-9223372036854775808L));
      setProjectilePath(this, null);
      this.booleanState4 = false;

      this.intState = -1;
      setPearlCatchSolution(this, null);

      setBooleanState3(this, false);
      this.id = Integer.MIN_VALUE;
      this.atomicReference.set(null);
      setIntegerSet(this, Set.of());
   }

   private static int clamp(float floatValue, double doubleValue, int intValue) {
      return MathHelper.clamp((int)Math.round((double)floatValue / doubleValue), -intValue, intValue);
   }

   private void updateState7() {
      if (getBooleanState3(this)) {
         this.booleanState3 = false;
         this.updateState12("Use expired");
      } else {
         ThreadLocalRandom.current().nextInt(17);
      }
   }

   private boolean checkCondition3(int intValue) {
      byte byteValue = 21;
      ThreadLocalRandom.current().nextInt(16);

      if (intValue >= 0) {
         if (MinecraftClientAccess52.getPlayer(mc) != null) {
            ItemStack stack = mc.player.getInventory().getStack(intValue);
            if (!stack.isEmpty() && !mc.player.getItemCooldownManager().isCoolingDown(stack)) {
               byteValue = 0;
            } else {
               byteValue = 1;
            }

            return (byteValue != 0);
         }
      }

      return true;
   }

   public static String getString(PearlCatchController pearlCatchController) {
      return pearlCatchController.string;
   }

   private int computeIntForVec3d(Vec3d vec3d2) {
      int startAge2 = this.projectilePath.getStartAge2();
      double maxValue = Double.MAX_VALUE;

      for (int startAge22 = getProjectilePath(this).getStartAge2(); startAge22 <= this.projectilePath.getStartAge2() + 4; startAge22++) {
         Vec3d vec3d3 = getProjectilePath(this).computeVec3d(startAge22);
         if (vec3d3 == null) {
            break;
         }

         double doubleValue = vec3d3.squaredDistanceTo(vec3d2);
         if (doubleValue < maxValue) {
            maxValue = doubleValue;
            startAge2 = startAge22;
         }
      }

      if (maxValue <= (1.0)) {
         return startAge2;
      } else {
         return -1;
      }
   }

   private boolean checkCondition4() {
      int intValue = this.computeIntForItem(Items.ENDER_PEARL);
      int intValue2 = this.computeIntForItem(MinecraftClientAccess52.getWIND_CHARGE());
      if (intValue >= 0) {
         if (intValue2 >= 0) {
            if (this.checkCondition3(intValue)) {
               return true;
            }

            if (this.checkCondition3(intValue2)) {
               return true;
            }
         }
      }

      if (this.longState == Long.MIN_VALUE) {
         return false;
      } else {
         label65:
         if (ActionSchedulers.getCurrentTick22() <= getLongState(this)) {
            Entity entityById;
            if (getIntState3(this) >= 0) {
               entityById = mc.world.getEntityById(this.intState3);
            } else {
               entityById = null;
            }

            Entity entityById2 = entityById;
            if (getIntState3(this) >= 0) {
               ThreadLocalRandom.current().nextInt(4);
               if (entityById2 == null) {
                  break label65;
               }

               if (entityById2.isRemoved()) {
                  break label65;
               }
            }

            return true;
         } else {
         }

         setIntState3(this, -1);

         setLongState(this, (-9223372036854775808L));
         return false;
      }
   }

   private float computeFloat2() {
      float floatValue = MathHelper.wrapDegrees(this.pearlCatchSolution.getYaw() - this.yaw3);
      float floatValue2 = this.pearlCatchSolution.getPitch() - getFloatState(this);
      float floatValue3 = (float)Math.sqrt((double)(floatValue * floatValue + floatValue2 * floatValue2));
      int intValue = (int)(ActionSchedulers.getCurrentTick22() - getCurrentTick225(this));
      int intValue2 = Math.max(1, getPearlCatchSolution(this).getThrowAge2() - intValue);
      return Math.min(getPearlCatchOptions(this).getFlickSpeed2(), Math.max(0.1F, floatValue3 / (float)intValue2));
   }

   public static void setProjectilePath(PearlCatchController pearlCatchController, ProjectilePath projectilePath2) {
      pearlCatchController.projectilePath = projectilePath2;
   }

   public static int getIntState3(PearlCatchController pearlCatchController) {
      return pearlCatchController.intState3;
   }

   public static int getIntState5(PearlCatchController pearlCatchController) {
      return pearlCatchController.intState5;
   }

   public static boolean getBooleanState2(PearlCatchController pearlCatchController) {
      return pearlCatchController.booleanState2;
   }

   public static void setLongState(PearlCatchController pearlCatchController, long longState3) {
      pearlCatchController.longState = longState3;
   }

   public static void setFlickState(PearlCatchController pearlCatchController, FlickState flickState2) {
      pearlCatchController.flickState = flickState2;
   }

   public static void setIntState5(PearlCatchController pearlCatchController, int intState52) {
      pearlCatchController.intState5 = intState52;
   }

   public static void setCurrentTick225(PearlCatchController pearlCatchController, long currentTick2252) {
      pearlCatchController.currentTick225 = currentTick2252;
   }

   public static void setYaw3(PearlCatchController pearlCatchController, float yaw32) {
      pearlCatchController.yaw3 = yaw32;
   }

   private void updateState8() {
      if (getClientPlayerEntity(this) != null) {
         if (this.clientPlayerEntity == mc.player && mc.interactionManager != null) {
            if (this.intState2 >= 0) {
               ThreadLocalRandom.current().nextInt(12);
               if (getSelectedSlot(this) != this.intState2 && this.clientPlayerEntity.getInventory().getSelectedSlot() == this.selectedSlot) {
                  if (CombatTickBudget.checkCondition2()) {
                     ThreadLocalRandom.current().nextInt(11);
                     this.clientPlayerEntity.getInventory().setSelectedSlot(getIntState22(this));
                     ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)mc.interactionManager).mochi$syncSelectedSlot();
                     CombatTickBudget.setBooleanState222();
                  } else {
                     CombatTickBudget.updateState6(this.intState2);
                  }

                  this.selectedSlot = this.intState2;
                  return;
               }
            }
         }
      }
   }

   private int computeIntForItem(Item item) {
      if (mc.player == null) {
         return -1;
      } else {
         int intValue = 0;

         while (true) {
            if (intValue >= 9) {
               return -1;
            }

            ItemStack stack = mc.player.getInventory().getStack(intValue);
            if (!stack.isEmpty()) {
               if (stack.isOf(item)) {
                  return intValue;
               }
            }

            intValue++;
         }
      }
   }

   private static float[] computeFloatArray(float floatValue, float floatValue2, int intValue, int intValue2, double doubleValue) {
      float[] floatArray = new float[]{floatValue + (float)((double)intValue * doubleValue), 0.0F};

      floatArray[1] = MathHelper.clamp(floatValue2 + (float)((double)intValue2 * doubleValue), ((-90.0F)), 90.0F);
      return floatArray;
   }

   public static void setClientPlayerEntity(PearlCatchController pearlCatchController, ClientPlayerEntity clientPlayerEntity2) {
      pearlCatchController.clientPlayerEntity = clientPlayerEntity2;
   }

   private MovementSnapshot createMovementSnapshot() {
      return new MovementSnapshot(ProjectileLaunchMath.createVec3d2(this.clientPlayerEntity.getEntityPos(), this.computeDouble2()), getVec3d(this), getClientPlayerEntity(this).isOnGround());
   }

   public boolean checkCondition5() {
      byte byteValue;
      if (getFlickState(this) != FlickState.IDLE) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      ThreadLocalRandom.current().nextInt(12);
      return (byteValue != 0);
   }

   public static FlickState getPREPARE() {
      return FlickState.PREPARE;
   }

   public void updateState9() {
      this.updateState12("Stopped");
      setBooleanState2(this, false);

      this.currentTick223 = Long.MIN_VALUE;

      this.intState3 = -1;

      this.longState = (-9223372036854775808L);
      this.booleanState = false;
      setBooleanState5(this, false);
      setVec3d(this, Vec3d.ZERO);
   }

   public static void setPearlCatchOptions(PearlCatchController pearlCatchController, PearlCatchOptions pearlCatchOptions2) {
      pearlCatchController.pearlCatchOptions = pearlCatchOptions2;
   }

   public static void setIntState(PearlCatchController pearlCatchController, int intState6) {
      pearlCatchController.intState = intState6;
   }

   public static long getLongState(PearlCatchController pearlCatchController) {
      return pearlCatchController.longState;
   }

   public static void setBooleanState3(PearlCatchController pearlCatchController, boolean booleanState32) {
      pearlCatchController.booleanState3 = booleanState32;
   }

   public static int getIntState(PearlCatchController pearlCatchController) {
      return pearlCatchController.intState;
   }

   public static void setIntState2(PearlCatchController pearlCatchController, int intState22) {
      pearlCatchController.intState2 = intState22;
   }

   public static void setLongState22(PearlCatchController pearlCatchController, long longState22) {
      pearlCatchController.longState2 = longState22;
   }

   public static boolean getBooleanState5(PearlCatchController pearlCatchController) {
      return pearlCatchController.booleanState5;
   }

   private boolean checkCondition6() {
      if (this.checkCondition2()) {
         if (mc.world == this.clientWorld && this.clientPlayerEntity == mc.player) {
            if (this.projectilePath != null) {
               ThreadLocalRandom.current().nextInt(8);

               if (this.clientPlayerEntity.getInventory().getSelectedSlot() == getSelectedSlot(this)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public static long getCurrentTick225(PearlCatchController pearlCatchController) {
      return pearlCatchController.currentTick225;
   }

   public static void setIntState3(PearlCatchController pearlCatchController, int intState32) {
      pearlCatchController.intState3 = intState32;
   }

   private void updateState10() {
      if (this.pearlCatchOptions.getMacro()) {
         this.updateState4();
      } else {
         int intValue = (int)(ActionSchedulers.getCurrentTick22() - getCurrentTick225(this));
         if (this.checkCondition6()) {
            if (!this.checkCondition9()) {
               if (intValue > getPearlCatchOptions(this).max()) {
                  this.updateState12("No catch in time");
                  return;
               }

               if (!this.clientPlayerEntity.getInventory().getStack(getIntState5(this)).isOf(Items.WIND_CHARGE)) {
                  setIntState5(this, this.computeIntForItem(Items.WIND_CHARGE));
                  if (this.intState5 < 0) {
                     this.updateState12("No wind charge");
                     return;
                  }
               }

               PearlCatchSolution pearlCatchSolution2;
               byte byteValue;
               label91: {
                  this.updateState();
                  pearlCatchSolution2 = this.computePearlCatchSolutionForProjectilePath(this.projectilePath, intValue, this.yaw3, getFloatState(this));
                  if (!this.booleanState4 && pearlCatchSolution2 != null) {
                     if (intValue < this.pearlCatchOptions.getMinDelay() + getPearlCatchOptions(this).getSpawnWait()) {
                        byteValue = 1;
                        break label91;
                     }
                  }

                  byteValue = 0;
               }

               byte byteValue2 = byteValue;
               if (intValue >= getPearlCatchOptions(this).getMinDelay() && byteValue2 == 0 && !this.checkCondition7() && this.testPearlCatchSolution(intValue, pearlCatchSolution2)) {
                  return;
               }

               if (pearlCatchSolution2 == null) {
                  if (intValue >= this.pearlCatchOptions.getMinDelay()) {
                     return;
                  }

                  this.updateState12("No catch ahead");
                  return;
               }

               byteValue = 16;
               ThreadLocalRandom.current().nextInt(14);
               setPearlCatchSolution(this, pearlCatchSolution2);
               return;
            }
         }

         this.updateState12("Pearl or slot lost");
      }
   }

   public static void setFloatState(PearlCatchController pearlCatchController, float floatState2) {
      pearlCatchController.floatState = floatState2;
   }

   public static void setCurrentTick223(PearlCatchController pearlCatchController, long currentTick2232) {
      pearlCatchController.currentTick223 = currentTick2232;
   }

   public static void setBooleanState5(PearlCatchController pearlCatchController, boolean booleanState52) {
      pearlCatchController.booleanState5 = booleanState52;
   }

   public static boolean getBooleanState4(PearlCatchController pearlCatchController) {
      return pearlCatchController.booleanState4;
   }

   private double computeDouble2() {
      return mc.player.getEyeY() - mc.player.getY();
   }

   public static int getIntState4(PearlCatchController pearlCatchController) {
      return pearlCatchController.intState4;
   }

   public static ClientWorld getClientWorld(PearlCatchController pearlCatchController) {
      return pearlCatchController.clientWorld;
   }

   public static void setVec3d(PearlCatchController pearlCatchController, Vec3d vec3d2) {
      pearlCatchController.vec3d = vec3d2;
   }

   private boolean checkCondition7() {
      byte byteValue;
      if (this.vec3d.lengthSquared() > 16.0) {
         byteValue = 16;
         ThreadLocalRandom.current().nextInt(14);

         byteValue = 1;

         ThreadLocalRandom.current().nextInt(7);
      } else {
         byteValue = 0;

         ThreadLocalRandom.current().nextInt(9);

         ThreadLocalRandom.current().nextInt(16);
      }

      return (byteValue != 0);
   }

   private boolean checkCondition8(float floatValue, float floatValue2, float floatValue3) {
      float floatValue4 = MathHelper.wrapDegrees(floatValue - this.yaw3);
      float floatValue5 = MathHelper.clamp(floatValue2, ((-90.0F)), (90.0F)) - this.floatState;
      float floatValue6 = (float)Math.sqrt((double)(floatValue4 * floatValue4 + floatValue5 * floatValue5));
      float floatValue7 = floatValue6 > floatValue3 ? floatValue3 / floatValue6 : 1.0F;
      float floatValue8 = getYaw3(this) + floatValue4 * floatValue7;
      float floatValue9 = this.floatState + floatValue5 * floatValue7;

      float floatValue10 = MathHelper.clamp(floatValue9, ((-90.0F)), (90.0F));
      ClientPlayerEntity clientPlayerEntity7 = getClientPlayerEntity(this);
      Vec3d vec3d2 = clientPlayerEntity7.getEyePos().add(computeVec3d(floatValue8, floatValue10));
      Object object2 = getObject(this);
      ActionPriority high = ActionPriority.HIGH;
      Supplier supplier = () -> computeVec3dForClientPlayerEntity(clientPlayerEntity7, vec3d2);
      RotationProfile rotationProfile = RotationProfile.createRotationProfile();

      RotationProfile rotationProfile2 = rotationProfile.withMaxRotationSpeed((3600.0)).withSilentAim(getPearlCatchOptions(this).getSilent()).computeRotationProfile7(true);

      RotationProfile rotationProfile3 = rotationProfile2.computeRotationProfile4((0.0));

      RotationProfile rotationProfile4 = rotationProfile3.computeRotationProfile3((0.0));

      RotationManager.updateStateForActionPriority(object2, high, supplier, rotationProfile4.computeRotationProfile9((0L)));
      if (RotationManager.computeVec3d(getObject(this)) == null) {
         return false;
      } else {
         ThreadLocalRandom.current().nextInt(17);
         RotationManager.updateState11(this.object, getYaw3(this), this.floatState);
         this.currentTick224 = ActionSchedulers.getCurrentTick22();

         return true;
      }
   }

   private MovementSnapshot computeMovementSnapshot(int intValue) {
      Vec3d entityPos = MinecraftClientAccess52.getPlayer(mc).getEntityPos();
      boolean onGround = MinecraftClientAccess52.getPlayer(mc).isOnGround();
      double y2 = MinecraftClientAccess52.getY(entityPos);
      double y = this.vec3d.y;
      if (!onGround) {
         ThreadLocalRandom.current().nextInt(7);
         double y3 = MinecraftClientAccess52.getY(MinecraftClientAccess52.getPlayer(mc).getVelocity());
         int intValue2 = 0;

         while (intValue2 < intValue) {
            y2 += y3;
            y = y3;
            y3 = (y3 - 0.08) * 0.98;
            intValue2++;
         }
      }

      Vec3d vec3d2 = new Vec3d(entityPos.x + this.vec3d.x * (double)intValue, y2, MinecraftClientAccess52.getZ(entityPos) + this.vec3d.z * (double)intValue);
      return new MovementSnapshot(ProjectileLaunchMath.createVec3d2(vec3d2, this.computeDouble2()), new Vec3d(MinecraftClientAccess52.getX(getVec3d(this)), y, getVec3d(this).z), onGround);
   }

   public static void setId(PearlCatchController pearlCatchController, int id2) {
      pearlCatchController.id = id2;
   }

   public static void setString(PearlCatchController pearlCatchController, String string2) {
      pearlCatchController.string = string2;
   }

   private PearlCatchSolution computePearlCatchSolutionForProjectilePath(ProjectilePath projectilePath2, int intValue, float floatValue, float floatValue2) {
      PearlCatchSolution pearlCatchSolution32 = null;

      int intValue2 = Math.max(intValue + 1, this.pearlCatchOptions.getMinDelay());

      while (intValue2 <= getPearlCatchOptions(this).max()) {
         RotationLimit rotationLimit = new RotationLimit(floatValue, floatValue2, (float)(intValue2 - intValue) * getPearlCatchOptions(this).getFlickSpeed2() + (1.4F));
         ClientWorld world4 = MinecraftClientAccess52.getWorld(mc);
         ClientPlayerEntity player = mc.player;
         MovementSnapshot movementSnapshot = this.computeMovementSnapshot(intValue2 - intValue);
         int maxCatch2 = this.pearlCatchOptions.getMaxCatch2();

         PearlCatchSolution pearlCatchSolution3 = PearlCatchSolver.computePearlCatchSolutionForWorld2(world4, player, projectilePath2, intValue2, movementSnapshot, maxCatch2, rotationLimit, false);
         if (pearlCatchSolution3 != null) {
            if (pearlCatchSolution3.getConfidence2() < getPearlCatchOptions(this).getMinConfidence2()) {
               ThreadLocalRandom.current().nextInt(8);
            } else {
               label49: {
                  if (pearlCatchSolution32 != null) {
                     if (!(pearlCatchSolution3.computeDouble() > pearlCatchSolution32.computeDouble() + 0.1)) {
                        break label49;
                     }
                  }

                  pearlCatchSolution32 = pearlCatchSolution3;
               }

               double doubleValue = pearlCatchSolution32.computeDouble();

               if (doubleValue >= (0.9)) {
                  break;
               }
            }
         }

         intValue2++;
      }

      return pearlCatchSolution32;
   }

   public PearlCatchController(Object object2) {
      this.id = Integer.MIN_VALUE;
      this.integerSet = Set.of();
      this.flickState = FlickState.IDLE;

      this.intState4 = -1;

      this.intState5 = -1;

      this.intState2 = -1;
      this.selectedSlot = -1;

      this.longState2 = (-9223372036854775808L);

      this.currentTick225 = (-9223372036854775808L);
      this.intState = -1;
      this.vec3d = Vec3d.ZERO;

      this.currentTick223 = Long.MIN_VALUE;

      this.intState3 = -1;

      this.longState = (-9223372036854775808L);

      this.currentTick224 = Long.MIN_VALUE;
      this.string = "Idle";
      this.object = object2;
   }

   private float computeFloat3() {
      if (RotationManager.checkCondition4()) {
         return RotationManager.computeFloat6();
      } else {
         return MinecraftClientAccess52.getPlayer(mc).getYaw();
      }
   }

   public void updateStateForPearlCatchOptions(PearlCatchOptions pearlCatchOptions2, boolean booleanState6) {
      java.lang.RuntimeException runtimeException;

      setPearlCatchOptions(this, pearlCatchOptions2);
      if (mc.player != null) {
         byte byteValue = 16;
         ThreadLocalRandom.current().nextInt(10);
         if (mc.world != null) {
            if (!getBooleanState5(this)) {
               this.yaw3 = MinecraftClientAccess52.getPlayer(mc).getYaw();
               setFloatState(this, mc.player.getPitch());
            }

            this.vec3d = ProjectileLaunchMath.createVec3d(MinecraftClientAccess52.getPlayer(mc));
            long currentTick22 = ActionSchedulers.getCurrentTick22();
            if (booleanState6 && !this.booleanState) {
               setBooleanState2(this, true);
               this.currentTick223 = currentTick22;
            }

            this.booleanState = booleanState6;

            label237: {
               label214: {
                  label240: {
                     label211:
                     try {
                        if (this.flickState == FlickState.IDLE) {
                           break label211;
                        }
                        break label240;
                     } catch (RuntimeException failure) {
                        runtimeException = failure;

                        break label237;
                     }

                     try {
                        if (this.checkCondition4()) {
                           break label240;
                        }
                     } catch (RuntimeException failure2) {
                        runtimeException = failure2;

                        break label237;
                     }

                     try {
                        byteValue = 0;
                        break label214;
                     } catch (RuntimeException failure3) {
                        runtimeException = failure3;

                        break label237;
                     }
                  }

                  try {
                     byteValue = 1;
                  } catch (RuntimeException failure4) {
                     runtimeException = failure4;

                     break label237;
                  }
               }

               byte byteValue2;
               label238: {
                  try {
                     byteValue2 = byteValue;
                     if (!getBooleanState2(this)) {
                        break label238;
                     }
                  } catch (RuntimeException failure5) {
                     runtimeException = failure5;

                     break label237;
                  }

                  try {
                     if (byteValue2 == 0) {
                        break label238;
                     }
                  } catch (RuntimeException failure6) {
                     runtimeException = failure6;

                     break label237;
                  }

                  try {
                     setCurrentTick223(this, currentTick22);
                  } catch (RuntimeException failure7) {
                     runtimeException = failure7;

                     break label237;
                  }
               }

               label230: {
                  try {
                     if (!this.booleanState2) {
                        break label230;
                     }
                  } catch (RuntimeException failure8) {
                     runtimeException = failure8;

                     break label237;
                  }

                  label176: {
                     try {
                        long longValue = currentTick22 - getCurrentTick223(this);

                        if (longValue <= 10L) {
                           break label176;
                        }
                     } catch (RuntimeException failure9) {
                        runtimeException = failure9;

                        break label237;
                     }

                     try {
                        setBooleanState2(this, false);
                        break label230;
                     } catch (RuntimeException failure10) {
                        runtimeException = failure10;

                        break label237;
                     }
                  }
               }

               label231: {
                  label232: {
                     label233: {
                        label239: {
                           try {
                              switch (getFlickState(this)) {
                                 case IDLE:
                                    break;
                                 case PREPARE:
                                    break label233;
                                 case FLICK:
                                    break label239;
                                 case DONE:
                                    break label232;
                                 default:
                                    break label231;
                              }
                           } catch (RuntimeException failure11) {
                              runtimeException = failure11;

                              break label237;
                           }

                           label146: {
                              try {
                                 if (getBooleanState2(this)) {
                                    break label146;
                                 }
                              } catch (RuntimeException failure12) {
                                 runtimeException = failure12;

                                 break label237;
                              }

                              try {
                                 if (!booleanState6) {
                                    break label231;
                                 }
                              } catch (RuntimeException failure13) {
                                 runtimeException = failure13;

                                 break label237;
                              }
                           }

                           try {
                              if (byteValue2 != 0) {
                                 break label231;
                              }
                           } catch (RuntimeException failure14) {
                              runtimeException = failure14;

                              break label237;
                           }

                           try {
                              this.updateState5();
                           } catch (RuntimeException failure15) {
                              runtimeException = failure15;

                              break label237;
                           }

                           break label231;
                        }

                        try {
                           this.updateState10();
                           break label231;
                        } catch (RuntimeException failure16) {
                           runtimeException = failure16;

                           break label237;
                        }
                     }

                     try {
                        this.updateState11();
                        break label231;
                     } catch (RuntimeException failure17) {
                        runtimeException = failure17;

                        break label237;
                     }
                  }

                  try {
                     this.updateState2();
                  } catch (RuntimeException failure18) {
                     runtimeException = failure18;

                     break label237;
                  }
               }

               try {
                  this.updateState3();
                  return;
               } catch (RuntimeException failure19) {
                  runtimeException = failure19;
               }
            }

            RuntimeException runtimeException2 = runtimeException;
            String simpleName = runtimeException2.getClass().getSimpleName();
            this.updateState12("Error: " + simpleName);

            return;
         }
      }

      if (this.flickState != FlickState.IDLE) {
         this.updateState12("No world");
      }
   }

   private void updateState11() {
      if (this.checkCondition2() && mc.world == this.clientWorld) {
         long longValue = ActionSchedulers.getCurrentTick22() - this.longState2;

         if (longValue <= 20L) {
            float floatValue = (float)Math.max(0.35F, computeDouble() * 0.5 + 0.01);
            if (Math.abs(MathHelper.wrapDegrees(getYaw3(this) - this.computeFloat3())) <= floatValue) {
               if (Math.abs(this.floatState - this.computeFloat()) <= floatValue) {
                  ThreadLocalRandom.current().nextInt(9);

                  this.updateState13();
               }
            }

            return;
         }
      }

      this.updateState12("Prepare timeout");
   }

   public static int getIntState22(PearlCatchController pearlCatchController) {
      return pearlCatchController.intState2;
   }

   private static Vec3d computeVec3d(float floatValue, float floatValue2) {
      double doubleValue = Math.toRadians((double)floatValue);
      double doubleValue2 = Math.toRadians((double)floatValue2);
      double doubleValue3 = Math.cos(doubleValue2);

      double doubleValue4 = Math.max(doubleValue3, (1.0E-4));
      Vec3d vec3d2 = new Vec3d(-Math.sin(doubleValue) * doubleValue4, -Math.sin(doubleValue2), Math.cos(doubleValue) * doubleValue4);

      return vec3d2.multiply((10.0));
   }

   private void updateState12(String string2) {
      if (getFlickState(this) == FlickState.IDLE) {
         if (this.clientPlayerEntity == null) {
            return;
         }
      }

      ActionSchedulers.updateState4(this.object);
      this.updateState8();
      RotationManager.updateState9(this.object);
      setString(this, string2);
      this.updateState6();
   }

   private static Vec3d computeVec3dForClientPlayerEntity(ClientPlayerEntity clientPlayerEntity2, Vec3d vec3d2) {
      if (clientPlayerEntity2 == mc.player) {
         return vec3d2;
      } else {
         return null;
      }
   }

   private boolean testItem2(int selectedSlot2, Item item) {
      if (!this.booleanState3) {
         if (mc.interactionManager != null) {
            if (getClientPlayerEntity(this).getInventory().getSelectedSlot() != selectedSlot2) {
               if (!CombatTickBudget.checkCondition2()) {
                  return false;
               }

               this.clientPlayerEntity.getInventory().setSelectedSlot(selectedSlot2);
               ((ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)MinecraftClientAccess52.getInteractionManager(mc)).mochi$syncSelectedSlot();
               CombatTickBudget.setBooleanState222();
               this.selectedSlot = selectedSlot2;
            } else {
               ThreadLocalRandom.current().nextInt(8);
            }

            long currentTick22 = ActionSchedulers.getCurrentTick22();
            setBooleanState3(this, true);
            ActionSchedulers.schedule2(this.object, () -> this.updateStateForItem(item, currentTick22), () -> this.updateState7());
            return true;
         }
      }

      return false;
   }

   public void updateStateForAfter(MovementSendEvent.After after) {
      setBooleanState5(this, true);
      setYaw3(this, after.yaw());
      setFloatState(this, after.pitch());
   }

   private boolean testPearlCatchSolution(int intValue, PearlCatchSolution pearlCatchSolution2) {
      if (CombatTickBudget.checkCondition4()) {
         if (!this.clientPlayerEntity.isUsingItem()) {
            ThreadLocalRandom.current().nextInt(3);
            if (!this.checkCondition3(this.intState5)) {
               if (!this.checkCondition()) {
                  if (!getBooleanState3(this)) {
                     MovementSnapshot movementSnapshot = this.createMovementSnapshot();
                     PearlCatchSolution pearlCatchSolution3 = this.computePearlCatchSolutionForMovementSnapshot(intValue, movementSnapshot);
                     if (pearlCatchSolution3 != null) {
                        if (!(pearlCatchSolution3.getConfidence2() < this.pearlCatchOptions.getMinConfidence2())) {
                           if (pearlCatchSolution2 != null) {
                              if (intValue < getPearlCatchOptions(this).max()) {
                                 double doubleValue = pearlCatchSolution3.computeDouble();

                                 if (doubleValue < (0.9)) {
                                    double doubleValue2 = pearlCatchSolution2.computeDouble();
                                    double doubleValue3 = pearlCatchSolution3.computeDouble();

                                    if (doubleValue2 > doubleValue3 + (0.1)) {
                                       return false;
                                    }
                                 }
                              }
                           }

                           if (!this.checkCondition8(pearlCatchSolution3.getYaw(), pearlCatchSolution3.getPitch(), 180.0F)) {
                              ThreadLocalRandom.current().nextInt(17);
                              return false;
                           }

                           PearlCatchSolution pearlCatchSolution4 = PearlCatchSolver.computePearlCatchSolutionForWorld(MinecraftClientAccess52.getWorld(mc), getClientPlayerEntity(this), getProjectilePath(this), intValue, movementSnapshot, this.clientPlayerEntity.getYaw(), this.clientPlayerEntity.getPitch(), this.pearlCatchOptions.getMaxCatch2());
                           if (pearlCatchSolution4 != null) {
                              if (!(pearlCatchSolution4.getConfidence2() < getPearlCatchOptions(this).getMinConfidence2())) {
                                 if (!this.testItem2(this.intState5, Items.WIND_CHARGE)) {
                                    return false;
                                 }

                                 setPearlCatchSolution(this, pearlCatchSolution4);
                                 setFlickState(this, FlickState.DONE);
                                 return true;
                              }
                           }

                           return false;
                        }
                     }

                     return false;
                  }
               }
            }
         }
      }

      return false;
   }

   public static void setIntegerSet(PearlCatchController pearlCatchController, Set integerSet2) {
      pearlCatchController.integerSet = integerSet2;
   }

   private void updateState13() {
      if (CombatTickBudget.checkCondition4()) {
         if (!this.checkCondition() && !this.checkCondition3(getIntState4(this))) {
            ThreadLocalRandom.current().nextInt(13);
            if (!this.checkCondition3(getIntState5(this))) {
               if (getPearlCatchOptions(this).getMacro()) {
                  if (!this.testItem2(this.intState4, Items.ENDER_PEARL)) {
                     ThreadLocalRandom.current().nextInt(17);
                     this.updateState12("Pearl use refused");
                     return;
                  }

                  setFlickState(this, FlickState.FLICK);
                  setCurrentTick225(this, ActionSchedulers.getCurrentTick22());
                  return;
               }

               if (!this.checkCondition8(this.computeFloat3(), this.computeFloat(), getPearlCatchOptions(this).getFlickSpeed2())) {
                  this.updateState12("Look held elsewhere");
                  return;
               }

               ThreadLocalRandom.current().nextInt(17);
               float yaw = getClientPlayerEntity(this).getYaw();
               float pitch = this.clientPlayerEntity.getPitch();
               ProjectilePath projectilePath2 = ProjectileSimulator.computeProjectileSimulatorForWorld(MinecraftClientAccess52.getWorld(mc), this.clientPlayerEntity, yaw, pitch, this.vec3d, null).computeProjectilePath(160);
               PearlCatchSolution pearlCatchSolution2 = this.computePearlCatchSolutionForProjectilePath(projectilePath2, 0, yaw, pitch);
               if (pearlCatchSolution2 == null) {
                  this.updateState12("No catch for this look");
                  return;
               }

               HashSet hashSet = new HashSet();

               for (Iterator iterator = MinecraftClientAccess52.getWorld(mc).getEntities().iterator(); iterator.hasNext(); ) {
                  Entity entity = (Entity)iterator.next();
                  if (entity instanceof EnderPearlEntity) {
                     hashSet.add(entity.getId());
                  }
               }

               this.integerSet = Set.copyOf(hashSet);
               this.atomicReference.set(null);
               this.id = getClientPlayerEntity(this).getId();
               if (!this.testItem2(getIntState4(this), Items.ENDER_PEARL)) {
                  this.updateState12("Pearl use refused");
                  return;
               }

               this.flickState = FlickState.FLICK;
               this.currentTick225 = ActionSchedulers.getCurrentTick22();
               setProjectilePath(this, projectilePath2);

               this.booleanState4 = false;
               setIntState(this, -1);
               this.pearlCatchSolution = pearlCatchSolution2;
               return;
            }
         }
      }

      if (getFlickState(this) == FlickState.IDLE) {
         this.updateState6();
      }
   }

   private boolean checkCondition9() {
      if (this.intState < 0) {
         return false;
      } else {
         Entity entityById = MinecraftClientAccess52.getWorld(mc).getEntityById(getIntState(this));
         if (entityById != null) {
            if (!entityById.isRemoved()) {
               return false;
            }
         }

         return true;
      }
   }

   public static FlickState getFLICK() {
      return FlickState.FLICK;
   }

   public static void setBooleanState4(PearlCatchController pearlCatchController, boolean booleanState42) {
      pearlCatchController.booleanState4 = booleanState42;
   }

   private void updateStateForItem(Item item, long longValue) {
      setBooleanState3(this, false);
      if (!this.testItem(item, longValue)) {
         String string2;
         if (item == Items.ENDER_PEARL) {
            string2 = "Pearl use failed";
         } else {
            ThreadLocalRandom.current().nextInt(9);

            ThreadLocalRandom.current().nextInt(10);
            string2 = "Charge use failed";
         }

         this.updateState12(string2);
      }
   }
}
