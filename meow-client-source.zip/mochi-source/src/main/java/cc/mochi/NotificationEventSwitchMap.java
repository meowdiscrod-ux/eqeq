package cc.mochi;

public class NotificationEventSwitchMap {
   static final int[] intArray = new int[NotificationEvent.values().length];

   static {
      try {
         intArray[NotificationEvent.MODULE_ENABLED.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      try {
         intArray[NotificationEvent.FRIEND_ADDED.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }

      try {
         intArray[NotificationEvent.MODULE_DISABLED.ordinal()] = 3;
      } catch (NoSuchFieldError failure3) {
      }

      try {
         intArray[NotificationEvent.FRIEND_REMOVED.ordinal()] = 4;
      } catch (NoSuchFieldError failure4) {
      }

      try {
         intArray[NotificationEvent.BUFF_EXPIRED.ordinal()] = 5;
      } catch (NoSuchFieldError failure5) {
      }
   }
}
