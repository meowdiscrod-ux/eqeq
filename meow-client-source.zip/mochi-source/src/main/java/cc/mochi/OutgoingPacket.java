package cc.mochi;

import io.netty.channel.ChannelFutureListener;
import net.minecraft.network.packet.Packet;

public record OutgoingPacket(Packet<?> packet, ChannelFutureListener listener) {
   public static Packet<?> getPacket(OutgoingPacket outgoingPacket) {
      return outgoingPacket.packet;
   }

   public ChannelFutureListener getListener2() {
      return getListener(this);
   }

   public static ChannelFutureListener getListener(OutgoingPacket outgoingPacket) {
      return outgoingPacket.listener;
   }

   public Packet getPacket2() {
      return getPacket(this);
   }
}
