package cc.mochi;

public class MochiClientAccess {
   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static ConfirmationDialog getConfirmationDialog(ModuleBrowser moduleBrowser) {
      return moduleBrowser.confirmationDialog;
   }

}
