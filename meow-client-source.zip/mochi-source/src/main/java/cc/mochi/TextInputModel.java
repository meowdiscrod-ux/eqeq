package cc.mochi;

import cc.mochi.utils.platform.ClipboardUtil;

public final class TextInputModel {
   private final int intState;

   private boolean booleanState;
   private final StringBuilder stringBuilder = new StringBuilder();
   private float floatState;
   private int counter;

   public TextInputModel(int intValue) {
      this.intState = Math.max(1, intValue);
   }

   public static void setCounter(TextInputModel textInputModel, int counter2) {
      textInputModel.counter = counter2;
   }

   public boolean checkCondition(int intValue, boolean booleanValue) {
      if (!this.booleanState) {
         return false;
      } else {
         setFloatState(this, 0.0F);
         switch (intValue) {
            case 65:
               if (!booleanValue) {
                  return false;
               }

               this.updateState2();
               return true;
            case 86:
               if (!booleanValue) {
                  return false;
               }

               String string = ClipboardUtil.paste();
               if (string != null) {
                  for (char charValue : string.replaceAll("[\\r\\n\\t]+", " ").toCharArray()) {
                     if (this.stringBuilder.length() >= this.intState) {
                        break;
                     }

                     if (!Character.isISOControl(charValue)) {
                        StringBuilder stringBuilder9 = getStringBuilder(this);
                        int counter2 = this.counter;
                        setCounter(this, this.counter + 1);
                        stringBuilder9.insert(counter2, charValue);
                     }
                  }
               }

               return true;
            case 259:
               if (getCounter(this) > 0) {
                  int counter3 = booleanValue ? this.computeInt(this.counter) : getCounter(this) - 1;
                  getStringBuilder(this).delete(counter3, this.counter);
                  this.counter = counter3;
               }

               return true;
            case 261:
               if (getCounter(this) < this.stringBuilder.length()) {
                  this.stringBuilder.deleteCharAt(getCounter(this));
               }

               return true;
            case 262:
               this.counter = Math.min(getStringBuilder(this).length(), getCounter(this) + 1);
               return true;
            case 263:
               setCounter(this, booleanValue ? this.computeInt(this.counter) : Math.max(0, getCounter(this) - 1));
               return true;
            case 268:
               this.counter = 0;
               return true;
            case 269:
               this.counter = getStringBuilder(this).length();
               return true;
            default:
               return false;
         }
      }
   }

   public static StringBuilder getStringBuilder(TextInputModel textInputModel) {
      return textInputModel.stringBuilder;
   }

   public boolean checkCondition2(float floatValue) {
      this.floatState += floatValue;
      return getBooleanState(this) && this.floatState % 1.06F < 0.53F;
   }

   public static int getCounter(TextInputModel textInputModel) {
      return textInputModel.counter;
   }

   public static boolean getBooleanState(TextInputModel textInputModel) {
      return textInputModel.booleanState;
   }

   public boolean checkCondition3(char charValue) {
      if (this.booleanState && !Character.isISOControl(charValue)) {
         if (this.stringBuilder.length() < this.intState) {
            getStringBuilder(this).insert(getCounter(this), charValue);
            this.counter++;
         }

         this.floatState = 0.0F;
         return true;
      } else {
         return false;
      }
   }

   public void updateState(String string) {
      getStringBuilder(this).setLength(0);
      if (string != null) {
         this.stringBuilder.append(string, 0, Math.min(string.length(), getIntState(this)));
      }

      this.counter = getStringBuilder(this).length();
   }

   public static void setFloatState(TextInputModel textInputModel, float floatState2) {
      textInputModel.floatState = floatState2;
   }

   public String toString() {
      return getStringBuilder(this).toString();
   }

   private int computeInt(int intValue) {
      int intValue2 = intValue;

      while (intValue2 > 0 && getStringBuilder(this).charAt(intValue2 - 1) == ' ') {
         intValue2--;
      }

      while (intValue2 > 0 && this.stringBuilder.charAt(intValue2 - 1) != ' ') {
         intValue2--;
      }

      return intValue2;
   }

   public boolean isEmpty() {
      return getStringBuilder(this).isEmpty();
   }

   public boolean getBooleanState2() {
      return this.booleanState;
   }

   public void updateState2() {
      this.updateState("");
   }

   public static int getIntState(TextInputModel textInputModel) {
      return textInputModel.intState;
   }

   public int getCounter9() {
      return getCounter(this);
   }

   public void updateState3(boolean booleanState2) {
      this.booleanState = booleanState2;
      setFloatState(this, 0.0F);
      if (booleanState2) {
         setCounter(this, this.stringBuilder.length());
      }
   }

}
