package cc.mochi;

record TextureRegion(TextureHandle texture, float u0, float v0, float u1, float v1) {
   public float getV1() {
      return this.v1;
   }

   public TextureHandle getTexture() {
      return this.texture;
   }

   public float getV0() {
      return this.v0;
   }

   public float getU1() {
      return this.u1;
   }

   public float getU0() {
      return this.u0;
   }
}
