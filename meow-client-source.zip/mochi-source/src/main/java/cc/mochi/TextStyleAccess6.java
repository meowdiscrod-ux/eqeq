package cc.mochi;

public class TextStyleAccess6 {
   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static UiLayer getSYSTEM() {
      return UiLayer.SYSTEM;
   }

   public static TextStyle getSTRONG() {
      return TextStyle.STRONG;
   }

   public static Icon getSEARCH() {
      return Icon.SEARCH;
   }

   public static TextStyle getBODY() {
      return TextStyle.BODY;
   }

}
