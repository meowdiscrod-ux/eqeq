package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.math.Direction;

public class ScaffoldDirectionSwitchMap {
   static final int[] intArray2 = new int[Direction.values().length];

   static {
      try {
         intArray2[Direction.UP.ordinal()] = 1;
      } catch (NoSuchFieldError failure) {
      }

      try {
         intArray2[Direction.DOWN.ordinal()] = 2;
      } catch (NoSuchFieldError failure2) {
      }

      label66: {
         try {
            int[] intArray = intArray2;
            int intValue = Direction.NORTH.ordinal();

            intArray[intValue] = 3;
         } catch (NoSuchFieldError failure3) {
            break label66;
         }
      }

      ThreadLocalRandom.current().nextInt(3);

      label61: {
         try {
            intArray2[Direction.SOUTH.ordinal()] = 4;
         } catch (NoSuchFieldError failure4) {
            break label61;
         }
      }

      label57: {
         try {
            intArray2[Direction.WEST.ordinal()] = 5;
         } catch (NoSuchFieldError failure5) {
            break label57;
         }
      }

      label53: {
         try {
            intArray2[Direction.EAST.ordinal()] = 6;
         } catch (NoSuchFieldError failure6) {
            break label53;
         }
      }
   }
}
