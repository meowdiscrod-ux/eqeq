package cc.mochi;

import java.awt.Color;

public record PotionHudEntry(String label, int amplifier, int duration, float fraction, Color color, boolean urgent) {
   public float getFraction() {
      return this.fraction;
   }

   public int getDuration() {
      return this.duration;
   }

   float computeFloat(float size, boolean booleanValue, boolean booleanValue2, boolean booleanValue3) {
      float floatValue = LegacyUiTheme.measureText(this.label, size, PotionsModule.fontFace2);
      if (booleanValue2 && this.amplifier > 0) {
         floatValue += 3.0F + LegacyUiTheme.measureText(PotionsModule.computeString3(this.amplifier + 1), size, PotionsModule.fontFace2);
      }

      if (booleanValue3) {
         floatValue += 8.0F;
      }

      if (booleanValue) {
         floatValue += 14.0F + LegacyUiTheme.measureText(PotionsModule.computeString2(this.duration), size, PotionsModule.fontFace);
      }

      return floatValue;
   }

   public boolean getUrgent() {
      return this.urgent;
   }

   public Color getColor() {
      return this.color;
   }

   public String getLabel() {
      return this.label;
   }

   public int getAmplifier() {
      return this.amplifier;
   }
}
