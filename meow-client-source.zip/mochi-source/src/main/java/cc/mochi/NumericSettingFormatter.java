package cc.mochi;

public final class NumericSettingFormatter {
   public static String computeStringForSetting(Setting setting, double doubleValue) {
      return computeString(doubleValue, computeIntForSetting(setting));
   }

   public static String computeString(double doubleValue, int intValue) {
      int intValue2 = Math.max(0, Math.min(4, intValue));
      long longValue = Math.round(doubleValue);
      return intValue2 != 0 && !(Math.abs(doubleValue - (double)longValue) < 0.5 * Math.pow(10.0, (double)(-intValue2 - 1)))
         ? String.format("%." + intValue2 + "f", doubleValue)
         : String.valueOf(longValue);
   }

   public static int computeIntForSetting(Setting setting) {
      if (setting instanceof DoubleRangeSetting var3) {
         return computeInt(var3.getStep2());
      } else if (setting instanceof DoubleSetting var2) {
         return computeInt(var2.getStep());
      } else {
         return setting instanceof DecimalSetting var1 ? var1.getDecimalPlaces() : 2;
      }
   }

   private NumericSettingFormatter() {
   }

   public static int computeInt(double doubleValue) {
      if (!(doubleValue > 0.0)) {
         return 0;
      } else {
         int intValue = 0;

         for (double doubleValue2 = doubleValue; doubleValue2 < 0.999999999 && intValue < 4; intValue++) {
            doubleValue2 *= 10.0;
         }

         return intValue;
      }
   }
}
