package cc.mochi;

import net.minecraft.client.MinecraftClient;

public final class UiViewport {
   public static double toViewportY(double doubleValue) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.getWindow() != null) {
         int scaledHeight = minecraftClient.getWindow().getScaledHeight();
         return scaledHeight <= 0 ? doubleValue : doubleValue * (double)getHeight() / (double)scaledHeight;
      } else {
         return doubleValue;
      }
   }

   public static int getHeight() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient != null && minecraftClient.getWindow() != null ? Math.round((float)minecraftClient.getWindow().getFramebufferHeight() / getScale()) : 1080;
   }

   public static float getScale() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.getWindow() != null) {
         int framebufferWidth = minecraftClient.getWindow().getFramebufferWidth();
         int framebufferHeight = minecraftClient.getWindow().getFramebufferHeight();
         return framebufferWidth > 0 && framebufferHeight > 0 ? Math.min((float)framebufferWidth / 1920.0F, (float)framebufferHeight / 1080.0F) : 1.0F;
      } else {
         return 1.0F;
      }
   }

   public static int getWidth() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      return minecraftClient != null && minecraftClient.getWindow() != null ? Math.round((float)minecraftClient.getWindow().getFramebufferWidth() / getScale()) : 1920;
   }

   public static int max() {
      return Math.max(1, Math.round(getScale()));
   }

   private UiViewport() {
   }

   public static double toViewportX(double doubleValue) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.getWindow() != null) {
         int scaledWidth = minecraftClient.getWindow().getScaledWidth();
         return scaledWidth <= 0 ? doubleValue : doubleValue * (double)getWidth() / (double)scaledWidth;
      } else {
         return doubleValue;
      }
   }
}
