package cc.mochi;

import java.awt.Color;
import net.minecraft.util.Identifier;

public interface UiRenderBackend extends AutoCloseable {
   default void drawShadow(float x, float y, float width, float height, float radius, float blur, float offset, Color color) {
      Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha() / 3);
      this.fillRoundedRect(x - offset, y - offset, width + offset * 2.0F, height + offset * 2.0F, radius + offset, color2);
   }

   void drawLine(float startX, float startY, float endX, float endY, float thickness, Color color);

   void applyClip();

   boolean isFallback();

   default void translate(float offsetX, float offsetY) {
   }

   default void fillRoundedCorners(float x, float y, float width, float height, float topLeftRadius, float topRightRadius, float bottomRightRadius, float bottomLeftRadius, Color color) {
      this.fillRoundedRect(x, y, width, height, Math.max(Math.max(topLeftRadius, topRightRadius), Math.max(bottomRightRadius, bottomLeftRadius)), color);
   }

   void drawCamouflage(float x, float y, float width, float height, float radius);

   void drawRoundedTexture(String string, float x, float y, float width, float height, float radius, Color color);

   default void strokeArc(float centerX, float centerY, float radius, float thickness, float startAngle, float sweepAngle, Color color) {
      int intValue = Math.max(2, (int)Math.ceil((double)(Math.abs(sweepAngle) * radius / 3.0F)));
      float endX2 = centerX + (float)Math.cos((double)startAngle) * radius;
      float endY2 = centerY + (float)Math.sin((double)startAngle) * radius;

      for (int intValue2 = 1; intValue2 <= intValue; intValue2++) {
         float floatValue = startAngle + sweepAngle * (float)intValue2 / (float)intValue;
         float endX = centerX + (float)Math.cos((double)floatValue) * radius;
         float endY = centerY + (float)Math.sin((double)floatValue) * radius;
         this.drawLine(endX2, endY2, endX, endY, thickness, color);
         endX2 = endX;
         endY2 = endY;
      }
   }

   default void pushClip(float x, float y, float width, float height) {
      this.setClip(x, y, width, height);
   }

   default void popOpacity() {
   }

   default void drawGlowOutline(float x, float y, float width, float height, float radius, float blur, float spread, Color color) {
      this.fillGlowingRoundedRect(x, y, width, height, radius, new Color(0, 0, 0, 0), color, blur, spread);
   }

   void fillVerticalGradient(float x, float y, float width, float height, float radius, Color topColor, Color bottomColor);

   default boolean drawGlassPanel(GlassPanelStyle glassPanelStyle) {
      return false;
   }

   float measureFontHeight(float size, FontFace font);

   default void scale(float scaleX, float scaleY) {
   }

   default void fillHorizontalGradient(float x, float y, float width, float height, float radius, Color leftColor, Color rightColor) {
      this.fillRoundedRect(x, y, width, height, radius, leftColor);
   }

   float measureText(String text, float size, FontFace font);

   default void drawLineSegment(float startX, float startY, float endX, float endY, float thickness, Color color) {
      this.drawLine(startX, startY, endX, endY, thickness, color);
   }

   void drawText(String text, float x, float y, float size, Color color, FontFace font);

   default void flushBloom() {
   }

   default void popBloom() {
   }

   void fillGlowingRoundedRect(float x, float y, float width, float height, float radius, Color color, Color color2, float blur, float spread);

   default void drawTextureRegion(
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4,
      float floatValue7,
      Color color
   ) {
   }

   @Override
   void close();

   default void fillAngledGradient(float x, float y, float width, float height, float radius, Color startColor, Color endColor, float angle) {
      this.fillRoundedRect(x, y, width, height, radius, new Color(startColor.getRed(), startColor.getGreen(), startColor.getBlue(), (startColor.getAlpha() + endColor.getAlpha()) / 2));
   }

   void drawTextureFromResource(String string, float x, float y, float width, float height, Color color);

   void setClip(float x, float y, float width, float height);

   default void pushBloom(float intensity) {
   }

   default void pushOpacity(float opacity) {
   }

   void fillRect(float x, float y, float width, float height, Color color);

   default void pushTransform() {
   }

   default void rotate(float angle) {
   }

   default void popClip() {
      this.applyClip();
   }

   void strokeRoundedRect(float x, float y, float width, float height, float radius, float thickness, Color color);

   void fillRoundedRect(float x, float y, float width, float height, float radius, Color color);

   default void strokeCircle(float centerX, float centerY, float radius, float thickness, Color color) {
      this.strokeRoundedRect(centerX - radius, centerY - radius, radius * 2.0F, radius * 2.0F, radius, thickness, color);
   }

   default boolean drawAurora(int[] intArray, int intValue, float floatValue, float floatValue2, float floatValue3) {
      return false;
   }

   void fillCircle(float centerX, float centerY, float radius, Color color);

   default void popTransform() {
   }
}
