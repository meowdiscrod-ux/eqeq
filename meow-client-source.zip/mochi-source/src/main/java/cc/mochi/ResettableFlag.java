package cc.mochi;

public final class ResettableFlag {
   private static boolean value;

   public static void reset() {
      setValue(false);
   }

   public static boolean getValue() {
      return value;
   }

   private ResettableFlag() {
   }

   public static void setValue(boolean value2) {
      value = value2;
   }

   public static void set() {
      setValue(true);
   }
}
