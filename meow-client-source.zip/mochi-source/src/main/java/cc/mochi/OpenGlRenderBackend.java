package cc.mochi;

import java.awt.Color;
import net.minecraft.util.Identifier;

final class OpenGlRenderBackend implements UiRenderBackend {
   private boolean closed;

   @Override
   public void pushClip(float x, float y, float width, float height) {
      Render2D.pushClip(x, y, width, height);
   }

   @Override
   public void drawCamouflage(float x, float y, float width, float height, float radius) {
      int intValue = CamouflageRenderer.computeInt();
      if (intValue > 0) {
         Render2D.updateStateForTextureHandle2(TextureHandle.computeTextureHandle(intValue, CamouflageRenderer.getIntState2(), CamouflageRenderer.getIntState3()), 0.0F, 0.0F, Render2D.getViewportWidth(), Render2D.getViewportHeight(), x, y, width, height, radius, 1.0F);
      }
   }

   @Override
   public void fillRect(float x, float y, float width, float height, Color color) {
      Render2D.updateState29(x, y, width, height, color.getRGB());
   }

   @Override
   public void close() {
      if (!this.closed) {
         this.closed = true;
         Render2D.endFrame();
      }
   }

   @Override
   public void popBloom() {
      Render2D.popBloom();
   }

   @Override
   public void drawTextureRegion(
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4,
      float floatValue7,
      Color color
   ) {
      Render2D.updateStateForIdentifier(identifier, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, (float)intValue, (float)intValue2, intValue3, intValue4, floatValue7, color.getRGB());
   }

   @Override
   public void flushBloom() {
      Render2D.flushBloom();
   }

   @Override
   public void fillAngledGradient(float x, float y, float width, float height, float radius, Color startColor, Color endColor, float angle) {
      Render2D.updateState28(x, y, width, height, radius, startColor.getRGB(), endColor.getRGB(), angle);
   }

   @Override
   public void setClip(float x, float y, float width, float height) {
      Render2D.updateState7(x, y, width, height);
   }

   @Override
   public void scale(float scaleX, float scaleY) {
      Render2D.scale(scaleX, scaleY);
   }

   @Override
   public float measureText(String text, float size, FontFace font) {
      return Render2D.computeFloatForFontResourceFamily(AcceleratedBackendProvider.fontFamily(font), text, size);
   }

   @Override
   public void drawGlowOutline(float x, float y, float width, float height, float radius, float blur, float spread, Color color) {
      Render2D.updateState5(x, y, width, height, radius, blur, spread, color.getRGB());
   }

   @Override
   public void drawText(String text, float x, float y, float size, Color color, FontFace font) {
      Render2D.computeFloatForFontResourceFamily3(AcceleratedBackendProvider.fontFamily(font), text, x, y, size, color.getRGB(), AcceleratedBackendProvider.fontWeight(font));
   }

   @Override
   public boolean isFallback() {
      return false;
   }

   @Override
   public void pushTransform() {
      Render2D.pushTransform();
   }

   public OpenGlRenderBackend() {
   }

   @Override
   public float measureFontHeight(float size, FontFace font) {
      return font != FontFace.REGULAR && font != FontFace.POPPINS ? Render2D.computeFloatForFontResourceFamily4(AcceleratedBackendProvider.fontFamily(font), size) : size;
   }

   @Override
   public void popTransform() {
      Render2D.popTransform();
   }

   @Override
   public void drawTextureFromResource(String string, float x, float y, float width, float height, Color color) {
      Render2D.updateState20(string, x, y, width, height, 0.0F, color.getRGB());
   }

   @Override
   public boolean drawGlassPanel(GlassPanelStyle glassPanelStyle) {
      float viewportWidth = Render2D.getViewportWidth();
      float viewportHeight = Render2D.getViewportHeight();
      if (!GlassPanelRenderer.testGlassPanelStyle(glassPanelStyle, viewportWidth, viewportHeight)) {
         return false;
      } else {
         int intValue = GlassPanelRenderer.computeInt();
         if (intValue <= 0) {
            return false;
         } else {
            Render2D.updateStateForRunnable(() -> GlassPanelRenderer.updateState4());
            Render2D.updateStateForTextureHandle2(TextureHandle.computeTextureHandle(intValue, GlassPanelRenderer.getIntState(), GlassPanelRenderer.getIntState2()), 0.0F, 0.0F, viewportWidth, viewportHeight, glassPanelStyle.getX(), glassPanelStyle.getY(), glassPanelStyle.getWidth(), glassPanelStyle.getHeight(), glassPanelStyle.getRadius(), glassPanelStyle.getAlpha());
            return true;
         }
      }
   }

   @Override
   public void strokeArc(float centerX, float centerY, float radius, float thickness, float startAngle, float sweepAngle, Color color) {
      Render2D.updateState22(centerX, centerY, radius, thickness, startAngle, sweepAngle, color.getRGB());
   }

   @Override
   public void strokeRoundedRect(float x, float y, float width, float height, float radius, float thickness, Color color) {
      Render2D.updateState13(x, y, width, height, radius, thickness, color.getRGB());
   }

   @Override
   public boolean drawAurora(int[] intArray, int intValue, float floatValue, float floatValue2, float floatValue3) {
      return Render2D.drawAurora(intArray, intValue, floatValue, floatValue2, floatValue3);
   }

   @Override
   public void popClip() {
      Render2D.popClip();
   }

   @Override
   public void drawLineSegment(float startX, float startY, float endX, float endY, float thickness, Color color) {
      Render2D.updateState26(startX, startY, endX, endY, thickness, color.getRGB());
   }

   @Override
   public void applyClip() {
      Render2D.applyClip();
   }

   @Override
   public void rotate(float angle) {
      Render2D.rotate(angle);
   }

   @Override
   public void drawShadow(float x, float y, float width, float height, float radius, float blur, float offset, Color color) {
      Render2D.updateState12(x, y, width, height, radius, blur, offset, color.getRGB());
   }

   @Override
   public void drawRoundedTexture(String string, float x, float y, float width, float height, float radius, Color color) {
      Render2D.updateState20(string, x, y, width, height, radius, color.getRGB());
   }

   @Override
   public void fillVerticalGradient(float x, float y, float width, float height, float radius, Color topColor, Color bottomColor) {
      Render2D.fillVerticalGradient(x, y, width, height, radius, topColor.getRGB(), bottomColor.getRGB());
   }

   @Override
   public void fillGlowingRoundedRect(float x, float y, float width, float height, float radius, Color color, Color color2, float blur, float spread) {
      if (color2 != null) {
         Render2D.updateState5(x, y, width, height, radius, Math.max(0.01F, blur), spread, color2.getRGB());
      }

      if (color != null) {
         Render2D.updateState11(x, y, width, height, radius, color.getRGB());
      }
   }

   @Override
   public void fillHorizontalGradient(float x, float y, float width, float height, float radius, Color leftColor, Color rightColor) {
      Render2D.fillHorizontalGradient(x, y, width, height, radius, leftColor.getRGB(), rightColor.getRGB());
   }

   @Override
   public void fillRoundedRect(float x, float y, float width, float height, float radius, Color color) {
      Render2D.updateState11(x, y, width, height, radius, color.getRGB());
   }

   @Override
   public void translate(float offsetX, float offsetY) {
      Render2D.translate(offsetX, offsetY);
   }

   @Override
   public void strokeCircle(float centerX, float centerY, float radius, float thickness, Color color) {
      Render2D.updateState14(centerX, centerY, radius, thickness, color.getRGB());
   }

   @Override
   public void drawLine(float startX, float startY, float endX, float endY, float thickness, Color color) {
      Render2D.updateState24(startX, startY, endX, endY, thickness, color.getRGB());
   }

   @Override
   public void fillRoundedCorners(float x, float y, float width, float height, float topLeftRadius, float topRightRadius, float bottomRightRadius, float bottomLeftRadius, Color color) {
      Render2D.updateState9(x, y, width, height, topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, color.getRGB());
   }

   @Override
   public void popOpacity() {
      Render2D.popOpacity();
   }

   @Override
   public void pushOpacity(float opacity) {
      Render2D.pushOpacity(opacity);
   }

   @Override
   public void fillCircle(float centerX, float centerY, float radius, Color color) {
      Render2D.updateState15(centerX, centerY, radius, color.getRGB());
   }

   @Override
   public void pushBloom(float intensity) {
      Render2D.pushBloom(intensity);
   }
}
