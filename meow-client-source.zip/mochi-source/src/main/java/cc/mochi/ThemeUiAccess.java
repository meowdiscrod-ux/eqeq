package cc.mochi;

public class ThemeUiAccess {
   public static UiLayer getBASE() {
      return UiLayer.BASE;
   }

   public static ChoiceSetting getThemeSetting() {
      return ClickGuiModule.themeSetting;
   }

   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }
}
