package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.sound.SoundEvents;

public final class ReBuffNotifierModule extends Module {
   private final BooleanSetting showNotificationSetting;
   private final DoubleSetting volumeSetting;
   private boolean booleanState;
   private final BooleanSetting soundAlertSetting;

   private boolean booleanState2;
   private final Stopwatch stopwatch;
   private boolean booleanState3;

   public static void setBooleanState3(ReBuffNotifierModule reBuffNotifierModule, boolean booleanState32) {
      reBuffNotifierModule.booleanState3 = booleanState32;
   }

   public static Stopwatch getStopwatch(ReBuffNotifierModule reBuffNotifierModule) {
      return reBuffNotifierModule.stopwatch;
   }

   public static boolean getBooleanState(ReBuffNotifierModule reBuffNotifierModule) {
      return reBuffNotifierModule.booleanState;
   }

   @Override
   public void onEnable() {
      super.onEnable();
      setBooleanState(this, false);

      setBooleanState3(this, false);
      setBooleanState2(this, false);
      getStopwatch(this).updateTimestampMillis();
   }

   private void resetBooleanState() {
      this.booleanState = false;
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (mc.player != null) {
         if (this.isEnabled()) {
            boolean statusEffect = mc.player.hasStatusEffect(StatusEffects.SPEED);
            boolean statusEffect2 = mc.player.hasStatusEffect(StatusEffects.STRENGTH);
            if (!statusEffect && this.booleanState3) {
               this.updateState("Speed");
            }

            if (!statusEffect2) {
               if (getBooleanState2(this)) {
                  this.updateState("Strength");
               }
            }

            if (getBooleanState(this)) {
               Stopwatch stopwatch2 = this.stopwatch;

               if (stopwatch2.checkCondition((3000L))) {
                  this.resetBooleanState();
               }
            }

            setBooleanState3(this, statusEffect);
            setBooleanState2(this, statusEffect2);
            return;
         }
      }
   }

   private void updateState(String string3) {
      if (this.soundAlertSetting.getValue()) {
         if (!getBooleanState(this)) {
            this.updateState2();
         }
      }

      if (getShowNotificationSetting(this).getValue()) {
         NotificationManager.getINSTANCE().updateState2(string3);
      }
   }

   public static void setBooleanState2(ReBuffNotifierModule reBuffNotifierModule, boolean booleanState22) {
      reBuffNotifierModule.booleanState2 = booleanState22;
   }

   public static boolean getBooleanState2(ReBuffNotifierModule reBuffNotifierModule) {
      return reBuffNotifierModule.booleanState2;
   }

   public static DoubleSetting getVolumeSetting(ReBuffNotifierModule reBuffNotifierModule) {
      return reBuffNotifierModule.volumeSetting;
   }

   public static void setBooleanState(ReBuffNotifierModule reBuffNotifierModule, boolean booleanState4) {
      reBuffNotifierModule.booleanState = booleanState4;
   }

   @Override
   public void onDisable() {
      this.resetBooleanState();
      super.onDisable();
   }

   private void updateState2() {
      if (!(getBooleanState(this))) {
         setBooleanState(this, true);
         this.stopwatch.updateTimestampMillis();
         mc.getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.BLOCK_NOTE_BLOCK_PLING, getVolumeSetting(this).floatValue()));
      }
   }

   public ReBuffNotifierModule() {
      super("Re-buff Notifier", "Plays a sound when speed or strength effects expire", -1, ModuleCategory.PLAYER);

      this.soundAlertSetting = new BooleanSetting("Sound Alert", true);
      this.showNotificationSetting = new BooleanSetting("Show Notification", true);
      this.volumeSetting = new DoubleSetting("Volume", 0.1F, 2.0, 1.0, 0.1F);
      this.stopwatch = new Stopwatch();
      this.booleanState = false;
      this.booleanState3 = false;
      this.booleanState2 = false;

      Setting[] settingArray = new Setting[3];

      settingArray[0] = this.soundAlertSetting;

      settingArray[1] = this.showNotificationSetting;

      settingArray[2] = this.volumeSetting;
      this.addSettings(settingArray);
   }

   public static BooleanSetting getShowNotificationSetting(ReBuffNotifierModule reBuffNotifierModule) {
      return reBuffNotifierModule.showNotificationSetting;
   }

}
