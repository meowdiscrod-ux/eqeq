// In MeowMenu.java
public static void open(MinecraftClient mc, Screen parent) {
    if (MochiClient.INSTANCE == null || mc == null || mc.currentScreen != parent) return;
    mc.setScreen(new LiquidGuiScreenV2()); // Use the new class
}
