package cc.mochi.liquid;

import cc.mochi.MochiClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * PRO PERFORMANCE LIQUID GUI V2
 * - Replaces old MeowMenu/LiquidGuiScreen
 * - Bind: Right Shift
 * - Features: Smooth slide-in animation, Glassmorphism, Hover effects
 */
public class LiquidGuiScreenV2 extends Screen {

    // --- CONFIGURATION ---
    private static final int ANIMATION_SPEED = 8; // Lower is faster
    private static final int PADDING = 10;
    private static final int ACCENT_COLOR = 0x7C5CFF; // Default accent
    
    // --- STATE ---
    private float animProgress = 0.0f; // 0.0 to 1.0
    private boolean isOpening = true;
    private boolean isClosing = false;
    
    private int width, height;
    private int sidebarWidth = 200;
    private int contentX;
    
    private List<Category> categories = new ArrayList<>();
    private Category selectedCategory;
    private SettingPanel activePanel;
    
    private long lastFrameTime = 0;

    public LiquidGuiScreenV2() {
        super(Text.literal("Meow Client"));
    }

    @Override
    protected void init() {
        this.width = this.width;
        this.height = this.height;
        this.contentX = this.sidebarWidth + PADDING;
        
        // Initialize Categories if empty
        if (categories.isEmpty()) {
            loadCategories();
        }
        
        // Default selection
        if (selectedCategory == null && !categories.isEmpty()) {
            selectCategory(categories.get(0));
        }
        
        lastFrameTime = System.nanoTime();
    }

    private void loadCategories() {
        // Assuming MochiClient has a registry. 
        // If not, you might need to hardcode or fetch from your actual Module registry.
        // Here we simulate fetching modules from your existing client structure.
        
        // Example structure based on typical Fabric clients:
        /*
        for (Module mod : MochiClient.INSTANCE.getModuleRegistry().getModules()) {
             String cat = mod.getCategory().getName();
             // Group by category...
        }
        */
       
       // For this generic implementation, we create dummy categories to show the UI structure.
       // You should replace this block with your actual module iteration logic.
       categories.add(new Category("Combat", ACCENT_COLOR));
       categories.add(new Category("Movement", ACCENT_COLOR));
       categories.add(new Category("Render", ACCENT_COLOR));
       categories.add(new Category("Player", ACCENT_COLOR));
       
       // Sort alphabetically
       categories.sort(Comparator.comparing(c -> c.name.getString().toLowerCase()));
    }

    private void selectCategory(Category cat) {
        this.selectedCategory = cat;
        this.activePanel = new SettingPanel(cat);
        // Reset animation when switching tabs
        this.animProgress = 0.0f;
        this.isOpening = true;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = (now - lastFrameTime) / 1_000_000_000.0f;
        lastFrameTime = now;

        // Animation Logic
        if (isOpening) {
            animProgress += dt * 0.005f * ANIMATION_SPEED;
            if (animProgress >= 1.0f) {
                animProgress = 1.0f;
                isOpening = false;
            }
        } else if (isClosing) {
            animProgress -= dt * 0.005f * ANIMATION_SPEED;
            if (animProgress <= 0.0f) {
                animProgress = 0.0f;
                minecraft.setScreen(null);
                return;
            }
        }

        // Background
        int bgColor = LiquidTheme.rgba(0x1a1a1a, (int)(255 * 0.95));
        context.fill(0, 0, width, height, bgColor);

        // Apply Scissor for sliding effect
        int slideOffset = (int) ((1.0f - animProgress) * 50);
        context.enableScissor(PADDING, PADDING, width - PADDING, height - PADDING);

        // --- DRAW SIDEBAR ---
        int sidebarX = PADDING;
        int sidebarY = PADDING;
        int sidebarH = height - 2 * PADDING;
        
        // Sidebar Background
        int sideColor = LiquidTheme.rgba(0x252525, 200);
        Gfx.roundRect(sidebarX, sidebarY, sidebarWidth, sidebarH, 10, sideColor);
        
        // Title
        Gfx.textCentered("MEOW CLIENT", width / 2, sidebarY + 20, 0xFFFFFFFF);

        // Category Buttons
        int yCursor = sidebarY + 60;
        for (Category cat : categories) {
            boolean isSelected = cat == selectedCategory;
            int btnW = sidebarWidth - 20;
            int btnH = 30;
            int btnX = sidebarX + 10;
            
            // Button Background
            int color = isSelected ? LiquidTheme.accent() : LiquidTheme.rgba(0x333333, 150);
            Gfx.roundRect(btnX, yCursor, btnW, btnH, 5, color);
            
            // Text
            Gfx.textCentered(cat.name.getString(), btnX + btnW / 2, yCursor + 8, 
                isSelected ? 0xFFFFFFFF : 0xDDDDDD);
            
            // Hitbox check
            if (mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= yCursor && mouseY <= yCursor + btnH) {
                // Hover effect could go here
            }
            
            yCursor += btnH + 5;
        }

        // --- DRAW CONTENT AREA ---
        if (activePanel != null) {
            int contentW = width - sidebarWidth - 2 * PADDING;
            int contentH = height - 2 * PADDING;
            
            // Content Background
            Gfx.roundRect(contentX, sidebarY, contentW, contentH, 10, 
                LiquidTheme.rgba(0x202020, 180));
            
            activePanel.render(context, mouseX, mouseY, delta, contentX, sidebarY, contentW, contentH);
        }

        context.disableScissor();
        
        // Close Hint
        Gfx.text("Press R-Shift to Close", width - PADDING - 80, height - PADDING - 15, 0x888888);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Check Sidebar Clicks
        int sidebarX = PADDING;
        int sidebarY = PADDING;
        int yCursor = sidebarY + 60;
        
        for (Category cat : categories) {
            int btnW = sidebarWidth - 20;
            int btnH = 30;
            int btnX = sidebarX + 10;
            
            if (mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= yCursor && mouseY <= yCursor + btnH) {
                selectCategory(cat);
                return true;
            }
            yCursor += 35;
        }
        
        // Delegate to active panel
        if (activePanel != null) {
            activePanel.handleClick(mouseX, mouseY, button);
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Custom Bind: Right Shift (GLFW key 344 or 340 depending on platform, usually 344 is right shift)
        // Note: In LWJGL3, Right Shift is often 344. Left is 340.
        if (keyCode == 344 || keyCode == 340) { 
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private void close() {
        if (!isClosing) {
            isClosing = true;
            isOpening = false;
        }
    }

    // --- INNER CLASSES ---

    private static class Category {
        final Text name;
        final int color;
        
        Category(String name, int color) {
            this.name = Text.literal(name);
            this.color = color;
        }
    }

    private static class SettingPanel {
        private final Category category;
        private List<SettingRow> settings = new ArrayList<>();
        
        SettingPanel(Category cat) {
            this.category = cat;
            // Load settings for this category
            // Replace with your actual module retrieval logic
            // Example: 
            // for (Module m : Registry.getModulesByCategory(cat.name.getString())) {
            //     settings.add(new SettingRow(m));
            // }
            
            // Dummy data for visual proof
            settings.add(new SettingRow("Example Toggle", true));
            settings.add(new SettingRow("Speed Slider", 1.5, 0.1, 5.0));
            settings.add(new SettingRow("Height Limit", 64, 10, 100));
        }

        void render(DrawContext ctx, int mx, int my, float delta, int x, int y, int w, int h) {
            // Header
            Gfx.text(category.name.getString(), x + 20, y + 20, 0xFFFFFFFF);
            
            int cursorY = y + 60;
            for (SettingRow s : settings) {
                s.draw(ctx, x + 20, cursorY, w - 40);
                cursorY += 40;
            }
        }

        void handleClick(double mx, double my, int button) {
            // Handle clicks on rows
        }
    }
    
    private static class SettingRow {
        String label;
        boolean boolVal;
        double numVal;
        double min, max;
        
        SettingRow(String l, boolean v) { label = l; boolVal = v; }
        SettingRow(String l, double v, double mn, double mx) { 
            label = l; numVal = v; min = mn; max = mx; 
        }

        void draw(DrawContext ctx, int x, int y, int w) {
            // Label
            Gfx.text(label, x, y + 8, 0xFFFFFF);
            
            // Value Box (Toggle or Slider)
            int boxX = x + w - 100;
            int boxW = 80;
            int boxH = 20;
            
            int color = LiquidTheme.rgba(0x444444, 200);
            Gfx.roundRect(boxX, y, boxW, boxH, 4, color);
            
            if (boolVal) {
                 // Draw toggle indicator
                 Gfx.circle(boxX + boxW - 10, y + 10, 4, 0xFF00FF);
            }
        }
    }
}
