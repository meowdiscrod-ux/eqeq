// In your main client entry point or initialization
InputUtil.Key rightShiftKey = InputUtil.fromKeyCode(GLFW_KEY_RIGHT_SHIFT, 0);
// Register a callback to call LiquidGuiScreenV2::open or similar
